import Foundation
import AVFoundation
import Combine

// MARK: - CSPlayer
/// AVPlayer-based player mirroring the `IPlayer` interface and `CS3IPlayer` behavior.
final class CSPlayer: ObservableObject {
    static let seekActionTime: Int64 = 30_000

    let player: AVPlayer
    private var timeObserverToken: Any?
    private var endObserver: NSObjectProtocol?
    private var periodicCancellable: Any?

    @Published private(set) var isPlaying = false
    @Published private(set) var isBuffering = false
    @Published private(set) var isEnded = false
    @Published var positionMs: Int64 = 0
    @Published private(set) var durationMs: Int64 = 0
    @Published private(set) var playbackSpeed: Double = 1.0
    @Published private(set) var videoSize: CGSize = .zero
    @Published private(set) var isLive = false
    @Published var subtitleOffsetMs: Int64 = 0
    @Published var isMuted = false

    /// Percentages of the video where the player reports position for episode
    /// handling (mirrors AbstractPlayerFragment constants).
    let skipOpVideoPercentage: Double = 50
    let preloadNextEpisodePercentage: Double = 80
    let nextWatchEpisodePercentage: Double = 90
    let updateSyncProgressPercentage: Double = 80

    var eventHandler: ((PlayerEvent) -> Void)?
    var positionChanged: ((Int64, Int64) -> Void)?
    var statusChanged: ((CSPlayerLoading, PlayerEventSource) -> Void)?

    private var currentStatus: CSPlayerLoading = .isPaused
    private(set) var stamps: [VideoSkipStamp] = []
    private var isSeeking = false
    private var isActive = false
    private var pendingPause = false
    private var hasVideo = false

    init() {
        self.player = AVPlayer()
        player.automaticallyWaitsToMinimizeStalling = true
        player.appliesMediaSelectionCriteriaAutomatically = true
        observePlayer()
    }

    // MARK: Observation

    private func observePlayer() {
        let interval = CMTime(seconds: 0.25, preferredTimescale: 600)
        timeObserverToken = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            guard let self else { return }
            let seconds = time.seconds
            guard !seconds.isNaN, !seconds.isInfinite else { return }
            self.positionMs = Int64(seconds * 1000)
            let dur = self.player.currentItem?.duration.seconds ?? 0
            let durMs = dur.isNaN || dur.isInfinite ? 0 : Int64(dur * 1000)
            if self.durationMs != durMs { self.durationMs = durMs }
            self.eventHandler?(.position(positionMs: self.positionMs, durationMs: durMs, source: .player))
            self.positionChanged?(self.positionMs, durMs)
            self.handleStamps()
        }

        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            self.isEnded = true
            self.setStatus(.isEnded)
            self.eventHandler?(.videoEnded)
        }

        player.publisher(for: \.timeControlStatus)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] status in
                guard let self else { return }
                switch status {
                case .playing:
                    self.isPlaying = true
                    self.isBuffering = false
                    self.setStatus(.isPlaying)
                    self.eventHandler?(.playEvent)
                case .paused:
                    self.isPlaying = false
                    self.isBuffering = false
                    self.setStatus(.isPaused)
                    self.eventHandler?(.pauseEvent)
                case .waitingToPlayAtSpecifiedRate:
                    self.isBuffering = true
                    self.setStatus(.isBuffering)
                @unknown default:
                    break
                }
            }
            .store(in: &cancellables)

        player.publisher(for: \.currentItem?.presentationSize)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] size in
                guard let self, let size else { return }
                self.videoSize = size
                self.eventHandler?(.resized(.fit))
            }
            .store(in: &cancellables)

        player.publisher(for: \.isMuted)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] muted in self?.isMuted = muted }
            .store(in: &cancellables)
    }

    private var cancellables = Set<AnyCancellable>()

    private func setStatus(_ status: CSPlayerLoading) {
        guard currentStatus != status else { return }
        currentStatus = status
        statusChanged?(status, .player)
    }

    // MARK: Loading

    func loadPlayer(link: ExtractorLink?, headers: [String: String]? = nil, startPositionMs: Int64 = 0,
                    isOffline: Bool = false) {
        guard let link else { return }
        isActive = true
        isEnded = false
        positionMs = startPositionMs

        let url = URL(string: link.url)
        var asset: AVURLAsset?
        if let url {
            if link.headers != nil && !(link.headers?.isEmpty ?? true) {
                let options = AVURLAsset(url: url, options: [
                    AVURLAssetAllowsCellularAccessKey: true,
                    "AVURLAssetOutOfBandMIMETypeKey": link.isM3u8 ? "application/x-mpegURL" : "video/mp4"
                ])
                asset = options
            } else {
                asset = AVURLAsset(url: url)
            }
        }

        let item = AVPlayerItem(asset: asset ?? AVPlayerItem(url: URL(string: link.url) ?? URL(fileURLWithPath: "")))
        // Apply custom headers via resource loader when provided.
        if let headers = link.headers ?? headers, !headers.isEmpty, let asset = asset {
            asset.resourceLoader.setDelegate(ResourceLoaderDelegate(headers: headers, cookies: nil), queue: .main)
        }
        player.replaceCurrentItem(with: item)
        isLive = link.isM3u8 || link.type == .hls

        if startPositionMs > 0 {
            seekTo(positionMs: startPositionMs, source: .ui)
        }
        setStatus(.isBuffering)
        player.play()
    }

    func reloadPlayer() {
        let pos = positionMs
        player.pause()
        player.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero)
        player.play()
        if pos > 0 { seekTo(positionMs: pos, source: .ui) }
    }

    // MARK: Controls

    func play() { player.play() }
    func pause() { player.pause() }

    func playPauseToggle() {
        if isPlaying { player.pause() } else { player.play() }
    }

    func restart() {
        seekTo(positionMs: 0, source: .ui)
        player.play()
    }

    func seekForward() { seekBy(seekActionTime) }
    func seekBack() { seekBy(-seekActionTime) }

    func seekBy(_ deltaMs: Int64) {
        seekTo(positionMs: positionMs + deltaMs, source: .ui)
    }

    func seekTo(positionMs: Int64, source: PlayerEventSource) {
        guard isSeekable else { return }
        let clamped = max(0, min(positionMs, durationMs > 0 ? durationMs : positionMs))
        isSeeking = true
        let time = CMTime(seconds: Double(clamped) / 1000.0, preferredTimescale: 600)
        player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] _ in
            self?.isSeeking = false
        }
        self.positionMs = clamped
        eventHandler?(.position(positionMs: clamped, durationMs: durationMs, source: source))
        positionChanged?(clamped, durationMs)
    }

    var isSeekable: Bool {
        durationMs > 0 || isLive
    }

    func setPlaybackSpeed(_ speed: Double) {
        playbackSpeed = speed
        player.rate = Float(speed)
    }

    func toggleMute() {
        player.isMuted.toggle()
    }

    func setMuted(_ muted: Bool) {
        player.isMuted = muted
    }

    func setSubtitleOffset(_ offsetMs: Int64) {
        subtitleOffsetMs = offsetMs
        eventHandler?(.subtitlesUpdated)
    }

    /// Handle skip intro/outro stamps. Mirrors getCurrentTimestamp tolerance.
    func addTimeStamps(_ newStamps: [VideoSkipStamp]) {
        stamps = newStamps.sorted { $0.startTime < $1.startTime }
    }

    func getCurrentTimestamp(within toleranceMs: Double = 300) -> VideoSkipStamp? {
        let posSec = Double(positionMs) / 1000.0
        let toleranceSec = toleranceMs / 1000.0
        return stamps.first { stamp in
            (posSec >= stamp.startTime - toleranceSec) && (posSec <= stamp.endTime)
        }
    }

    func skipCurrentChapter() {
        guard let stamp = getCurrentTimestamp() else {
            seekTo(positionMs: durationMs + 1, source: .ui)
            return
        }
        seekTo(positionMs: Int64(stamp.endTime * 1000), source: .ui)
        eventHandler?(.timestampSkipped(stamp: stamp))
    }

    /// Mirrors the skip-op behavior: seek 85s ahead.
    func skipOpening() {
        seekTo(positionMs: positionMs + 85_000, source: .ui)
    }

    private func handleStamps() {
        guard let stamp = getCurrentTimestamp() else { return }
        // Auto-invoke intro skip (tolerance 300ms) like the Android skip logic.
        eventHandler?(.timestampInvoked(stamp: stamp))
        seekTo(positionMs: Int64(stamp.endTime * 1000), source: .ui)
    }

    // MARK: Tracks

    func getVideoTracks() -> [VideoTrack] {
        // AVPlayer media selection is exposed via `availableMediaSelectionOptions` in the UI layer.
        []
    }

    // MARK: Live edge

    func getTimeAheadOfLive() -> Int64 {
        guard isLive, let item = player.currentItem else { return 0 }
        let dur = item.duration.seconds
        guard !dur.isNaN, dur > 0 else { return 0 }
        return Int64((dur - item.currentTime().seconds) * 1000)
    }

    func seekToLiveEdge() {
        guard let item = player.currentItem else { return }
        let time = CMTimeSubtract(item.duration, CMTime(seconds: 5, preferredTimescale: 600))
        player.seek(to: time)
    }

    // MARK: Lifecycle

    func onResume() {
        if isActive { player.play() }
    }

    func onPause() {
        if isActive { player.pause() }
    }

    func release() {
        isActive = false
        player.pause()
        player.replaceCurrentItem(with: nil)
        if let token = timeObserverToken {
            player.removeTimeObserver(token)
            timeObserverToken = nil
        }
        if let endObserver {
            NotificationCenter.default.removeObserver(endObserver)
            self.endObserver = nil
        }
    }
}

// MARK: - ResourceLoaderDelegate
/// Supplies custom request headers to AVAssetResourceLoader for HLS streams.
final class ResourceLoaderDelegate: NSObject, AVAssetResourceLoaderDelegate, @unchecked Sendable {
    private let headers: [String: String]

    init(headers: [String: String], cookies: [String: String]?) {
        self.headers = headers
    }

    func resourceLoader(_ resourceLoader: AVAssetResourceLoader,
                        shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest) -> Bool {
        guard let url = loadingRequest.request.url else { return false }
        var request = URLRequest(url: url)
        for (k, v) in headers { request.setValue(v, forHTTPHeaderField: k) }
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let data, let response {
                loadingRequest.response = response
                loadingRequest.dataRequest?.respond(with: data)
                loadingRequest.finishLoading()
            } else {
                loadingRequest.finishLoading(with: error)
            }
        }
        task.resume()
        return true
    }
}

// MARK: - LiveManager (mirrors ui/player/live/LiveManager.kt)
enum LiveManager {
    static let liveMargin: Int64 = 6_000
    static let preferredLiveOffset: Int64 = 5_000
    static let chunkVariance: Int64 = 3_000

    struct LivestreamChunk {
        var durationMs: Int64
        var receiveTimeMs: Int64
    }

    static func getTimeAheadOfLive(positionMs: Int64, durationMs: Int64) -> Int64 {
        guard durationMs > 0 else { return 0 }
        return max(0, durationMs - positionMs)
    }
}