import Foundation
import Combine

// MARK: - Download models (mirrors DownloadObjects.kt)
enum DownloadType: Int, Codable, Sendable {
    case isPaused = 0
    case isDownloading = 1
    case isDone = 2
    case isFailed = 3
    case isStopped = 4
    case isPending = 5
}

enum DownloadActionType: Int, Sendable {
    case pause = 0
    case resume = 1
    case stop = 2
}

struct DownloadQueueItem: Codable, Identifiable, Equatable, Sendable {
    var id: Int
    var parentId: Int?
    var episode: Int?
    var season: Int?
    var title: String
    var url: String
    var apiName: String
    var posterUrl: String?
    var tvType: TvType
    var subtitleUrls: [String] = []
}

struct DownloadQueueWrapper: Codable, Identifiable, Equatable, Sendable {
    var item: DownloadQueueItem
    var isPending: Bool = false
    var id: Int { item.id }
    var parentId: Int? { item.parentId }
}

struct DownloadedFileInfo: Codable, Equatable, Sendable {
    var totalBytes: Int64
    var relativePath: String
    var displayName: String
    var basePath: String
    var linkHash: String
}

struct DownloadMetadata: Codable, Equatable, Sendable {
    var id: Int
    var title: String
    var url: String
    var apiName: String
    var posterUrl: String?
    var tvType: TvType
    var season: Int?
    var episode: Int?
    var fileInfo: DownloadedFileInfo
    var status: DownloadType
}

// MARK: - DownloadManager
/// Mirrors VideoDownloadManager behavior using native URLSession downloads.
@MainActor
final class DownloadManager: NSObject, ObservableObject {
    static let shared = DownloadManager()

    static let maxConcurrentDownloads: Int = 3
    static let partialMinSize: Int64 = 50 * 1024 * 1024

    @Published private(set) var downloads: [Int: DownloadType] = [:]
    @Published private(set) var progress: [Int: Double] = [:]
    @Published private(set) var activeDownloads: [Int: ActiveDownload] = [:]

    struct ActiveDownload: Identifiable {
        var id: Int
        var downloadedBytes: Int64
        var totalBytes: Int64
        var speed: Int64
    }

    private var tasks: [Int: URLSessionDownloadTask] = [:]
    private var session: URLSession!

    private let downloadsDirectory: URL

    override private init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        downloadsDirectory = docs.appendingPathComponent("downloads", isDirectory: true)
        super.init()
        try? FileManager.default.createDirectory(at: downloadsDirectory, withIntermediateDirectories: true)
        let config = URLSessionConfiguration.background(withIdentifier: "com.pulsestream.ios.downloads")
        config.isDiscretionary = false
        config.sessionSendsLaunchEvents = true
        session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        loadPersistedState()
    }

    private func loadPersistedState() {
        let keys = CSDataStore.getKeys().filter { $0.hasPrefix("downloads/status/") }
        for key in keys {
            if let raw = CSDataStore.getRaw(key), let type = DownloadType(rawValue: Int(raw) ?? -1) {
                let id = Int(String(key.dropFirst("downloads/status/".count))) ?? 0
                downloads[id] = type
            }
        }
    }

    // MARK: Public API

    func download(item: DownloadQueueItem) {
        let id = item.id
        guard tasks[id] == nil else { return }
        guard let url = URL(string: item.url) else { return }

        downloads[id] = .isDownloading
        CSDataStore.setKey("downloads/status/\(id)", downloads[id]!.rawValue)
        progress[id] = 0

        var request = URLRequest(url: url)
        request.timeoutInterval = 60
        let task = session.downloadTask(with: request)
        tasks[id] = task
        activeDownloads[id] = ActiveDownload(id: id, downloadedBytes: 0, totalBytes: 0, speed: 0)
        task.resume()
    }

    func pause(id: Int) {
        guard let task = tasks[id] else { return }
        task.cancel { [weak self] resumeData in
            Task { @MainActor in
                self?.resumeData[id] = resumeData
                self?.downloads[id] = .isPaused
                self?.persistStatus(id: id, type: .isPaused)
                self?.tasks[id] = nil
                self?.activeDownloads[id] = nil
            }
        }
    }

    func resume(id: Int) {
        guard downloads[id] == .isPaused || downloads[id] == .isFailed else { return }
        let item = queueItem(for: id)
        if let resumeData = resumeData[id] {
            let task = session.downloadTask(withResumeData: resumeData)
            tasks[id] = task
            downloads[id] = .isDownloading
            persistStatus(id: id, type: .isDownloading)
            task.resume()
        } else if let item {
            download(item: item)
        }
    }

    func stop(id: Int) {
        tasks[id]?.cancel()
        tasks[id] = nil
        resumeData[id] = nil
        downloads[id] = .isStopped
        persistStatus(id: id, type: .isStopped)
        activeDownloads[id] = nil
    }

    func remove(id: Int) {
        stop(id: id)
        downloads.removeValue(forKey: id)
        progress.removeValue(forKey: id)
        CSDataStore.removeKey("downloads/status/\(id)")
        // Remove downloaded file
        if let meta: DownloadMetadata = CSDataStore.getKey("downloads/meta/\(id)", type: DownloadMetadata.self) {
            let fileURL = downloadsDirectory.appendingPathComponent(meta.fileInfo.relativePath)
            try? FileManager.default.removeItem(at: fileURL)
            CSDataStore.removeKey("downloads/meta/\(id)")
        }
    }

    func status(of id: Int) -> DownloadType {
        downloads[id] ?? .isPending
    }

    func isDone(_ id: Int) -> Bool {
        downloads[id] == .isDone
    }

    // MARK: Helpers

    private var resumeData: [Int: Data] = [:]
    private var queueStore: [Int: DownloadQueueItem] = [:]

    private func queueItem(for id: Int) -> DownloadQueueItem? {
        if let item = queueStore[id] { return item }
        if let wrapper: DownloadQueueWrapper = CSDataStore.getKey("downloads/queue/\(id)", type: DownloadQueueWrapper.self) {
            queueStore[id] = wrapper.item
            return wrapper.item
        }
        return nil
    }

    private func persistStatus(id: Int, type: DownloadType) {
        CSDataStore.setKey("downloads/status/\(id)", type.rawValue)
    }

    /// Mirror of setupStream — persist a streaming URL as a download.
    func setupStream(url: String, name: String) async {
        let id = url.hashValue & 0x7fffffff
        let item = DownloadQueueItem(id: id, title: name, url: url, apiName: "Direct", tvType: .video)
        queueStore[id] = item
        let wrapper = DownloadQueueWrapper(item: item)
        CSDataStore.setKey("downloads/queue/\(id)", wrapper)
        download(item: item)
    }

    func getDownloadFileInfo(id: Int) -> DownloadedFileInfo? {
        guard let meta: DownloadMetadata = CSDataStore.getKey("downloads/meta/\(id)", type: DownloadMetadata.self) else { return nil }
        return meta.fileInfo
    }

    func getFileURL(id: Int) -> URL? {
        guard let info = getDownloadFileInfo(id: id) else { return nil }
        return downloadsDirectory.appendingPathComponent(info.relativePath)
    }
}

// MARK: - URLSessionDownloadDelegate
extension DownloadManager: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let id = downloadTask.taskIdentifier
        Task { @MainActor in
            progress[id] = totalBytesExpectedToWrite > 0 ? Double(totalBytesWritten) / Double(totalBytesExpectedToWrite) : 0
            activeDownloads[id] = ActiveDownload(id: id, downloadedBytes: totalBytesWritten,
                                                totalBytes: totalBytesExpectedToWrite, speed: bytesWritten)
        }
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let taskId = downloadTask.taskIdentifier
        Task { @MainActor in
            guard let item = queueItem(for: taskId) else { return }
            let fileURL = downloadsDirectory.appendingPathComponent("\(taskId)_\(sanitize(item.title))\(ext(for: item.url))")
            try? FileManager.default.createDirectory(at: downloadsDirectory, withIntermediateDirectories: true)
            try? FileManager.default.removeItem(at: fileURL)
            try? FileManager.default.moveItem(at: location, to: fileURL)
            let size = (try? FileManager.default.attributesOfItem(atPath: fileURL.path)[.size] as? Int64) ?? 0
            let info = DownloadedFileInfo(totalBytes: size, relativePath: fileURL.lastPathComponent,
                                          displayName: item.title, basePath: downloadsDirectory.path,
                                          linkHash: "\(taskId)")
            let meta = DownloadMetadata(id: taskId, title: item.title, url: item.url, apiName: item.apiName,
                                        posterUrl: item.posterUrl, tvType: item.tvType, season: item.season,
                                        episode: item.episode, fileInfo: info, status: .isDone)
            CSDataStore.setKey("downloads/meta/\(taskId)", meta)
            downloads[taskId] = .isDone
            progress[taskId] = 1.0
            persistStatus(id: taskId, type: .isDone)
            tasks[taskId] = nil
            activeDownloads[taskId] = nil
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error else { return }
        let taskId = task.taskIdentifier
        Task { @MainActor in
            let nsError = error as NSError
            if nsError.domain == NSURLErrorDomain, nsError.code == NSURLErrorCancelled {
                return
            }
            downloads[taskId] = .isFailed
            persistStatus(id: taskId, type: .isFailed)
            activeDownloads[taskId] = nil
            tasks[taskId] = nil
        }
    }

    private func sanitize(_ name: String) -> String {
        let invalid = CharacterSet(charactersIn: "/\\:?%*|\"<>")
        return name.components(separatedBy: invalid).joined(separator: "_")
    }

    private func ext(for url: String) -> String {
        if url.contains(".m3u8") { return ".m3u8" }
        if let path = URL(string: url)?.lastPathComponent, let ext = path.components(separatedBy: ".").last, ext.count < 6 {
            return ".\(ext)"
        }
        return ".mp4"
    }
}

// MARK: - DownloadQueueManager (mirrors utils/downloader/DownloadQueueManager.kt)
@MainActor
final class DownloadQueueManager: ObservableObject {
    static let shared = DownloadQueueManager()
    static let queueKey = "download_queue_key"

    @Published private(set) var queue: [DownloadQueueWrapper] = []

    private init() {
        queue = CSDataStore.getKey(Self.queueKey, type: [DownloadQueueWrapper].self) ?? []
    }

    func add(_ item: DownloadQueueItem) {
        guard !queue.contains(where: { $0.id == item.id }) else { return }
        var wrapper = DownloadQueueWrapper(item: item, isPending: true)
        if queue.isEmpty {
            wrapper.isPending = false
            DownloadManager.shared.download(item: item)
        } else {
            wrapper.isPending = true
        }
        queue.append(wrapper)
        persist()
    }

    func addToQueue(_ item: DownloadQueueItem) {
        var wrapper = DownloadQueueWrapper(item: item, isPending: true)
        if queue.isEmpty {
            wrapper.isPending = false
            DownloadManager.shared.download(item: item)
        }
        queue.append(wrapper)
        persist()
    }

    func remove(id: Int) {
        queue.removeAll { $0.id == id }
        persist()
    }

    func removeAll() {
        for item in queue {
            DownloadManager.shared.remove(id: item.id)
        }
        queue.removeAll()
        persist()
    }

    func reorder(fromOffsets source: IndexSet, toOffset destination: Int) {
        queue.move(fromOffsets: source, toOffset: destination)
        persist()
    }

    private func persist() {
        CSDataStore.setKey(Self.queueKey, queue)
    }
}