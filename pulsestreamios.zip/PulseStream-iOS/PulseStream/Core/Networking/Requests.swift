import Foundation

// MARK: - Response
/// Mirrors the `Response` returned by nicehttp's Requests.
struct CSResponse: Sendable {
    let statusCode: Int
    let body: Data?
    let headers: [String: String]
    let url: URL?

    var text: String {
        guard let body else { return "" }
        return String(data: body, encoding: .utf8) ?? String(data: body, encoding: .isoLatin1) ?? ""
    }

    var isSuccessful: Bool { (200..<300).contains(statusCode) }

    func parsed<T: Decodable>(_ type: T.Type) throws -> T {
        guard let body, !body.isEmpty else { throw CS3Error.invalidResponse }
        return try CSJSON.decoder.decode(type, from: body)
    }

    func jsonObject() throws -> [String: Any] {
        guard let body, let obj = try? JSONSerialization.jsonObject(with: body) as? [String: Any] else {
            throw CS3Error.decode("Not a JSON object")
        }
        return obj
    }
}

// MARK: - Cookie Store
final class CSCookieStore: @unchecked Sendable {
    static let shared = CSCookieStore()
    private var storage: [String: [String: String]] = [:]
    private let lock = NSLock()

    func setCookie(name: String, value: String, domain: String) {
        lock.lock(); defer { lock.unlock() }
        var dom = storage[domain] ?? [:]
        dom[name] = value
        storage[domain] = dom
    }

    func cookies(for domain: String) -> [String: String] {
        lock.lock(); defer { lock.unlock() }
        var result: [String: String] = [:]
        for (d, cookies) in storage where domain.hasSuffix(d) || d.hasSuffix(domain) {
            for (k, v) in cookies { result[k] = v }
        }
        return result
    }

    func cookieHeader(for url: URL?) -> String? {
        guard let host = url?.host else { return nil }
        let cookies = cookies(for: host)
        guard !cookies.isEmpty else { return nil }
        return cookies.map { "\($0.key)=\($0.value)" }.joined(separator: "; ")
    }

    func parseSetCookie(_ headerValue: String, for url: URL?) {
        guard let host = url?.host else { return }
        for part in headerValue.components(separatedBy: ",") {
            let pieces = part.split(separator: ";").map { $0.trimmingCharacters(in: .whitespaces) }
            guard let first = pieces.first, let eq = first.firstIndex(of: "=") else { continue }
            let name = String(first[..<eq])
            let value = String(first[first.index(after: eq)...])
            setCookie(name: name, value: value, domain: host)
        }
    }

    func clear() {
        lock.lock(); defer { lock.unlock() }
        storage.removeAll()
    }
}

// MARK: - Requests
/// Mirrors `com.lagradost.nicehttp.Requests` — the primary HTTP client.
final class Requests: @unchecked Sendable {
    static let userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    static let jsonResponseParser: (Data) -> String = { data in
        String(data: data, encoding: .utf8) ?? ""
    }

    /// The shared app-wide client (mirrors `app` in library MainActivity.kt).
    static let app = Requests()
    /// SSL-disabled client (mirrors `insecureApp` / @UnsafeSSL).
    static let insecureApp = Requests(verifySSL: false)

    private let session: URLSession
    private let verifySSL: Bool
    private let cookieStore: CSCookieStore

    init(verifySSL: Bool = true) {
        self.verifySSL = verifySSL
        self.cookieStore = CSCookieStore.shared
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieAcceptPolicy = .never
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 120
        config.requestCachePolicy = .useProtocolCachePolicy
        config.urlCache = URLCache(memoryCapacity: 64 * 1024 * 1024, diskCapacity: 256 * 1024 * 1024)
        if verifySSL {
            self.session = URLSession(configuration: config)
        } else {
            self.session = URLSession(configuration: config, delegate: InsecureDelegate(), delegateQueue: nil)
        }
    }

    // MARK: Request builder

    func request(_ method: String, _ url: String, headers: [String: String]? = nil,
                 params: [String: Any]? = nil, body: Data? = nil, json: Any? = nil,
                 referer: String? = nil, timeout: TimeInterval? = nil,
                 allowRedirects: Bool = true) async throws -> CSResponse {
        guard var components = URLComponents(string: url) else { throw CS3Error.invalidResponse }
        if let params, !params.isEmpty {
            var queryItems = components.queryItems ?? []
            for (k, v) in params {
                queryItems.append(URLQueryItem(name: k, value: String(describing: v)))
            }
            components.queryItems = queryItems.isEmpty ? nil : queryItems
        }
        guard let finalURL = components.url else { throw CS3Error.invalidResponse }

        var request = URLRequest(url: finalURL)
        request.httpMethod = method
        request.timeoutInterval = timeout ?? 30

        var mergedHeaders: [String: String] = [:]
        mergedHeaders["User-Agent"] = Requests.userAgent
        if let cookieHeader = cookieStore.cookieHeader(for: finalURL) {
            mergedHeaders["Cookie"] = cookieHeader
        }
        if let referer {
            mergedHeaders["Referer"] = referer
        }
        if let headers {
            for (k, v) in headers { mergedHeaders[k] = v }
        }
        request.allHTTPHeaderFields = mergedHeaders

        if let body {
            request.httpBody = body
        } else if let json {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: json)
        }

        if !allowRedirects {
            request.setValue("true", forHTTPHeaderField: "X-CS-NoRedirect")
        }

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw CS3Error.invalidResponse }

        if let setCookie = http.allHeaderFields["Set-Cookie"] as? String {
            cookieStore.parseSetCookie(setCookie, for: finalURL)
        }

        var headersDict: [String: String] = [:]
        for (k, v) in http.allHeaderFields {
            headersDict["\(k)"] = "\(v)"
        }

        return CSResponse(statusCode: http.statusCode, body: data, headers: headersDict, url: http.url)
    }

    func get(_ url: String, headers: [String: String]? = nil, params: [String: Any]? = nil,
             referer: String? = nil, allowRedirects: Bool = true, verify: Bool = true,
             timeout: TimeInterval? = nil) async throws -> CSResponse {
        try await request("GET", url, headers: headers, params: params, referer: referer,
                          timeout: timeout, allowRedirects: allowRedirects)
    }

    func post(_ url: String, headers: [String: String]? = nil, params: [String: Any]? = nil,
              json: Any? = nil, data: Data? = nil, referer: String? = nil,
              allowRedirects: Bool = true, timeout: TimeInterval? = nil) async throws -> CSResponse {
        try await request("POST", url, headers: headers, params: params, body: data, json: json,
                          referer: referer, timeout: timeout, allowRedirects: allowRedirects)
    }

    func put(_ url: String, headers: [String: String]? = nil, params: [String: Any]? = nil,
             json: Any? = nil, data: Data? = nil, referer: String? = nil) async throws -> CSResponse {
        try await request("PUT", url, headers: headers, params: params, body: data, json: json, referer: referer)
    }

    func delete(_ url: String, headers: [String: String]? = nil, params: [String: Any]? = nil,
                json: Any? = nil, referer: String? = nil) async throws -> CSResponse {
        try await request("DELETE", url, headers: headers, params: params, body: nil, json: json, referer: referer)
    }
}

/// URLSession delegate that skips SSL certificate validation (@UnsafeSSL equivalent).
private final class InsecureDelegate: NSObject, URLSessionDelegate, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let trust = challenge.protectionSpace.serverTrust {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }
}

// MARK: - JSON helpers
enum CSJSON {
    static let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .useDefaultKeys
        return d
    }()

    static let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.outputFormatting = [.sortedKeys]
        return e
    }()

    static func decode<T: Decodable>(_ type: T.Type, from json: [String: Any]) throws -> T {
        let data = try JSONSerialization.data(withJSONObject: json)
        return try decoder.decode(type, from: data)
    }

    static func toJSONString<T: Encodable>(_ value: T) throws -> String {
        let data = try encoder.encode(value)
        return String(data: data, encoding: .utf8) ?? ""
    }
}

// MARK: - URL utils
enum URLUtils {
    static func fixUrl(_ url: String?, base: String? = nil) -> String? {
        guard let url else { return nil }
        var u = url.trimmingCharacters(in: .whitespacesAndNewlines)
        if u.hasPrefix("//") {
            u = "https:\(u)"
        } else if u.hasPrefix("/") {
            if let base {
                u = "\(base.trimmingCharacters(in: CharacterSet(charactersIn: "/")))\(u)"
            }
        } else if !u.lowercased().hasPrefix("http://") && !u.lowercased().hasPrefix("https://") {
            u = "https://\(u)"
        }
        return u
    }

    static func decodeUrl(_ value: String) -> String {
        value.removingPercentEncoding ?? value
    }

    static func encodeUrl(_ value: String) -> String {
        value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value
    }

    static func baseUrl(_ url: String?) -> String? {
        guard let url else { return nil }
        guard let components = URLComponents(string: url), let scheme = components.scheme, let host = components.host else {
            return nil
        }
        var result = "\(scheme)://\(host)"
        if let port = components.port { result += ":\(port)" }
        return result
    }

    static func domain(_ url: String?) -> String? {
        URL(string: url ?? "")?.host
    }
}

// MARK: - HTML entity decode
enum HTMLEntities {
    static func decode(_ input: String) -> String {
        guard let data = input.data(using: .utf8) else { return input }
        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]
        guard let attributed = try? NSAttributedString(data: data, options: options,
                                                       documentAttributes: nil) else { return input }
        return attributed.string
    }
}