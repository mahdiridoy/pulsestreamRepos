import Foundation

// MARK: - AdBlocker (mirrors library utils/AdBlocker.kt)
/// Filters obvious advertisement/pop-under links and domains from provider results.
enum AdBlocker {
    private static let adDomains: Set<String> = [
        "omg10.com", "popads.net", "popadscdn.net", "popcash.net", "popunder.net",
        "popunderit.com", "popmyads.com", "popunderjs.com", "popuscash.com",
        "sitepopup.com", "adsterra.com", "adsterra.net", "adbana.com", "adbana.net",
        "adk2x.com", "adnium.com", "adpushup.com", "adreactor.com", "adserver.com",
        "advertising.com", "advertserve.com", "advertstream.com", "adshost1.com",
        "clickadu.com", "propellerads.com", "propellerclick.com", "exoclick.com",
        "juicyads.com", "juicyadss.com", "onclickads.net", "onclckds.com",
        "trafficjunky.net", "zedo.com", "cpmstar.com", "smartyads.com", "bannerbunk.com",
        "intentmedia.net", "taboola.com", "outbrain.com", "revcontent.com", "mgid.com",
        "majesticsofaindia.com", "circleftp.net", "googlesyndication.com",
        "doubleclick.net", "googletagservices.com", "googleadservices.com",
        "adservice.google.com"
    ]

    private static let adNameRegex = try! NSRegularExpression(
        pattern: #"(?i)\b(ad|ads|advert|advertisement|sponsored|sponsor|popup|popunder|pop-under)\b"#
    )

    private static let adPathRegex = try! NSRegularExpression(
        pattern: #"(?i)(scratchcard|slideup|popunder|popupad|adframe|ads-frame|bannerad|advert|adsense|doubleclick)"#
    )

    static func isAdDomain(_ host: String) -> Bool {
        let lower = host.lowercased().trimmingCharacters(in: .whitespaces)
        return adDomains.contains { lower == $0 || lower.hasSuffix(".\($0)") }
    }

    static func isAdUrl(_ urlString: String) -> Bool {
        guard let parsed = URL(string: urlString), let host = parsed.host else { return false }
        return isAdDomain(host) || matches(adPathRegex, parsed.path)
    }

    static func isAdName(_ name: String) -> Bool {
        matches(adNameRegex, name)
    }

    static func isAdLink(_ link: ExtractorLink) -> Bool {
        isAdUrl(link.url) || isAdName(link.name)
    }

    private static func matches(_ regex: NSRegularExpression, _ string: String) -> Bool {
        let range = NSRange(string.startIndex..., in: string)
        return regex.firstMatch(in: string, options: [], range: range) != nil
    }
}