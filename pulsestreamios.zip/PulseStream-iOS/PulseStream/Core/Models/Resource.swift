import Foundation

/// Mirrors `Resource<T>` from the Android mvvm layer.
enum Resource<Value> {
    case success(Value)
    case failure(isNetworkError: Bool, errorString: String)
    case loading

    var value: Value? {
        if case .success(let v) = self { return v }
        return nil
    }

    var errorString: String? {
        if case .failure(_, let e) = self { return e }
        return nil
    }

    var isSuccess: Bool {
        if case .success = self { return true }
        return false
    }

    var isLoading: Bool {
        if case .loading = self { return true }
        return false
    }
}

enum CS3Error: LocalizedError {
    case network
    case timeout
    case ssl
    case cancelled
    case invalidResponse
    case server(String)
    case versionMismatch
    case notFound
    case decode(String)

    var errorDescription: String? {
        switch self {
        case .network: return "Cannot connect to server"
        case .timeout: return "Connection timed out"
        case .ssl: return "SSL/TLS connection failed"
        case .cancelled: return "Cancelled"
        case .invalidResponse: return "Invalid server response"
        case .server(let m): return m
        case .versionMismatch: return "App version mismatch"
        case .notFound: return "Content not found"
        case .decode(let m): return "Failed to decode response: \(m)"
        }
    }

    static func from<Value>(_ error: Error) -> Resource<Value> {
        let ns = error as NSError
        if ns.domain == NSURLErrorDomain {
            switch ns.code {
            case NSURLErrorTimedOut: return .failure(isNetworkError: true, errorString: "Connection timed out")
            case NSURLErrorCannotFindHost, NSURLErrorCannotConnectToHost, NSURLErrorNetworkConnectionLost,
                 NSURLErrorNotConnectedToInternet, NSURLErrorDNSLookupFailed:
                return .failure(isNetworkError: true, errorString: "Cannot connect to server")
            case NSURLErrorSecureConnectionFailed, NSURLErrorServerCertificateUntrusted,
                 NSURLErrorServerCertificateHasBadDate, NSURLErrorServerCertificateNotYetValid:
                return .failure(isNetworkError: true, errorString: "SSL/TLS connection failed")
            case NSURLErrorCancelled: return .failure(isNetworkError: false, errorString: "Cancelled")
            default: return .failure(isNetworkError: true, errorString: error.localizedDescription)
            }
        }
        return .failure(isNetworkError: false, errorString: error.localizedDescription)
    }
}

/// Concurrency helpers mirroring `amap` / `runAllAsync`.
extension Sequence {
    func amap<Output>(_ transform: @escaping (Element) async throws -> Output) async rethrows -> [Output] {
        var results: [Output] = []
        results.reserveCapacity(underestimatedCount)
        for element in self {
            results.append(try await transform(element))
        }
        return results
    }
}

func runAllAsync<Result>(_ tasks: [(() async throws -> Result)]) async throws -> [Result] {
    try await withThrowingTaskGroup(of: Result.self) { group in
        for task in tasks {
            group.addTask { try await task() }
        }
        var results: [Result] = []
        for try await result in group { results.append(result) }
        return results
    }
}