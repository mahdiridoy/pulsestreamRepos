import Foundation

// MARK: - LiveTvChannel
/// Mirrors `LiveTvChannel` from the Android app.
struct LiveTvChannel: Codable, Identifiable, Equatable, Hashable, Sendable {
    var id: String
    var name: String
    var streamUrl: String
    var logoUrl: String?
    var groupTitle: String?
    var tvgId: String?

    init(id: String? = nil, name: String, streamUrl: String, logoUrl: String? = nil,
         groupTitle: String? = nil, tvgId: String? = nil) {
        if let id, !id.isEmpty {
            self.id = id
        } else if let tvgId, !tvgId.isEmpty {
            self.id = tvgId
        } else {
            self.id = "ch_\(abs((name + streamUrl).hashValue))"
        }
        self.name = name
        self.streamUrl = streamUrl
        self.logoUrl = logoUrl
        self.groupTitle = groupTitle
        self.tvgId = tvgId
    }
}

// MARK: - M3U Parser
/// Mirrors `M3uParser` from ui/livetv/M3uParser.kt.
enum M3uParser {
    /// Matches `key="value"` attribute pairs inside `#EXTINF:` lines.
    private static let attributeRegex = try! NSRegularExpression(pattern: "([a-zA-Z0-9\\-]+)=\"([^\"]*)\"")

    static func parse(_ content: String) -> [LiveTvChannel] {
        var channels: [LiveTvChannel] = []
        var attributes: [String: String] = [:]
        var name: String?

        let lines = content.components(separatedBy: .newlines)
        for rawLine in lines {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty { continue }

            if line.hasPrefix("#EXTINF") {
                attributes = [:]
                let nsRange = NSRange(line.startIndex..<line.endIndex, in: line)
                attributeRegex.enumerateMatches(in: line, options: [], range: nsRange) { match, _, _ in
                    guard let match else { return }
                    if let keyRange = Range(match.range(at: 1), in: line),
                       let valueRange = Range(match.range(at: 2), in: line) {
                        attributes[String(line[keyRange])] = String(line[valueRange])
                    }
                }
                // Trailing name after last comma, e.g. #EXTINF:-1 tvg-id="x",Channel Name
                if let comma = line.lastIndex(of: ",") {
                    let after = line[line.index(after: comma)...]
                    name = String(after)
                }
            } else if line.hasPrefix("#EXTVLCOPT") {
                continue
            } else if line.hasPrefix("#") {
                continue
            } else {
                // This is a stream URL line
                let streamUrl = line
                let tvgId = attributes["tvg-id"]
                let logoUrl = attributes["tvg-logo"]
                let groupTitle = attributes["group-title"]
                let channelName = name ?? attributes["tvg-name"] ?? tvgId ?? "Unknown"
                let channel = LiveTvChannel(name: channelName, streamUrl: streamUrl,
                                            logoUrl: logoUrl, groupTitle: groupTitle, tvgId: tvgId)
                channels.append(channel)
                attributes = [:]
                name = nil
            }
        }
        return channels
    }
}

// MARK: - Live TV player models
enum LiveTvResolution: Int, CaseIterable, Sendable {
    case auto = 0
    case p1080 = 1
    case p720 = 2
    case p480 = 3
    case p360 = 4

    var maxHeight: Int? {
        switch self {
        case .auto: return nil
        case .p1080: return 1080
        case .p720: return 720
        case .p480: return 480
        case .p360: return 360
        }
    }

    var displayName: String {
        switch self {
        case .auto: return "Auto"
        case .p1080: return "1080p"
        case .p720: return "720p"
        case .p480: return "480p"
        case .p360: return "360p"
        }
    }
}