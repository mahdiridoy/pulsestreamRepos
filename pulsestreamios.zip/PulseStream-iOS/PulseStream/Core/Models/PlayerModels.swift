import Foundation

// MARK: - ExtractorLink
/// Mirrors `ExtractorLink` from the library ExtractorApi.
struct ExtractorLink: Codable, Equatable, Hashable, Identifiable, Sendable {
    var source: String
    var name: String
    var url: String
    var quality: Int
    var headers: [String: String]?
    var extractorData: String?
    var isM3u8: Bool
    var type: ExtractorLinkType
    var needsHeader: Bool = false
    var drm: [String] = []
    var width: Int?
    var height: Int?
    var fileSize: Int64?

    var id: String { "\(source)|\(name)|\(url)" }

    /// Referer header derived from the source url. Mirrors `newExtractorLink`.
    var referer: String? {
        guard let headers, let referer = headers["Referer"] ?? headers["referer"] else { return nil }
        return referer
    }

    func settingHeader(_ key: String, _ value: String) -> ExtractorLink {
        var copy = self
        var h = copy.headers ?? [:]
        h[key] = value
        copy.headers = h
        return copy
    }
}

enum ExtractorLinkType: Int, Codable, CaseIterable, Sendable {
    case normal = 0
    case m3u8 = 1
    case dash = 2
    case hls = 3
    case torrent = 4
    case magnet = 5

    static let loadTypeInApp: Set<ExtractorLinkType> = [.normal, .dash, .m3u8, .torrent, .magnet]
    static let loadTypeInAppDownload: Set<ExtractorLinkType> = [.normal, .dash, .m3u8]
    static let loadTypeChromecast: Set<ExtractorLinkType> = [.normal, .dash, .m3u8]
}

enum Qualities: Int, Codable, CaseIterable, Sendable {
    case unknown = -1
    case lq = 120
    case sd = 480
    case hd = 720
    case fhd = 1080
    case uhd4k = 2160

    init(quality: Int) {
        self = Qualities(rawValue: quality) ?? .unknown
    }
}

struct ExtractorMedia: Codable, Equatable, Sendable {
    var quality: Qualities
    var width: Int?
    var height: Int?
    var size: Int64?
}

// MARK: - SubtitleData
/// Mirrors `SubtitleData` from PlayerSubtitleHelper.
struct SubtitleData: Codable, Equatable, Hashable, Identifiable, Sendable {
    enum Origin: Int, Codable, Sendable {
        case url = 0
        case embeddedInVideo = 1
        case downloadedFile = 2
    }

    var originalName: String
    var nameSuffix: String = ""
    var url: String
    var origin: Origin = .url
    var mimeType: String?
    var headers: [String: String]?
    var languageCode: String?

    var name: String { nameSuffix.isEmpty ? originalName : "\(originalName) \(nameSuffix)" }
    var id: String { origin == .embeddedInVideo ? url : "\(url)|\(name)" }

    /// Mirrors `getFixedUrl` — prepends https: for scheme-less urls.
    func fixedUrl() -> String {
        if url.hasPrefix("//") { return "https:\(url)" }
        return url
    }

    func getIETFTag() -> String? {
        guard let languageCode else { return nil }
        return SubtitleLanguage.fromCodeToIETFTag(languageCode)
    }
}

// MARK: - ExtractorUri (local file alternative to ExtractorLink)
struct ExtractorUri: Codable, Equatable, Hashable, Sendable {
    var uri: URL
    var name: String
    var basePath: String
    var relativePath: String
    var displayName: String
    var id: Int
    var parentId: Int?
    var episode: Int?
    var season: Int?
    var headerName: String?
    var tvType: TvType
}

typealias VideoLink = (link: ExtractorLink?, uri: ExtractorUri?)

struct BasicLink: Sendable {
    var url: String
    var name: String?
}

// MARK: - LinkLoadingResult
/// Mirrors ResultViewModel2.LinkLoadingResult (with the new episodes + page fields).
struct LinkLoadingResult {
    var links: [ExtractorLink]
    var subs: [SubtitleData]
    var syncData: [String: String]
    var episodes: [ResultEpisode]
    var page: LoadResponse?
}

struct ResultEpisode: Identifiable, Equatable {
    var id: Int
    var name: String?
    var season: Int
    var episode: Int
    var posterUrl: String?
    var data: Episode
    var description: String?
}

// MARK: - DisplayLink / priority
struct DisplayLink: Equatable, Sendable {
    var link: VideoLink
    var shouldUseLink: Bool
    var priority: Int
}

// MARK: - VideoSkipStamp (anime skip intro/outro)
struct VideoSkipStamp: Codable, Equatable, Identifiable, Sendable {
    var startTime: Double
    var endTime: Double
    var kind: Kind

    enum Kind: Int, Codable, Sendable {
        case intro = 0
        case outro = 1
    }

    var id: String { "\(kind.rawValue)-\(startTime)-\(endTime)" }
    var isFiller: Bool { false }
}

// MARK: - LoadTypes for generators
enum LoadType: String, Sendable {
    case inApp = "inapp"
    case inAppDownload = "inapp_download"
    case chromecast = "chromecast"
    case all = "all"

    var sourceTypes: Set<ExtractorLinkType> {
        switch self {
        case .inApp: return ExtractorLinkType.loadTypeInApp
        case .inAppDownload: return ExtractorLinkType.loadTypeInAppDownload
        case .chromecast: return ExtractorLinkType.loadTypeChromecast
        case .all: return Set(ExtractorLinkType.allCases)
        }
    }
}

// MARK: - Player events (mirror IPlayer.kt)
enum CSPlayerEvent {
    case pause
    case play
    case seekForward
    case seekBack
    case skipCurrentChapter
    case nextEpisode
    case prevEpisode
    case playPauseToggle
    case toggleMute
    case restart
    case playAsAudio
}

enum CSPlayerLoading {
    case isPaused
    case isPlaying
    case isBuffering
    case isEnded
}

enum PlayerEventSource: String, Sendable {
    case ui = "UI"
    case player = "Player"
    case sync = "Sync"
}

enum PlayerEvent {
    case position(positionMs: Int64, durationMs: Int64, source: PlayerEventSource)
    case status(status: CSPlayerLoading, source: PlayerEventSource)
    case error(message: String)
    case timestampInvoked(stamp: VideoSkipStamp)
    case timestampSkipped(stamp: VideoSkipStamp)
    case episodeSeek(delta: Int, source: PlayerEventSource)
    case resized(PlayerResize)
    case videoEnded
    case tracksChanged(current: CurrentTracks)
    case embeddedSubtitlesFetched(subtitles: [SubtitleData])
    case playerAttached
    case subtitlesUpdated
    case requestAudioFocus
    case pauseEvent
    case playEvent
    case download(bytesDownloaded: Int64, bytesTotal: Int64, downloadSpeed: Int64, connections: Int)
}

enum PlayerResize: String, Codable, Sendable {
    case fit = "fit"
    case fill = "fill"
    case zoom = "zoom"
}

// MARK: - Tracks
struct VideoTrack: Codable, Equatable, Sendable {
    var language: String?
    var id: Int
    var width: Int?
    var height: Int?
    var format: String?
    var label: String?
}

struct AudioTrack: Codable, Equatable, Sendable {
    var language: String?
    var id: Int
    var format: String?
    var channelCount: Int?
    var label: String?
}

struct TextTrack: Codable, Equatable, Sendable {
    var language: String?
    var id: Int
    var label: String?
}

struct CurrentTracks: Codable, Equatable, Sendable {
    var video: VideoTrack?
    var audio: AudioTrack?
    var text: TextTrack?
}

// MARK: - SkipAPI stamp result
struct VideoStampsResponse: Codable, Sendable {
    var results: [VideoStampResult]

    struct VideoStampResult: Codable, Sendable {
        var interval: Interval
        var skipType: String?

        struct Interval: Codable, Sendable {
            var startTime: Double
            var endTime: Double
        }
    }
}

// MARK: - Subtitle search entities (SubtitlesFragment / providers)
struct SubtitleSearch: Sendable {
    var query: String
    var season: Int?
    var episode: Int?
    var isMovie: Bool
    var language: String?
}

struct SubtitleEntity: Identifiable, Sendable {
    var id: String
    var name: String
    var language: String
    var url: String?
    var type: SubtitleEntityType
    var resource: SubtitleResource?

    enum SubtitleEntityType: Int, Sendable {
        case file = 0
        case external = 1
        case broadcast = 2
    }
}

struct SubtitleResource: Sendable {
    var name: String
    var url: String
    var searchLanguages: [String]
}

// MARK: - Subtitle language helpers
enum SubtitleLanguage {
    static func fromCodeToIETFTag(_ code: String) -> String? {
        if code.count <= 3 { return code }
        let components = code.split(separator: "-").map(String.init)
        guard let first = components.first, first.count <= 3 else { return nil }
        return components.joined(separator: "-")
    }
}