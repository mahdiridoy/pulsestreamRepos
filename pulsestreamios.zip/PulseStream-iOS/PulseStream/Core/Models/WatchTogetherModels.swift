import Foundation

// MARK: - Watch Together Models
/// Mirrors WatchTogetherManager.kt data classes.

enum WatchTogetherRole: String, Codable, Sendable {
    case none = "NONE"
    case host = "HOST"
    case viewer = "VIEWER"

    var wireValue: String? {
        switch self {
        case .host: return "host"
        case .viewer: return "viewer"
        case .none: return nil
        }
    }
}

struct RoomInfo: Codable, Sendable {
    var roomName: String
    var roomCode: String
    var hostToken: String
}

struct RoomUser: Codable, Equatable, Sendable {
    var role: WatchTogetherRole
    var name: String
}

struct ContentInfo: Codable, Equatable, Sendable {
    var url: String
    var apiName: String
    var name: String
    var episodeId: Int?
    var episode: Int?
    var season: Int?

    /// Mirrors `sameContent` dedup: url + apiName + episodeId.
    func sameContent(as other: ContentInfo?) -> Bool {
        guard let other else { return false }
        return url == other.url && apiName == other.apiName && episodeId == other.episodeId
    }
}

struct NavigateInfo: Codable, Equatable, Sendable {
    var destination: String
    var url: String?
    var apiName: String?
    var name: String?

    func sameAs(_ other: NavigateInfo?) -> Bool {
        guard let other else { return false }
        return destination == other.destination && url == other.url &&
               apiName == other.apiName && name == other.name
    }
}

struct RoomStatePayload: Codable, Sendable {
    var contentId: String?
    var episodeId: String?
    var contentUrl: String?
    var apiName: String?
    var name: String?
    var episode: Int?
    var season: Int?
    var position: Int64
    var playing: Bool
}

// MARK: - Wire message parsing
/// The messages exchanged over the Watch Together WebSocket.
enum WatchTogetherMessage {
    case connected(room: String, roomName: String, role: String, name: String)
    case roomState(state: RoomStatePayload)
    case openContent(url: String, apiName: String?, name: String, position: Int64, playing: Bool,
                     episodeId: Any?, episode: Any?, season: Any?)
    case play(position: Int64)
    case pause(position: Int64)
    case seek(position: Int64)
    case roomUsers(users: [RoomUser])
    case userJoined(role: String, name: String)
    case userDisconnected(role: String, name: String)
    case navigate(destination: String, url: String?, apiName: String?, name: String?)
    case roomClosed
    case error(message: String)
    case unknown

    static func parse(_ json: [String: Any]) -> WatchTogetherMessage {
        guard let type = json["type"] as? String else { return .unknown }
        switch type {
        case "CONNECTED":
            return .connected(room: json["room"] as? String ?? "",
                              roomName: json["roomName"] as? String ?? "",
                              role: json["role"] as? String ?? "",
                              name: json["name"] as? String ?? "")
        case "ROOM_STATE":
            guard let state = json["state"] as? [String: Any] else { return .unknown }
            return .roomState(state: RoomStatePayload(
                contentId: state["contentId"] as? String,
                episodeId: state["episodeId"] as? String,
                contentUrl: state["contentUrl"] as? String,
                apiName: state["apiName"] as? String,
                name: state["name"] as? String,
                episode: (state["episode"] as? NSNumber)?.intValue,
                season: (state["season"] as? NSNumber)?.intValue,
                position: (state["position"] as? NSNumber)?.int64Value ?? 0,
                playing: state["playing"] as? Bool ?? false))
        case "OPEN_CONTENT":
            return .openContent(url: json["contentUrl"] as? String ?? "",
                                apiName: json["apiName"] as? String,
                                name: json["name"] as? String ?? "",
                                position: (json["position"] as? NSNumber)?.int64Value ?? 0,
                                playing: json["playing"] as? Bool ?? false,
                                episodeId: json["episodeId"],
                                episode: json["episode"],
                                season: json["season"])
        case "PLAY":
            return .play(position: (json["position"] as? NSNumber)?.int64Value ?? 0)
        case "PAUSE":
            return .pause(position: (json["position"] as? NSNumber)?.int64Value ?? 0)
        case "SEEK":
            return .seek(position: (json["position"] as? NSNumber)?.int64Value ?? 0)
        case "ROOM_USERS":
            let users: [RoomUser] = (json["users"] as? [[String: Any]] ?? []).compactMap { dict in
                guard let name = dict["name"] as? String else { return nil }
                let role: WatchTogetherRole = (dict["role"] as? String) == "host" ? .host : .viewer
                return RoomUser(role: role, name: name)
            }
            return .roomUsers(users: users)
        case "USER_JOINED":
            return .userJoined(role: json["role"] as? String ?? "viewer", name: json["name"] as? String ?? "")
        case "USER_DISCONNECTED":
            return .userDisconnected(role: json["role"] as? String ?? "viewer", name: json["name"] as? String ?? "")
        case "NAVIGATE":
            return .navigate(destination: json["destination"] as? String ?? "",
                             url: json["url"] as? String,
                             apiName: json["apiName"] as? String,
                             name: json["name"] as? String)
        case "ROOM_CLOSED":
            return .roomClosed
        case "ERROR":
            return .error(message: json["message"] as? String ?? "Unknown error")
        default:
            return .unknown
        }
    }
}

// MARK: - Outgoing payload builders
enum WatchTogetherOutbound {
    static func play(position: Int64) -> [String: Any] {
        ["type": "PLAY", "position": position]
    }
    static func pause(position: Int64) -> [String: Any] {
        ["type": "PAUSE", "position": position]
    }
    static func seek(position: Int64) -> [String: Any] {
        ["type": "SEEK", "position": position]
    }
    static func openContent(url: String, apiName: String?, name: String, position: Int64, playing: Bool,
                            episodeId: Int?, episode: Int?, season: Int?) -> [String: Any] {
        var dict: [String: Any] = [
            "type": "OPEN_CONTENT",
            "contentUrl": url,
            "name": name,
            "position": position,
            "playing": playing
        ]
        if let apiName { dict["apiName"] = apiName }
        if let episodeId { dict["episodeId"] = episodeId }
        if let episode { dict["episode"] = episode }
        if let season { dict["season"] = season }
        return dict
    }
    static func navigate(destination: String, url: String?, apiName: String?, name: String?) -> [String: Any] {
        var dict: [String: Any] = ["type": "NAVIGATE", "destination": destination]
        if let url { dict["url"] = url }
        if let apiName { dict["apiName"] = apiName }
        if let name { dict["name"] = name }
        return dict
    }
}