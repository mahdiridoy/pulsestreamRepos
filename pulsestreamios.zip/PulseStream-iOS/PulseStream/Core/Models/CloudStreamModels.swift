import Foundation
import Combine

// MARK: - TvType
/// Mirrors `TvType` in the Android MainAPI.
enum TvType: Int, Codable, CaseIterable, Sendable {
    case movie = 1
    case animeMovie = 2
    case tvSeries = 3
    case cartoon = 4
    case anime = 5
    case ova = 6
    case torrent = 7
    case documentary = 8
    case asianDrama = 9
    case live = 10
    case nsfw = 11
    case others = 12
    case music = 13
    case audioBook = 14
    case customMedia = 15
    case audio = 16
    case podcast = 17
    case video = 18

    var isMovie: Bool { self == .movie || self == .animeMovie }
    var isAudio: Bool { self == .audio || self == .podcast || self == .audioBook }
    var isLiveStream: Bool { self == .live }
    var isAnimeOp: Bool { self == .animeMovie || self == .anime || self == .ova }
    var isAnimeBased: Bool { self == .anime || self == .animeMovie || self == .cartoon || self == .ova || self == .asianDrama }
    var isEpisodeBased: Bool { !isMovie && !isAudio && !isLiveStream }

    var displayName: String {
        switch self {
        case .movie: return "Movie"
        case .animeMovie: return "Anime Movie"
        case .tvSeries: return "TV Series"
        case .cartoon: return "Cartoon"
        case .anime: return "Anime"
        case .ova: return "OVA"
        case .torrent: return "Torrent"
        case .documentary: return "Documentary"
        case .asianDrama: return "Asian Drama"
        case .live: return "Live"
        case .nsfw: return "NSFW"
        case .others: return "Other"
        case .music: return "Music"
        case .audioBook: return "Audio Book"
        case .customMedia: return "Custom Media"
        case .audio: return "Audio"
        case .podcast: return "Podcast"
        case .video: return "Video"
        }
    }

    /// Mirror of `getFolderPrefix`.
    var folderPrefix: String {
        switch self {
        case .movie: return "movies"
        case .animeMovie: return "animemovies"
        case .tvSeries: return "series"
        case .cartoon: return "cartoon"
        case .anime: return "anime"
        case .ova: return "ova"
        case .torrent: return "torrent"
        case .documentary: return "documentary"
        case .asianDrama: return "asiandrama"
        case .live: return "live"
        case .nsfw: return "nsfw"
        case .others: return "others"
        case .music: return "music"
        case .audioBook: return "audiobook"
        case .customMedia: return "custom"
        case .audio: return "audio"
        case .podcast: return "podcast"
        case .video: return "video"
        }
    }
}

// MARK: - Score
/// Mirrors the fixed-point `Score` type used by providers.
struct Score: Codable, Equatable, Sendable {
    static let max: Int = 1_000_000_000
    static let min: Int = 0
    static let maxZeros: Int = 9

    let value: Int

    init(value: Int) { self.value = Swift.min(Swift.max(value, Score.min), Score.max) }
    init(fromInt: Int) { self.value = Swift.min(Swift.max(fromInt, 0), 10) }
    init(from5: Int) { self.value = Swift.min(Swift.max(from5 * 100_000_000, 0), Score.max) }
    init(from10: Double) { self.value = Swift.min(Swift.max(Int((from10 * 100_000_000).rounded()), 0), Score.max) }
    init(from100: Int) { self.value = Swift.min(Swift.max(from100 * 10_000_000, 0), Score.max) }
    init(fromString: String) {
        if let int = Int(fromString) { self.init(from100: int) } else if let dbl = Double(fromString) { self.init(from10: dbl) } else { self.value = 0 }
    }

    var toInt: Int { value / 100_000_000 }
    var toFloat: Float { Float(value) / 100_000_000.0 }
    var toDouble: Double { Double(value) / 100_000_000.0 }
    var toRating: Double { (toDouble * 2).rounded() / 2 }
    var isUnrated: Bool { value == 0 }

    /// String form with at most 9 significant digits, no trailing zeros (mirrors Kotlin).
    var stringValue: String {
        guard value > 0 else { return "0" }
        let full = "\(value)"
        let zeros = Swift.max(0, Score.maxZeros - (full.count - 1))
        if zeros >= 0 && value % 1_000_000_000 == 0 { return "\(value / 1_000_000_000)" }
        let s = String(format: "%.2f", toDouble)
        return s
    }

    static let unrated = Score(value: 0)
}

// MARK: - SearchResponse
/// Mirrors the `SearchResponse` hierarchy.
class SearchResponse: Codable, Identifiable, ObservableObject, Equatable, Hashable {
    let id: String
    var name: String
    var url: String
    var apiName: String?
    var posterUrl: String?
    var year: Int?
    var score: Score
    var isAdult: Bool
    var quality: String?
    var lang: String?
    var type: TvType
    var posterHeaders: [String: String]?

    init(id: String, name: String, url: String, apiName: String? = nil, posterUrl: String? = nil,
         year: Int? = nil, score: Score = .unrated, isAdult: Bool = false, quality: String? = nil,
         lang: String? = nil, type: TvType = .movie, posterHeaders: [String: String]? = nil) {
        self.id = id
        self.name = name
        self.url = url
        self.apiName = apiName
        self.posterUrl = posterUrl
        self.year = year
        self.score = score
        self.isAdult = isAdult
        self.quality = quality
        self.lang = lang
        self.type = type
        self.posterHeaders = posterHeaders
    }

    static func == (lhs: SearchResponse, rhs: SearchResponse) -> Bool { lhs.id == rhs.id && lhs.apiName == rhs.apiName }
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(apiName)
    }
}

final class MovieSearchResponse: SearchResponse {
    init(id: String, name: String, url: String, apiName: String? = nil, posterUrl: String? = nil,
         year: Int? = nil, score: Score = .unrated, isAdult: Bool = false, quality: String? = nil,
         lang: String? = nil, type: TvType = .movie) {
        super.init(id: id, name: name, url: url, apiName: apiName, posterUrl: posterUrl, year: year,
                   score: score, isAdult: isAdult, quality: quality, lang: lang, type: type)
    }
    required init(from decoder: Decoder) throws { try super.init(from: decoder) }
}

final class TvSeriesSearchResponse: SearchResponse {
    var genre: String?
    var isShort: Bool = false
    init(id: String, name: String, url: String, apiName: String? = nil, posterUrl: String? = nil,
         year: Int? = nil, score: Score = .unrated, isAdult: Bool = false, quality: String? = nil,
         lang: String? = nil, genre: String? = nil, isShort: Bool = false) {
        self.genre = genre
        self.isShort = isShort
        super.init(id: id, name: name, url: url, apiName: apiName, posterUrl: posterUrl, year: year,
                   score: score, isAdult: isAdult, quality: quality, lang: lang, type: .tvSeries)
    }
    required init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        genre = try c.decodeIfPresent(String.self, forKey: .genre)
        isShort = try c.decodeIfPresent(Bool.self, forKey: .isShort) ?? false
        try super.init(from: decoder)
    }
    override func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encodeIfPresent(genre, forKey: .genre)
        try c.encode(isShort, forKey: .isShort)
        try super.encode(to: encoder)
    }
    private enum CodingKeys: String, CodingKey { case genre, isShort }
}

// MARK: - HomePageResponse
struct HomePageResponse: Codable {
    var items: [HomePageList]
    var hasNext: Bool
}

struct HomePageList: Codable, Identifiable {
    var id: String { name }
    var name: String
    var list: [SearchResponse]
    var isHorizontalImages: Bool = false
}

struct SearchResponseList {
    var items: [SearchResponse]
    var hasNext: Bool
    var isHorizontalImages: Bool = false
}

// MARK: - LoadResponse
/// Mirrors the `LoadResponse` sealed hierarchy.
class LoadResponse: Codable, Identifiable, ObservableObject, Equatable, Hashable {
    let url: String
    let apiName: String?
    let name: String
    var type: TvType
    var posterUrl: String?
    var year: Int?
    var plot: String?
    var tags: [String] = []
    var score: Score = .unrated
    var duration: Int = 0
    var trailerUrls: [String] = []
    var recommendations: [SearchResponse] = []
    var contentRating: String?
    var actors: [Actor] = []
    var imdbId: String?
    var simklId: String?
    var traktId: String?
    var posterHeaders: [String: String]?
    var backgroundPosterUrl: String?
    var logoUrl: String?
    var comingSoon: Bool = false
    var showStatus: ShowStatus = .ongoing
    private var _seasonNames: [String] = []
    var seasonNames: [String] {
        get { _seasonNames }
        set { _seasonNames = newValue }
    }
    var syncData: SyncStatusData?

    init(url: String, apiName: String?, name: String, type: TvType, posterUrl: String? = nil, year: Int? = nil,
         plot: String? = nil, tags: [String] = [], score: Score = .unrated, duration: Int = 0,
         trailerUrls: [String] = [], recommendations: [SearchResponse] = [], contentRating: String? = nil,
         imdbId: String? = nil, simklId: String? = nil, traktId: String? = nil, posterHeaders: [String: String]? = nil,
         backgroundPosterUrl: String? = nil, logoUrl: String? = nil, comingSoon: Bool = false,
         showStatus: ShowStatus = .ongoing, seasonNames: [String] = []) {
        self.url = url
        self.apiName = apiName
        self.name = name
        self.type = type
        self.posterUrl = posterUrl
        self.year = year
        self.plot = plot
        self.tags = tags
        self.score = score
        self.duration = duration
        self.trailerUrls = trailerUrls
        self.recommendations = recommendations
        self.contentRating = contentRating
        self.imdbId = imdbId
        self.simklId = simklId
        self.traktId = traktId
        self.posterHeaders = posterHeaders
        self.backgroundPosterUrl = backgroundPosterUrl
        self.logoUrl = logoUrl
        self.comingSoon = comingSoon
        self.showStatus = showStatus
        self.seasonNames = seasonNames
    }

    static func == (lhs: LoadResponse, rhs: LoadResponse) -> Bool { lhs.url == rhs.url && lhs.apiName == rhs.apiName }
    func hash(into hasher: inout Hasher) {
        hasher.combine(url)
        hasher.combine(apiName)
    }
}

/// Lightweight persisted sync status payload attached to loaded content.
struct SyncStatusData: Codable, Equatable, Sendable {
    var synced: Bool
    var status: SyncStatus?
    var score: Int
    var episodeNumber: Int?
    var isRewatched: Bool
}

final class MovieLoadResponse: LoadResponse {
    init(url: String, apiName: String? = nil, name: String, posterUrl: String? = nil, year: Int? = nil,
         plot: String? = nil, tags: [String] = [], score: Score = .unrated, duration: Int = 0,
         trailerUrls: [String] = [], recommendations: [SearchResponse] = [], contentRating: String? = nil,
         imdbId: String? = nil, simklId: String? = nil, traktId: String? = nil, posterHeaders: [String: String]? = nil,
         backgroundPosterUrl: String? = nil, logoUrl: String? = nil, comingSoon: Bool = false) {
        super.init(url: url, apiName: apiName, name: name, type: .movie, posterUrl: posterUrl, year: year,
                   plot: plot, tags: tags, score: score, duration: duration, trailerUrls: trailerUrls,
                   recommendations: recommendations, contentRating: contentRating, imdbId: imdbId,
                   simklId: simklId, traktId: traktId, posterHeaders: posterHeaders,
                   backgroundPosterUrl: backgroundPosterUrl, logoUrl: logoUrl, comingSoon: comingSoon)
    }
    required init(from decoder: Decoder) throws { try super.init(from: decoder) }
}

final class TvSeriesLoadResponse: LoadResponse {
    var episodes: [Episode] = []

    init(url: String, apiName: String? = nil, name: String, posterUrl: String? = nil, year: Int? = nil,
         plot: String? = nil, tags: [String] = [], score: Score = .unrated, duration: Int = 0,
         trailerUrls: [String] = [], recommendations: [SearchResponse] = [], contentRating: String? = nil,
         imdbId: String? = nil, simklId: String? = nil, traktId: String? = nil, posterHeaders: [String: String]? = nil,
         backgroundPosterUrl: String? = nil, logoUrl: String? = nil, comingSoon: Bool = false,
         episodes: [Episode] = []) {
        self.episodes = episodes
        super.init(url: url, apiName: apiName, name: name, type: .tvSeries, posterUrl: posterUrl, year: year,
                   plot: plot, tags: tags, score: score, duration: duration, trailerUrls: trailerUrls,
                   recommendations: recommendations, contentRating: contentRating, imdbId: imdbId,
                   simklId: simklId, traktId: traktId, posterHeaders: posterHeaders,
                   backgroundPosterUrl: backgroundPosterUrl, logoUrl: logoUrl, comingSoon: comingSoon)
    }
    required init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        episodes = try c.decodeIfPresent([Episode].self, forKey: .episodes) ?? []
        try super.init(from: decoder)
    }
    override func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(episodes, forKey: .episodes)
        try super.encode(to: encoder)
    }
    private enum CodingKeys: String, CodingKey { case episodes }

    var totalEpisodeIndex: Int {
        var count = 0
        for episode in episodes { count += episode.episode }
        return count
    }
}

final class AnimeLoadResponse: LoadResponse {
    var episodes: [Int: [Episode]] = [:]
    private var _animeSeasonNames: [String] = []
    override var seasonNames: [String] {
        get { _animeSeasonNames }
        set { _animeSeasonNames = newValue }
    }

    init(url: String, apiName: String? = nil, name: String, posterUrl: String? = nil, year: Int? = nil,
         plot: String? = nil, tags: [String] = [], score: Score = .unrated, duration: Int = 0,
         trailerUrls: [String] = [], recommendations: [SearchResponse] = [], contentRating: String? = nil,
         imdbId: String? = nil, simklId: String? = nil, traktId: String? = nil,
         posterHeaders: [String: String]? = nil, backgroundPosterUrl: String? = nil,
         logoUrl: String? = nil, comingSoon: Bool = false, episodes: [Int: [Episode]] = [:],
         seasonNames: [String] = []) {
        self.episodes = episodes
        self.seasonNames = seasonNames
        super.init(url: url, apiName: apiName, name: name, type: .anime, posterUrl: posterUrl, year: year,
                   plot: plot, tags: tags, score: score, duration: duration, trailerUrls: trailerUrls,
                   recommendations: recommendations, contentRating: contentRating, imdbId: imdbId,
                   simklId: simklId, traktId: traktId, posterHeaders: posterHeaders,
                   backgroundPosterUrl: backgroundPosterUrl, logoUrl: logoUrl, comingSoon: comingSoon)
    }
    required init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        episodes = try c.decodeIfPresent([Int: [Episode]].self, forKey: .episodes) ?? [:]
        seasonNames = try c.decodeIfPresent([String].self, forKey: .seasonNames) ?? []
        try super.init(from: decoder)
    }
    override func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(episodes, forKey: .episodes)
        try c.encode(seasonNames, forKey: .seasonNames)
        try super.encode(to: encoder)
    }
    private enum CodingKeys: String, CodingKey { case episodes, seasonNames }
}

final class LiveStreamLoadResponse: LoadResponse {
    var liveUrl: String?

    init(url: String, apiName: String? = nil, name: String, posterUrl: String? = nil, year: Int? = nil,
         plot: String? = nil, tags: [String] = [], score: Score = .unrated, duration: Int = 0,
         trailerUrls: [String] = [], recommendations: [SearchResponse] = [], contentRating: String? = nil,
         imdbId: String? = nil, simklId: String? = nil, traktId: String? = nil,
         posterHeaders: [String: String]? = nil, backgroundPosterUrl: String? = nil,
         logoUrl: String? = nil, comingSoon: Bool = false, liveUrl: String? = nil) {
        self.liveUrl = liveUrl
        super.init(url: url, apiName: apiName, name: name, type: .live, posterUrl: posterUrl, year: year,
                   plot: plot, tags: tags, score: score, duration: duration, trailerUrls: trailerUrls,
                   recommendations: recommendations, contentRating: contentRating, imdbId: imdbId,
                   simklId: simklId, traktId: traktId, posterHeaders: posterHeaders,
                   backgroundPosterUrl: backgroundPosterUrl, logoUrl: logoUrl, comingSoon: comingSoon)
    }
    required init(from decoder: Decoder) throws { try super.init(from: decoder) }
}

final class TorrentLoadResponse: LoadResponse {
    init(url: String, apiName: String? = nil, name: String, posterUrl: String? = nil, year: Int? = nil,
         plot: String? = nil, tags: [String] = [], score: Score = .unrated, duration: Int = 0,
         trailerUrls: [String] = [], recommendations: [SearchResponse] = [], contentRating: String? = nil,
         imdbId: String? = nil, simklId: String? = nil, traktId: String? = nil,
         posterHeaders: [String: String]? = nil, backgroundPosterUrl: String? = nil,
         logoUrl: String? = nil, comingSoon: Bool = false) {
        super.init(url: url, apiName: apiName, name: name, type: .torrent, posterUrl: posterUrl, year: year,
                   plot: plot, tags: tags, score: score, duration: duration, trailerUrls: trailerUrls,
                   recommendations: recommendations, contentRating: contentRating, imdbId: imdbId,
                   simklId: simklId, traktId: traktId, posterHeaders: posterHeaders,
                   backgroundPosterUrl: backgroundPosterUrl, logoUrl: logoUrl, comingSoon: comingSoon)
    }
    required init(from decoder: Decoder) throws { try super.init(from: decoder) }
}

// MARK: - Episode
/// Mirrors `Episode` in the Android MainAPI.
class Episode: Codable, Identifiable, ObservableObject, Equatable, Hashable {
    var id: Int
    var name: String?
    var season: Int
    var episode: Int
    var posterUrl: String?
    var score: Score = .unrated
    var description: String?
    var date: Date?
    var runTime: Int?
    var url: String?

    init(id: Int, name: String? = nil, season: Int, episode: Int, posterUrl: String? = nil,
         score: Score = .unrated, description: String? = nil, date: Date? = nil, runTime: Int? = nil) {
        self.id = id
        self.name = name
        self.season = season
        self.episode = episode
        self.posterUrl = posterUrl
        self.score = score
        self.description = description
        self.date = date
        self.runTime = runTime
    }

    static func == (lhs: Episode, rhs: Episode) -> Bool { lhs.id == rhs.id && lhs.season == rhs.season && lhs.episode == rhs.episode }
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(season)
        hasher.combine(episode)
    }
}

// MARK: - Enums
enum ShowStatus: String, Codable, CaseIterable, Sendable {
    case completed = "Completed"
    case ongoing = "Ongoing"
    case upcoming = "Upcoming"
    case cancelled = "Cancelled"
    case unreturning = "Unreturning"
}

enum DubStatus: Int, Codable, CaseIterable, Sendable {
    case none = -1
    case subbed = 0
    case dubbed = 1
}

enum ScoreLevel: Double, CaseIterable, Sendable {
    case unrated = -1
    case terrible = 0
    case veryBad = 1
    case bad = 2
    case belowAverage = 3
    case average = 4
    case good = 5
    case veryGood = 6
    case great = 7
    case superb = 8
    case masterpiece = 9
}

enum VPNStatus: String, Codable, Sendable {
    case none = "None"
    case mightBeNeeded = "MightBeNeeded"
    case torrent = "Torrent"
}

enum ProviderType: String, Codable, Sendable {
    case metaProvider = "MetaProvider"
    case directProvider = "DirectProvider"
}

enum TrackerType: String, Codable, CaseIterable, Sendable {
    case mal = "MyAnimeList"
    case anilist = "Anilist"
    case kitsu = "Kitsu"
    case simkl = "Simkl"
    case trakt = "Trakt"
    case imdb = "Imdb"
    case openSubtitles = "OpenSubtitles"

    static func types(for tvType: TvType) -> [TrackerType] {
        switch tvType {
        case .movie: return [.mal, .anilist, .kitsu, .simkl, .trakt, .imdb]
        case .tvSeries: return [.mal, .anilist, .kitsu, .simkl, .trakt, .imdb]
        case .anime, .animeMovie, .ova, .cartoon: return [.mal, .anilist, .kitsu, .simkl, .trakt, .imdb]
        default: return []
        }
    }
}

enum SyncIdName: String, Codable, CaseIterable, Sendable {
    case anilist = "Anilist"
    case myAnimeList = "MyAnimeList"
    case kitsu = "Kitsu"
    case trakt = "Trakt"
    case imdb = "Imdb"
    case simkl = "Simkl"
    case localList = "LocalList"
}

enum SyncStatus: String, Codable, CaseIterable, Sendable {
    case completed = "Completed"
    case completedRepeating = "CompletedRepeating"
    case currently = "Currently"
    case dropped = "Dropped"
    case onHold = "OnHold"
    case planTo = "PlanTo"
}

// MARK: - Subtitle & Audio files
struct SubtitleFile: Codable, Equatable, Hashable, Sendable {
    var lang: String?
    var name: String
    var url: String?
    var headers: [String: String]?
}

struct AudioFile: Codable, Equatable, Hashable, Sendable {
    var lang: String?
    var name: String
    var url: String
}

// MARK: - Torrent
struct Torrent: Codable, Equatable, Hashable, Sendable {
    var name: String
    var size: Long?
    var hash: String
    var magnet: String?
    var seeders: Int?
    var leechers: Int?
    var file: String?
    var quality: String?

    struct Long: Codable, Equatable, Hashable, Sendable {
        var value: Int64
        init(_ v: Int64) { value = v }
    }
}

// MARK: - Actor
struct Actor: Codable, Equatable, Hashable, Sendable {
    var name: String
    var photoUrl: String?
}

// MARK: - Sync providers helper
struct LibraryMetadata: Codable, Identifiable, Equatable, Sendable {
    var id: String
    var name: String
    var score: Int
    var status: SyncStatus?
    var lastEpisodeWatched: Int?
    var url: String?
    var posterUrl: String?
}

struct SyncResult: Codable, Equatable, Sendable {
    var url: String?
    var posterUrl: String?
    var name: String?
    var year: Int?
    var lastEpisode: String?
}
