import Foundation

/// Mirrors the Android BuildConfig fields (SIMKL_CLIENT_ID, MAL_KEY, ANILIST_KEY, etc.)
/// Keys come from the build environment / local config, matching how Android reads
/// System.getenv(...) ?: local.properties.
enum AppConfig {
    static let simklClientId = env("SIMKL_CLIENT_ID") ?? ""
    static let simklClientSecret = env("SIMKL_CLIENT_SECRET") ?? ""
    static let malKey = env("MAL_KEY") ?? ""
    static let anilistKey = env("ANILIST_KEY") ?? ""

    static let isDebug: Bool = {
        #if DEBUG
        return true
        #else
        return false
        #endif
    }()

    static let versionName = "1.0.0.2"
    static let versionCode = 3

    private static func env(_ key: String) -> String? {
        if let value = ProcessInfo.processInfo.environment[key], !value.isEmpty {
            return value
        }
        // Mirror local.properties keys: simkl.id, simkl.secret, mal.key, anilist.key
        guard let path = Bundle.main.path(forResource: "local", ofType: "properties") else { return nil }
        guard let content = try? String(contentsOfFile: path, encoding: .utf8) else { return nil }
        let mapping = ["simkl.id": "SIMKL_CLIENT_ID",
                       "simkl.secret": "SIMKL_CLIENT_SECRET",
                       "mal.key": "MAL_KEY",
                       "anilist.key": "ANILIST_KEY"]
        for line in content.components(separatedBy: .newlines) {
            let parts = line.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            guard parts.count == 2 else { continue }
            if let target = mapping[parts[0]], target == key {
                return parts[1]
            }
        }
        return nil
    }
}

/// The app package name used for OAuth deep-link redirect strings (mirrors APP_STRING).
enum AppPackage {
    static let app = "pulsestreamapp"
    static let appRepo = "\(app)_repo"
    static let appPlayer = "\(app)_player"
    static let appSearch = "\(app)_search"
    static let appResumeWatching = "\(app)_resume_watching"
    static let appShare = "\(app)_share"
    static let appOAuth = "\(app)_oauth"
}
