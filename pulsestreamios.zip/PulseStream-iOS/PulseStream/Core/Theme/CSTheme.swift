import SwiftUI
import UIKit

// MARK: - Theme (mirrors the Android theme engine + colors.xml)
enum CSTheme: String, CaseIterable, Identifiable {
    case amoledLight = "AmoledLight"
    case black = "Black"
    case amoled = "Amoled"
    case light = "Light"
    case system = "System"
    case monet = "Monet"
    case dracula = "Dracula"
    case lavender = "Lavender"
    case silentBlue = "SilentBlue"

    var id: String { rawValue }
    var displayName: String {
        switch self {
        case .amoledLight: return "Dark"
        case .black: return "Gray"
        case .amoled: return "Amoled"
        case .light: return "Flashbang"
        case .system: return "System"
        case .monet: return "Material You"
        case .dracula: return "Dracula"
        case .lavender: return "Lavender Dreams"
        case .silentBlue: return "Silent Blue"
        }
    }

    var isDark: Bool {
        switch self {
        case .light: return false
        case .system: return UITraitCollection.current.userInterfaceStyle == .dark
        default: return true
        }
    }
}

enum CSPrimaryColor: String, CaseIterable, Identifiable {
    case normal = "Normal"
    case dandelionYellow = "DandelionYellow"
    case carnationPink = "CarnationPink"
    case orange = "Orange"
    case darkGreen = "DarkGreen"
    case maroon = "Maroon"
    case navyBlue = "NavyBlue"
    case grey = "Grey"
    case white = "White"
    case coolBlue = "CoolBlue"
    case brown = "Brown"
    case blue = "Blue"
    case red = "Red"
    case purple = "Purple"
    case green = "Green"
    case greenApple = "GreenApple"
    case banana = "Banana"
    case party = "Party"
    case pink = "Pink"
    case lavender = "Lavender"
    case monet = "Monet"
    case monet2 = "Monet2"

    var id: String { rawValue }
    var displayName: String {
        switch self {
        case .normal: return "Normal"
        case .dandelionYellow: return "Dandelion Yellow"
        case .carnationPink: return "Carnation Pink"
        case .darkGreen: return "Dark Green"
        case .navyBlue: return "Navy Blue"
        case .grey: return "Grey"
        case .coolBlue: return "Cool Blue"
        case .greenApple: return "Apple"
        case .monet: return "Material You"
        case .monet2: return "Material You (Secondary)"
        default: return rawValue
        }
    }

    var uiColor: UIColor {
        switch self {
        case .normal: return UIColor(hex: 0x3D50FA)
        case .dandelionYellow: return UIColor(hex: 0xFFD500)
        case .carnationPink: return UIColor(hex: 0xFFB6C1)
        case .orange: return UIColor(hex: 0xFF6D00)
        case .darkGreen: return UIColor(hex: 0x1B5E20)
        case .maroon: return UIColor(hex: 0x880E4F)
        case .navyBlue: return UIColor(hex: 0x1A237E)
        case .grey: return UIColor(hex: 0x616161)
        case .white: return UIColor(hex: 0xFFFFFF)
        case .coolBlue: return UIColor(hex: 0x2962FF)
        case .brown: return UIColor(hex: 0x5D4037)
        case .blue: return UIColor(hex: 0x3B65F5)
        case .red: return UIColor(hex: 0xF44336)
        case .purple: return UIColor(hex: 0x9C27B0)
        case .green: return UIColor(hex: 0x4CAF50)
        case .greenApple: return UIColor(hex: 0x76FF03)
        case .banana: return UIColor(hex: 0xFFF176)
        case .party: return UIColor(hex: 0xFF4081)
        case .pink: return UIColor(hex: 0xE91E63)
        case .lavender: return UIColor(hex: 0x9575CD)
        case .monet, .monet2: return UIColor(hex: 0x6750A4)
        }
    }
}

/// Mirrors the palette in colors.xml.
struct CSColors {
    static let colorPrimary = UIColor(hex: 0x3D50FA)
    static let colorSearch = UIColor(hex: 0x303135)
    static let colorOngoing = UIColor(hex: 0xF53B66)
    static let primaryGrayBackground = UIColor(hex: 0x2B2C30)
    static let primaryBlackBackground = UIColor(hex: 0x111111)
    static let iconGrayBackground = UIColor(hex: 0x1C1C20)
    static let boxItemBackground = UIColor(hex: 0x161616)
    static let textColor = UIColor(hex: 0xE9EAEE)
    static let grayTextColor = UIColor(hex: 0x9BA0A4)
    static let grayShimmer = UIColor(hex: 0xDCDCDC)
    static let amoledModeLight = UIColor(hex: 0x121213)
    static let dubColorText = UIColor(hex: 0x121950)
    static let dubColorBg = UIColor(hex: 0x3B65F5)
    static let subColorText = UIColor(hex: 0x571711)
    static let subColorBg = UIColor(hex: 0xF53B66)
    static let typeColorText = UIColor(hex: 0xBEC8FF)
    static let typeColorBg = UIColor(hex: 0x3700B3)

    // Dracula palette
    static let draculaBackground = UIColor(hex: 0x282A36)
    static let draculaForeground = UIColor(hex: 0xF8F8F2)
    static let draculaPurple = UIColor(hex: 0xBD93F9)

    // Silent Blue palette
    static let silentBlueBackground = UIColor(hex: 0x192038)
    static let silentBluePrimary = UIColor(hex: 0x4C8DFF)

    // Lavender palette
    static let lavenderBackground = UIColor(hex: 0x2B2440)
    static let lavenderPrimary = UIColor(hex: 0x9D7BFF)

    static let lightBackground = UIColor(hex: 0xFFFFFF)
    static let lightText = UIColor(hex: 0x1B1B1B)
}

// MARK: - AppTheme environment
struct AppTheme {
    var isDark: Bool
    var primary: UIColor
    var background: UIColor
    var surface: UIColor
    var surfaceVariant: UIColor
    var text: UIColor
    var textSecondary: UIColor
    var accent: UIColor

    var colorScheme: ColorScheme { isDark ? .dark : .light }

    init(theme: CSTheme, primary: CSPrimaryColor) {
        isDark = theme.isDark
        self.primary = primary.uiColor

        switch theme {
        case .amoled:
            background = CSColors.primaryBlackBackground
            surface = CSColors.iconGrayBackground
            surfaceVariant = CSColors.boxItemBackground
        case .amoledLight:
            background = CSColors.amoledModeLight
            surface = CSColors.primaryGrayBackground
            surfaceVariant = CSColors.boxItemBackground
        case .black:
            background = CSColors.primaryGrayBackground
            surface = CSColors.iconGrayBackground
            surfaceVariant = CSColors.boxItemBackground
        case .light:
            background = CSColors.lightBackground
            surface = UIColor(hex: 0xF2F2F5)
            surfaceVariant = UIColor(hex: 0xE8E8EC)
        case .system:
            let dark = UITraitCollection.current.userInterfaceStyle == .dark
            background = dark ? CSColors.amoledModeLight : CSColors.lightBackground
            surface = dark ? CSColors.primaryGrayBackground : UIColor(hex: 0xF2F2F5)
            surfaceVariant = dark ? CSColors.boxItemBackground : UIColor(hex: 0xE8E8EC)
        case .monet:
            background = CSColors.amoledModeLight
            surface = CSColors.primaryGrayBackground
            surfaceVariant = CSColors.boxItemBackground
        case .dracula:
            background = CSColors.draculaBackground
            surface = UIColor(hex: 0x1E1F29)
            surfaceVariant = UIColor(hex: 0x3A3D4E)
        case .lavender:
            background = CSColors.lavenderBackground
            surface = UIColor(hex: 0x352C4F)
            surfaceVariant = UIColor(hex: 0x453A63)
        case .silentBlue:
            background = CSColors.silentBlueBackground
            surface = UIColor(hex: 0x232C49)
            surfaceVariant = UIColor(hex: 0x2E3A5C)
        }

        switch theme {
        case .light:
            text = CSColors.lightText
            textSecondary = UIColor(hex: 0x6B6B70)
        case .dracula:
            text = CSColors.draculaForeground
            textSecondary = UIColor(hex: 0xB8BCC9)
        default:
            text = CSColors.textColor
            textSecondary = CSColors.grayTextColor
        }

        if theme == .silentBlue { accent = CSColors.silentBluePrimary }
        else if theme == .lavender { accent = CSColors.lavenderPrimary }
        else if theme == .dracula { accent = CSColors.draculaPurple }
        else { accent = primary.uiColor }
    }
}

// MARK: - SwiftUI environment key
private struct AppThemeKey: EnvironmentKey {
    static let defaultValue = AppTheme(theme: .amoledLight, primary: .normal)
}

extension EnvironmentValues {
    var appTheme: AppTheme {
        get { self[AppThemeKey.self] }
        set { self[AppThemeKey.self] = newValue }
    }
}

extension UIColor {
    convenience init(hex: Int) {
        self.init(red: CGFloat((hex >> 16) & 0xFF) / 255.0,
                  green: CGFloat((hex >> 8) & 0xFF) / 255.0,
                  blue: CGFloat(hex & 0xFF) / 255.0,
                  alpha: 1.0)
    }
}