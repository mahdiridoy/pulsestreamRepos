import Foundation

// MARK: - SampleProvider
/// Bundled built-in provider so the app ships with movie/series content out of
/// the box (the Android build gets this from installed APK plugins; iOS bundles
/// a curated catalog instead).
final class SampleProvider: MainAPI, @unchecked Sendable {
    var name: String { "Sample" }
    var mainUrl: String { "https://sample.pulsestream.app" }
    var enabled: Bool = true
    var hasMainPage: Bool { true }
    var hasQuickSearch: Bool { true }
    var supportedTypes: Set<TvType> { [.movie, .tvSeries] }
    var instantLinkLoading: Bool { false }

    /// Curated home page rows.
    func getMainPage(page: Int, request: MainPageRequest) async throws -> HomePageResponse {
        let rows = [
            HomePageList(name: "Trending Movies", list: [
                MovieSearchResponse(id: "s1", name: "The Grand Voyage", url: "sample://movie/1",
                                    apiName: name, posterUrl: nil, year: 2024,
                                    score: Score(from10: 8.2), type: .movie),
                MovieSearchResponse(id: "s2", name: "Midnight Protocol", url: "sample://movie/2",
                                    apiName: name, posterUrl: nil, year: 2023,
                                    score: Score(from10: 7.8), type: .movie),
                MovieSearchResponse(id: "s3", name: "Echoes of Tomorrow", url: "sample://movie/3",
                                    apiName: name, posterUrl: nil, year: 2025,
                                    score: Score(from10: 8.9), type: .movie)
            ]),
            HomePageList(name: "Popular Series", list: [
                TvSeriesSearchResponse(id: "s4", name: "Neon District", url: "sample://series/1",
                                       apiName: name, posterUrl: nil, year: 2024,
                                       score: Score(from10: 8.0), type: .tvSeries),
                TvSeriesSearchResponse(id: "s5", name: "The Last Lighthouse", url: "sample://series/2",
                                       apiName: name, posterUrl: nil, year: 2023,
                                       score: Score(from10: 7.5), type: .tvSeries)
            ])
        ]
        return HomePageResponse(items: rows, hasNext: false)
    }

    func search(query: String) async throws -> SearchResponseList? {
        let matches = [
            MovieSearchResponse(id: "q1", name: query, url: "sample://movie/1", apiName: name,
                                posterUrl: nil, type: .movie),
            TvSeriesSearchResponse(id: "q2", name: query, url: "sample://series/1", apiName: name,
                                   posterUrl: nil, type: .tvSeries)
        ]
        return SearchResponseList(items: matches, hasNext: false)
    }

    func load(url: String) async throws -> LoadResponse? {
        if url.contains("series") {
            var episodes: [Episode] = []
            for s in 1...2 {
                for e in 1...8 {
                    episodes.append(Episode(id: s * 100 + e, name: "Episode \(e)", season: s,
                                            episode: e, description: "Sample episode S\(s)E\(e)"))
                }
            }
            return TvSeriesLoadResponse(url: url, apiName: name, name: "Neon District",
                                        posterUrl: nil, year: 2024, plot: "A sample series.",
                                        score: Score(from10: 8.0), episodes: episodes)
        }
        return MovieLoadResponse(url: url, apiName: name, name: "The Grand Voyage",
                                 posterUrl: nil, year: 2024, plot: "A sample movie.",
                                 score: Score(from10: 8.2))
    }

    func loadLinks(episode: Episode) async throws -> LinkResult {
        // Demo links: a public-domain sample stream so playback works out of the box.
        let link = ExtractorLink(source: "Sample", name: "Demo 720p",
                                 url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                                 quality: Qualities.hd.rawValue, headers: nil, extractorData: nil,
                                 isM3u8: false, type: .normal)
        return LinkResult(links: [link], subtitles: [])
    }
}