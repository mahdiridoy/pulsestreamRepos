import Foundation
import Combine

// MARK: - LiveTvRepository (mirrors ui/livetv/LiveTvRepository.kt)
@MainActor
final class LiveTvRepository {
    static let shared = LiveTvRepository()

    /// Same playlist URL as the Android app.
    static let playlistURL = "https://mahdiridoy.github.io/Tv/mahdi_iptv.m3u8"
    static let channelsCacheKey = "live_tv_channels_cache_v1"
    static let lastChannelIdKey = "live_tv_last_channel_id_v1"
    static let fetchTimeout: TimeInterval = 20

    struct CachedChannels: Codable {
        var fetchedAt: Date
        var channels: [LiveTvChannel]
    }

    @Published private(set) var channels: [LiveTvChannel] = []
    @Published private(set) var isLoading = false
    @Published private(set) var isRefreshing = false
    @Published private(set) var loadError: String?

    var lastChannelId: String? {
        get { CSDataStore.getKeyString(Self.lastChannelIdKey) }
        set {
            if let newValue { CSDataStore.setKey(Self.lastChannelIdKey, newValue) }
            else { CSDataStore.removeKey(Self.lastChannelIdKey) }
        }
    }

    private init() {
        if let cached: CachedChannels = CSDataStore.getKey(Self.channelsCacheKey, type: CachedChannels.self) {
            channels = cached.channels
        }
    }

    func load(forceRefresh: Bool = false) async {
        if forceRefresh {
            isRefreshing = true
        } else if channels.isEmpty {
            isLoading = true
        }
        defer {
            isLoading = false
            isRefreshing = false
        }
        do {
            // Bypass cache refresh bypasses the shared URLCache, mirroring forceRefresh.
            let response = try await Requests.app.get(Self.playlistURL,
                                                     params: forceRefresh ? ["_": "\(Date().timeIntervalSince1970)"] : nil,
                                                     timeout: Self.fetchTimeout)
            guard response.isSuccessful else {
                loadError = "Failed to load playlist (HTTP \(response.statusCode))"
                return
            }
            let parsed = M3uParser.parse(response.text)
            guard !parsed.isEmpty else {
                loadError = "No channels found in playlist"
                return
            }
            channels = parsed
            let cached = CachedChannels(fetchedAt: Date(), channels: parsed)
            CSDataStore.setKey(Self.channelsCacheKey, cached)
            loadError = nil
        } catch {
            // Keep cached channels on network failure.
            if channels.isEmpty {
                loadError = error.localizedDescription
            }
        }
    }

    func channel(id: String?) -> LiveTvChannel? {
        guard let id else { return nil }
        return channels.first { $0.id == id }
    }

    func nextChannel(after id: String?) -> LiveTvChannel? {
        guard let id, let idx = channels.firstIndex(where: { $0.id == id }) else {
            return channels.first
        }
        let next = (idx + 1) % channels.count
        return channels[next]
    }

    func previousChannel(before id: String?) -> LiveTvChannel? {
        guard let id, let idx = channels.firstIndex(where: { $0.id == id }) else {
            return channels.last
        }
        let prev = (idx - 1 + channels.count) % channels.count
        return channels[prev]
    }
}

// MARK: - IPTVProvider
/// Bundled provider exposing the IPTV playlist through the MainAPI contract
/// (home page rows of live channels, search, and live-stream load responses).
final class IPTVProvider: MainAPI, @unchecked Sendable {
    var name: String { "IPTV" }
    var mainUrl: String { "https://mahdiridoy.github.io" }
    var enabled: Bool = true
    var hasMainPage: Bool { true }
    var supportedTypes: Set<TvType> { [.live] }

    @MainActor
    func getMainPage(page: Int, request: MainPageRequest) async throws -> HomePageResponse {
        let repo = LiveTvRepository.shared
        if repo.channels.isEmpty { await repo.load() }
        let items: [SearchResponse] = repo.channels.map { channel in
            LiveStreamSearchResponse(id: channel.id, name: channel.name, url: channel.streamUrl,
                                     apiName: name, posterUrl: channel.logoUrl, type: .live)
        }
        return HomePageResponse(items: [HomePageList(name: "Live TV", list: items)], hasNext: false)
    }

    @MainActor
    func search(query: String) async throws -> SearchResponseList? {
        let repo = LiveTvRepository.shared
        if repo.channels.isEmpty { await repo.load() }
        let filtered = repo.channels.filter { $0.name.localizedCaseInsensitiveContains(query) }
        let items: [SearchResponse] = filtered.map { channel in
            LiveStreamSearchResponse(id: channel.id, name: channel.name, url: channel.streamUrl,
                                     apiName: name, posterUrl: channel.logoUrl, type: .live)
        }
        return SearchResponseList(items: items, hasNext: false)
    }

    @MainActor
    func load(url: String) async throws -> LoadResponse? {
        let repo = LiveTvRepository.shared
        if repo.channels.isEmpty { await repo.load() }
        guard let channel = repo.channels.first(where: { $0.streamUrl == url || $0.id == url }) else {
            return nil
        }
        return LiveStreamLoadResponse(url: channel.streamUrl, apiName: name, name: channel.name,
                                      posterUrl: channel.logoUrl, comingSoon: false)
    }

    func loadLinks(episode: Episode) async throws -> LinkResult {
        LinkResult(links: [], subtitles: [])
    }
}

/// Search response used by the Live TV provider.
final class LiveStreamSearchResponse: SearchResponse {
    init(id: String, name: String, url: String, apiName: String?, posterUrl: String?, type: TvType = .live) {
        super.init(id: id, name: name, url: url, apiName: apiName, posterUrl: posterUrl, type: type)
    }
    required init(from decoder: Decoder) throws { try super.init(from: decoder) }
}