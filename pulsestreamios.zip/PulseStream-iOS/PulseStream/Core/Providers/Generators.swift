import Foundation

// MARK: - Quality data helper (mirrors ui/player/source_priority/QualityDataHelper.kt)
@MainActor
enum QualityDataHelper {
    static let videoSourcePriority = "video_source_priority"
    static let videoProfileName = "video_profile_name"
    static let videoQualityPriority = "video_quality_priority"
    static let videoProfileSettings = "video_profile_settings"
    static let videoProfileTypes = "video_profile_types_2"
    static let defaultSourcePriority = 1
    static let autoSkipPriority = 10
    static let profileCount = 7

    enum QualityProfileType: Int, Codable, CaseIterable, Sendable {
        case none = 0
        case wifi = 1
        case data = 2
        case download = 3

        var isUnique: Bool { self == .wifi || self == .data || self == .download }
    }

    enum ProfileSettings: Codable {
        case hideNegativeSources
        case hideErrorSources

        var key: String {
            switch self {
            case .hideNegativeSources: return "hide_negative_sources"
            case .hideErrorSources: return "hide_error_sources"
            }
        }
    }

    struct QualityProfile: Codable, Identifiable, Equatable, Sendable {
        var name: String
        var type: QualityProfileType
        var id: Int

        static let `default` = QualityProfile(name: "Default", type: .none, id: 0)
    }

    private static func profileKey(_ profile: Int) -> String {
        "$account_\(profile)"
    }

    static func getProfileName(_ profile: Int) -> String {
        CSDataStore.getKeyString("\(videoProfileName)/\(profileKey(profile))") ?? "Default"
    }

    static func setProfileName(_ profile: Int, _ name: String) {
        CSDataStore.setKey("\(videoProfileName)/\(profileKey(profile))", name)
    }

    static func getProfileSetting(_ profile: Int, _ setting: ProfileSettings) -> Bool {
        CSDataStore.getKeyBool("\(videoProfileSettings)/\(profileKey(profile))/\(setting.key)") ?? false
    }

    static func getProfileType(_ profile: Int) -> QualityProfileType {
        QualityProfileType(rawValue: CSDataStore.getKeyInt("\(videoProfileTypes)/\(profileKey(profile))") ?? 0) ?? .none
    }

    static func getSourcePriority(_ profile: Int, source: String?) -> Int {
        guard let source else { return 0 }
        return CSDataStore.getKeyInt("\(videoSourcePriority)/\(profileKey(profile))/\(source)") ?? defaultSourcePriority
    }

    static func setSourcePriority(_ profile: Int, source: String, priority: Int) {
        CSDataStore.setKey("\(videoSourcePriority)/\(profileKey(profile))/\(source)", priority)
    }

    static func getQualityPriority(_ profile: Int, quality: Int) -> Int {
        CSDataStore.getKeyInt("\(videoQualityPriority)/\(profileKey(profile))/\(quality)") ?? 0
    }

    static func setQualityPriority(_ profile: Int, quality: Int, priority: Int) {
        CSDataStore.setKey("\(videoQualityPriority)/\(profileKey(profile))/\(quality)", priority)
    }

    /// Mirrors getLinkPriority = qualityPriority + sourcePriority.
    static func getLinkPriority(profile: Int, link: ExtractorLink?) -> Int {
        guard let link else { return Int.min }
        let closest = closestQuality(link.quality)
        return getQualityPriority(profile, quality: closest) + getSourcePriority(profile, source: link.source)
    }

    /// Maps an arbitrary quality value to the nearest defined quality bucket.
    static func closestQuality(_ quality: Int?) -> Int {
        guard let quality else { return Qualities.unknown.rawValue }
        let buckets = [Qualities.lq.rawValue, Qualities.sd.rawValue, Qualities.hd.rawValue,
                       Qualities.fhd.rawValue, Qualities.uhd4k.rawValue]
        var closest = Qualities.unknown.rawValue
        var bestDistance = Int.max
        for bucket in buckets {
            let distance = abs(bucket - quality)
            if distance < bestDistance {
                bestDistance = distance
                closest = bucket
            }
        }
        return closest
    }

    /// Mirrors sortUrls: stable sort by (priority desc, index).
    static func sortUrls(_ links: [ExtractorLink], profile: Int) -> [ExtractorLink] {
        links.enumerated().sorted { a, b in
            let pa = getLinkPriority(profile: profile, link: a.element)
            let pb = getLinkPriority(profile: profile, link: b.element)
            if pa != pb { return pa > pb }
            return a.offset < b.offset
        }.map { $0.element }
    }
}

// MARK: - VideoGenerator abstraction (mirrors IGenerator.kt)
protocol VideoGenerator: AnyObject, Sendable {
    var videos: [ResultEpisode] { get }
    var page: LoadResponse? { get }
    var hasCache: Bool { get }
    var canSkipLoading: Bool { get }

    func getId(index: Int) -> Int?
    func hasNext(_ videoIndex: Int) -> Bool
    func hasPrev(_ videoIndex: Int) -> Bool
    func generateLinks(clearCache: Bool, sourceTypes: Set<ExtractorLinkType>,
                       callback: @escaping (VideoLink) -> Void,
                       subtitleCallback: @escaping (SubtitleData) -> Void,
                       offset: Int, isCasting: Bool) async -> Bool
}

extension VideoGenerator {
    var page: LoadResponse? { nil }
    func hasNext(_ videoIndex: Int) -> Bool { videoIndex < videos.count - 1 }
    func hasPrev(_ videoIndex: Int) -> Bool { videoIndex > 0 }
}

/// No-op generator used when a player opens without any videos.
final class NoVideoGenerator: VideoGenerator, @unchecked Sendable {
    let videos: [ResultEpisode] = []
    let hasCache = false
    let canSkipLoading = false
    var id: Int?
    init(id: Int?) { self.id = id }
    func getId(index: Int) -> Int? { id }
    func generateLinks(clearCache: Bool, sourceTypes: Set<ExtractorLinkType>,
                       callback: @escaping (VideoLink) -> Void,
                       subtitleCallback: @escaping (SubtitleData) -> Void,
                       offset: Int, isCasting: Bool) async -> Bool { false }
}

// MARK: - RepoLinkGenerator (mirrors ui/player/RepoLinkGenerator.kt)
/// Generates links for an episode list from a provider, with a process-wide
/// `(apiName, episodeId)` cache, 20-minute TTL, URL dedup and saturated short-circuit.
final class RepoLinkGenerator: VideoGenerator, @unchecked Sendable {
    let videos: [ResultEpisode]
    let page: LoadResponse?
    let apiName: String
    let hasCache: Bool = true
    let canSkipLoading: Bool = false

    struct Cache {
        var linkCache: Set<String> = []
        var subtitleCache: Set<String> = []
        var lastCachedTimestamp: Date = Date()
        var saturated: Bool = false
    }

    private static var globalCache: [String: Cache] = [:]
    private static let cacheLock = NSLock()
    private static let cacheTTL: TimeInterval = 60 * 20

    init(_ videos: [ResultEpisode], page: LoadResponse?, apiName: String) {
        self.videos = videos
        self.page = page
        self.apiName = apiName
    }

    func getId(index: Int) -> Int? {
        videos.indices.contains(index) ? videos[index].id : nil
    }

    func generateLinks(clearCache: Bool, sourceTypes: Set<ExtractorLinkType>,
                       callback: @escaping (VideoLink) -> Void,
                       subtitleCallback: @escaping (SubtitleData) -> Void,
                       offset: Int, isCasting: Bool) async -> Bool {
        guard videos.indices.contains(offset) else { return false }
        let episode = videos[offset]
        let cacheKey = "\(apiName)|\(episode.id)"

        Self.cacheLock.lock()
        var cache = Self.globalCache[cacheKey] ?? Cache()
        if clearCache || Date().timeIntervalSince(cache.lastCachedTimestamp) > Self.cacheTTL {
            cache = Cache()
        }

        // Synchronous cache replay.
        var emittedSubs: Set<String> = []
        for subURL in cache.subtitleCache {
            guard !emittedSubs.contains(subURL) else { continue }
            emittedSubs.insert(subURL)
            subtitleCallback(SubtitleData(originalName: "Cached", url: subURL, origin: .url))
        }

        if cache.saturated {
            Self.cacheLock.unlock()
            return true
        }
        Self.cacheLock.unlock()

        // Network load.
        let api = await MainActor.run { APIHolder.shared.getApiFromName(apiName) ?? IPTVProvider() }
        let repository = APIRepository(api: api)
        let result = await repository.loadLinks(episode: episode.data)
        guard case .success(let linkResult) = result else {
            Self.cacheLock.lock()
            cache.saturated = cache.linkCache.isEmpty
            cache.lastCachedTimestamp = Date()
            Self.globalCache[cacheKey] = cache
            Self.cacheLock.unlock()
            return false
        }

        Self.cacheLock.lock()
        for sub in linkResult.subtitles {
            guard let url = sub.url, !url.isEmpty, !cache.subtitleCache.contains(url) else { continue }
            cache.subtitleCache.insert(url)
            Self.cacheLock.unlock()
            subtitleCallback(SubtitleData(originalName: sub.name, url: url, origin: .url,
                                          languageCode: sub.lang))
            Self.cacheLock.lock()
        }
        for link in linkResult.links {
            guard !link.url.isEmpty, !cache.linkCache.contains(link.url) else { continue }
            if AdBlocker.isAdLink(link) { continue }
            if !sourceTypes.contains(link.type) { continue }
            cache.linkCache.insert(link.url)
            Self.cacheLock.unlock()
            callback((link, nil))
            Self.cacheLock.lock()
        }
        cache.saturated = !cache.linkCache.isEmpty
        cache.lastCachedTimestamp = Date()
        Self.globalCache[cacheKey] = cache
        Self.cacheLock.unlock()
        return true
    }
}

// MARK: - LinkGenerator (mirrors ui/player/LinkGenerator.kt)
/// Generates links directly from a pre-resolved URL (deep links, direct playback).
final class LinkGenerator: VideoGenerator, @unchecked Sendable {
    struct BasicLinkItem: Sendable {
        var url: String
        var name: String?
    }

    let items: [BasicLinkItem]
    let extract: Bool
    let id: Int
    let videos: [ResultEpisode]
    let hasCache = false
    let canSkipLoading = true

    init(_ items: [BasicLinkItem], extract: Bool, id: Int) {
        self.items = items
        self.extract = extract
        self.id = id
        self.videos = items.enumerated().map { (idx, item) in
            ResultEpisode(id: id + idx, season: 1, episode: idx + 1, data: Episode(id: id + idx, season: 1, episode: idx + 1))
        }
    }

    func getId(index: Int) -> Int? { videos.indices.contains(index) ? videos[index].id : nil }

    func generateLinks(clearCache: Bool, sourceTypes: Set<ExtractorLinkType>,
                       callback: @escaping (VideoLink) -> Void,
                       subtitleCallback: @escaping (SubtitleData) -> Void,
                       offset: Int, isCasting: Bool) async -> Bool {
        guard items.indices.contains(offset) else { return false }
        let item = items[offset]
        await ExtractorResolver.resolve(link: item.url, name: item.name, referer: nil,
                                        subtitleCallback: { sub in
            subtitleCallback(SubtitleData(originalName: sub.name, url: sub.url ?? "", origin: .url))
        }) { link in
            callback((link, nil))
        }
        return true
    }
}

// MARK: - PlayMirrorGenerator
/// Mirrors the anonymous generator built by PlayMirrorAction: a pre-seeded index
/// that yields the already-selected link instantly, other episodes load lazily.
final class PlayMirrorGenerator: VideoGenerator, @unchecked Sendable {
    let allEpisodes: [ResultEpisode]
    let startIndex: Int
    let preSelectedLink: ExtractorLink
    let preSelectedSubs: [SubtitleData]
    let responsePage: LoadResponse?
    let apiName: String
    let hasCache = false
    let canSkipLoading = false

    var videos: [ResultEpisode] { allEpisodes }

    init(allEpisodes: [ResultEpisode], startIndex: Int, link: ExtractorLink,
         subs: [SubtitleData], page: LoadResponse?, apiName: String) {
        self.allEpisodes = allEpisodes
        self.startIndex = startIndex
        self.preSelectedLink = link
        self.preSelectedSubs = subs
        self.responsePage = page
        self.apiName = apiName
    }

    func getId(index: Int) -> Int? {
        allEpisodes.indices.contains(index) ? allEpisodes[index].id : allEpisodes.first?.id
    }

    func generateLinks(clearCache: Bool, sourceTypes: Set<ExtractorLinkType>,
                       callback: @escaping (VideoLink) -> Void,
                       subtitleCallback: @escaping (SubtitleData) -> Void,
                       offset: Int, isCasting: Bool) async -> Bool {
        guard allEpisodes.indices.contains(offset) else { return false }
        if offset == startIndex {
            // Instant link: emit the pre-selected source without any fetch.
            for sub in preSelectedSubs {
                subtitleCallback(sub)
            }
            callback((preSelectedLink, nil))
            return true
        }
        // Lazy load other episodes through the normal repository path.
        let repoGenerator = RepoLinkGenerator(allEpisodes, page: responsePage, apiName: apiName)
        return await repoGenerator.generateLinks(clearCache: clearCache, sourceTypes: sourceTypes,
                                                 callback: callback, subtitleCallback: subtitleCallback,
                                                 offset: offset, isCasting: isCasting)
    }
}