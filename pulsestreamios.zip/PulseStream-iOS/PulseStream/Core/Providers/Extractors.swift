import Foundation

// MARK: - Generic extractors
/// Extracts direct m3u8/mp4 links from an HTML page (mirrors GenericM3U8-style extractors).
final class GenericM3U8Extractor: ExtractorAPI, @unchecked Sendable {
    var name: String { "Generic M3U8" }
    var mainUrl: String { "" }
    var requiresReferer: Bool { true }

    func getUrl(url: String, referer: String?,
                subtitleCallback: @escaping (SubtitleFile) -> Void,
                callback: @escaping (ExtractorLink) -> Void) async {
        guard let html = try? await Requests.app.get(url, referer: referer).text else { return }
        let m3u8Urls = Self.extractM3U8(html)
        let mp4Urls = Self.extractMP4(html)
        for stream in m3u8Urls {
            let fixed = URLUtils.fixUrl(stream, base: URLUtils.baseUrl(url)) ?? stream
            var headers: [String: String] = [:]
            if let referer { headers["Referer"] = referer }
            callback(ExtractorLink(source: name, name: "HLS Stream", url: fixed, quality: Qualities.hd.rawValue,
                                   headers: headers, isM3u8: true, type: .m3u8))
        }
        for stream in mp4Urls {
            let fixed = URLUtils.fixUrl(stream, base: URLUtils.baseUrl(url)) ?? stream
            var headers: [String: String] = [:]
            if let referer { headers["Referer"] = referer }
            callback(ExtractorLink(source: name, name: "MP4 Stream", url: fixed, quality: Qualities.sd.rawValue,
                                   headers: headers, isM3u8: false, type: .normal))
        }
    }

    private static func extractM3U8(_ html: String) -> [String] {
        var result: Set<String> = []
        let patterns = [
            "(https?://[^\"'\\s]+\\.m3u8[^\"'\\s]*)",
            "https?:\\\\?/\\\\?/[^\"'\\s]+\\.m3u8"
        ]
        for pattern in patterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
                let nsRange = NSRange(html.startIndex..<html.endIndex, in: html)
                regex.enumerateMatches(in: html, options: [], range: nsRange) { match, _, _ in
                    guard let match, let range = Range(match.range(at: 1), in: html) else { return }
                    let value = String(html[range])
                        .replacingOccurrences(of: "\\\\", with: "/")
                        .replacingOccurrences(of: "\\", with: "")
                    result.insert(value)
                }
            }
        }
        return Array(result)
    }

    private static func extractMP4(_ html: String) -> [String] {
        var result: Set<String> = []
        let pattern = "(https?://[^\"'\\s]+\\.(mp4|webm)[^\"'\\s]*)"
        if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
            let nsRange = NSRange(html.startIndex..<html.endIndex, in: html)
            regex.enumerateMatches(in: html, options: [], range: nsRange) { match, _, _ in
                guard let match, let range = Range(match.range(at: 1), in: html) else { return }
                result.insert(String(html[range]))
            }
        }
        return Array(result)
    }
}

/// Pass-through extractor when the URL is already an m3u8 stream.
final class HlsManifestExtractor: ExtractorAPI, @unchecked Sendable {
    var name: String { "HLS Manifest" }
    var mainUrl: String { "" }

    func getUrl(url: String, referer: String?,
                subtitleCallback: @escaping (SubtitleFile) -> Void,
                callback: @escaping (ExtractorLink) -> Void) async {
        var headers: [String: String] = [:]
        if let referer { headers["Referer"] = referer }
        callback(ExtractorLink(source: name, name: "HLS Stream", url: url, quality: Qualities.hd.rawValue,
                               headers: headers, isM3u8: true, type: .m3u8))
    }
}

/// Scrapes nested iframe/player pages for streams (mirrors GenericVidPlay-style extractors).
final class GenericVidPlayExtractor: ExtractorAPI, @unchecked Sendable {
    var name: String { "Generic VidPlay" }
    var mainUrl: String { "" }
    var requiresReferer: Bool { true }
    var needsFullUrl: Bool { true }

    func getUrl(url: String, referer: String?,
                subtitleCallback: @escaping (SubtitleFile) -> Void,
                callback: @escaping (ExtractorLink) -> Void) async {
        guard let html = try? await Requests.app.get(url, referer: referer).text else { return }
        // Look for <source src="..."> and "file":"..." / file:"..." patterns.
        let m3u8Source = Self.extractSourceTags(html, extensions: ["m3u8"])
        let videoSources = Self.extractSourceTags(html, extensions: ["mp4", "webm"])
        let jsonFileUrls = Self.extractJsonFileUrls(html)
        var headers: [String: String] = [:]
        if let referer { headers["Referer"] = referer }
        for stream in m3u8Source {
            let fixed = URLUtils.fixUrl(stream, base: URLUtils.baseUrl(url)) ?? stream
            callback(ExtractorLink(source: name, name: "HLS Stream", url: fixed, quality: Qualities.hd.rawValue,
                                   headers: headers, isM3u8: true, type: .m3u8))
        }
        for stream in videoSources {
            let fixed = URLUtils.fixUrl(stream, base: URLUtils.baseUrl(url)) ?? stream
            callback(ExtractorLink(source: name, name: "Video", url: fixed, quality: Qualities.sd.rawValue,
                                   headers: headers, isM3u8: false, type: .normal))
        }
        for stream in jsonFileUrls {
            let fixed = URLUtils.fixUrl(stream, base: URLUtils.baseUrl(url)) ?? stream
            let isM3u8 = fixed.contains(".m3u8")
            callback(ExtractorLink(source: name, name: isM3u8 ? "HLS Stream" : "Video", url: fixed,
                                   quality: Qualities.hd.rawValue, headers: headers,
                                   isM3u8: isM3u8, type: isM3u8 ? .m3u8 : .normal))
        }
    }

    private static func extractSourceTags(_ html: String, extensions: [String]) -> [String] {
        var result: Set<String> = []
        let pattern = "<source[^>]*src=[\"']([^\"']+)[\"']"
        if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
            let nsRange = NSRange(html.startIndex..<html.endIndex, in: html)
            regex.enumerateMatches(in: html, options: [], range: nsRange) { match, _, _ in
                guard let match, let range = Range(match.range(at: 1), in: html) else { return }
                let value = String(html[range])
                if extensions.contains(where: { value.lowercased().contains("." + $0) }) {
                    result.insert(value)
                }
            }
        }
        return Array(result)
    }

    private static func extractJsonFileUrls(_ html: String) -> [String] {
        var result: Set<String> = []
        let pattern = "file\\s*[:=]\\s*[\"']([^\"']+)[\"']"
        if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
            let nsRange = NSRange(html.startIndex..<html.endIndex, in: html)
            regex.enumerateMatches(in: html, options: [], range: nsRange) { match, _, _ in
                guard let match, let range = Range(match.range(at: 1), in: html) else { return }
                let value = String(html[range])
                if value.contains(".m3u8") || value.contains(".mp4") || value.contains(".webm") {
                    result.insert(value)
                }
            }
        }
        return Array(result)
    }
}

// MARK: - Extractor resolver (mirrors loadExtractor / unshortenLinkSafe)
enum ExtractorResolver {
    /// Find the first extractor that can handle the URL and run it.
    static func loadExtractor(url: String, referer: String?,
                              subtitleCallback: @escaping (SubtitleFile) -> Void,
                              callback: @escaping (ExtractorLink) -> Void) async -> Bool {
        let extractorApis = await MainActor.run { APIHolder.shared.extractorApis }
        if let direct = extractorApis.first(where: { $0.needsFullUrl && canExtract($0, url: url) }) {
            await direct.getUrl(url: url, referer: referer, subtitleCallback: subtitleCallback, callback: callback)
            return true
        }
        let host = URL(string: url)?.host ?? ""
        for extractor in extractorApis where !extractor.needsFullUrl {
            if canExtract(extractor, url: url) || host.contains(extractor.mainUrl) {
                await extractor.getUrl(url: url, referer: referer, subtitleCallback: subtitleCallback, callback: callback)
                return true
            }
        }
        return false
    }

    private static func canExtract(_ extractor: ExtractorAPI, url: String) -> Bool {
        if extractor is HlsManifestExtractor { return url.contains(".m3u8") }
        if extractor is GenericM3U8Extractor || extractor is GenericVidPlayExtractor {
            return URL(string: url)?.scheme != nil
        }
        return false
    }

    /// Resolve a raw link, using extractors when available and falling back to the raw URL.
    static func resolve(link url: String, name: String?, referer: String?,
                        subtitleCallback: @escaping (SubtitleFile) -> Void,
                        callback: @escaping (ExtractorLink) -> Void) async {
        let isDirectStream = url.contains(".m3u8") || url.contains(".mp4") || url.contains(".webm")
        if isDirectStream {
            let fixed = URLUtils.fixUrl(url) ?? url
            var headers: [String: String] = [:]
            if let referer { headers["Referer"] = referer }
            callback(ExtractorLink(source: "Direct", name: name ?? "Stream", url: fixed,
                                   quality: Qualities.hd.rawValue, headers: headers,
                                   isM3u8: url.contains(".m3u8"), type: url.contains(".m3u8") ? .m3u8 : .normal))
            return
        }
        let extracted = await loadExtractor(url: url, referer: referer,
                                            subtitleCallback: subtitleCallback, callback: callback)
        if !extracted {
            let fixed = URLUtils.fixUrl(url) ?? url
            callback(ExtractorLink(source: "Direct", name: name ?? "Stream", url: fixed,
                                   quality: Qualities.hd.rawValue, headers: referer.map { ["Referer": $0] },
                                   isM3u8: false, type: .normal))
        }
    }
}