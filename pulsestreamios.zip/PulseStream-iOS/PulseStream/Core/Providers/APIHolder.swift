import Foundation

// MARK: - MainAPI protocol (mirrors library MainAPI)
protocol MainAPI: AnyObject, Sendable {
    var name: String { get }
    var mainUrl: String { get }
    var enabled: Bool { get set }
    var hasMainPage: Bool { get }
    var hasQuickSearch: Bool { get }
    var supportedTypes: Set<TvType> { get }
    var instantLinkLoading: Bool { get }
    var requiresLogin: Bool { get }
    var vpnStatus: VPNStatus { get }
    var supportedSyncNames: Set<SyncIdName> { get }

    /// Home page rows. `page` starts at 0.
    func getMainPage(page: Int, request: MainPageRequest) async throws -> HomePageResponse
    func search(query: String) async throws -> SearchResponseList?
    func search(query: String, page: Int) async throws -> SearchResponseList?
    func load(url: String) async throws -> LoadResponse?
    func load(url: String, extraData: String) async throws -> LoadResponse?
    func getSearchSuggestions(query: String) async throws -> [String]?
    func loadLinks(episode: Episode) async throws -> LinkResult

    /// Returns nil if this provider can't produce links itself (e.g. needs extractors).
    func getVideoInterceptor(link: ExtractorLink) -> Any?
}

extension MainAPI {
    var instantLinkLoading: Bool { false }
    var supportedSyncNames: Set<SyncIdName> { [] }
    var requiresLogin: Bool { false }
    var vpnStatus: VPNStatus { .none }
    var hasQuickSearch: Bool { false }

    func search(query: String) async throws -> SearchResponseList? {
        try await search(query: query, page: 1)
    }
    func search(query: String, page: Int) async throws -> SearchResponseList? {
        try await search(query: query)
    }
    func load(url: String, extraData: String) async throws -> LoadResponse? {
        try await load(url: url)
    }
    func getSearchSuggestions(query: String) async throws -> [String]? { nil }
    func getVideoInterceptor(link: ExtractorLink) -> Any? { nil }
}

struct MainPageRequest: Sendable {
    var page: Int
    var category: String?
    var overrideName: String?
    var job: Task<Void, Never>?
}

/// Result of loading links for an episode.
struct LinkResult: Sendable {
    var links: [ExtractorLink]
    var subtitles: [SubtitleFile]
}

// MARK: - ExtractorAPI protocol (mirrors library ExtractorApi)
protocol ExtractorAPI: AnyObject, Sendable {
    var name: String { get }
    var mainUrl: String { get }
    var requiresReferer: Bool { get }
    var needsFullUrl: Bool { get }
    var isNSFW: Bool { get }

    /// Extract playable links from a provider page. Subtitle callback can emit subtitles found.
    func getUrl(url: String, referer: String?,
                subtitleCallback: @escaping (SubtitleFile) -> Void,
                callback: @escaping (ExtractorLink) -> Void) async
}

extension ExtractorAPI {
    var requiresReferer: Bool { false }
    var needsFullUrl: Bool { false }
    var isNSFW: Bool { false }

    func getUrl(url: String, referer: String?) async -> [ExtractorLink]? {
        var links: [ExtractorLink] = []
        await getUrl(url: url, referer: referer, subtitleCallback: { _ in }) { link in
            links.append(link)
        }
        return links.isEmpty ? nil : links
    }
}

// MARK: - SubtitleAPI protocol (mirrors app syncproviders SubtitleAPI)
protocol SubtitleAPI: AnyObject, Sendable {
    var name: String { get }
    func search(_ query: SubtitleSearch) async throws -> [SubtitleEntity]?
    func load(_ subtitle: SubtitleEntity) async throws -> String?
}

// MARK: - APIHolder registry (mirrors APIHolder)
@MainActor
final class APIHolder {
    static let shared = APIHolder()

    private(set) var apis: [MainAPI] = []
    private(set) var extractorApis: [ExtractorAPI] = []
    private(set) var subtitleApis: [SubtitleAPI] = []
    private var apiMap: [String: MainAPI] = [:]
    private var providerNameMap: [String: MainAPI] = [:]

    func register(_ api: MainAPI) {
        apis.append(api)
        providerNameMap[api.name.lowercased()] = api
        if let url = URL(string: api.mainUrl), let host = url.host {
            apiMap[host.lowercased()] = api
        }
    }

    func registerExtractor(_ extractor: ExtractorAPI) {
        extractorApis.append(extractor)
    }

    func registerSubtitle(_ subtitle: SubtitleAPI) {
        subtitleApis.append(subtitle)
    }

    func getApiFromName(_ name: String) -> MainAPI? {
        providerNameMap[name.lowercased()]
    }

    func getApiFromUrl(_ url: String) -> MainAPI? {
        guard let host = URL(string: url)?.host?.lowercased() else { return nil }
        return apiMap[host]
    }

    /// Mirrors `APIRepository` search across all providers.
    func getApiRepository(_ api: MainAPI) -> APIRepository {
        APIRepository(api: api)
    }

    func reset() {
        apis = PluginRegistry.bundledProviders
        providerNameMap = [:]
        apiMap = [:]
        for api in apis {
            providerNameMap[api.name.lowercased()] = api
            if let host = URL(string: api.mainUrl)?.host?.lowercased() {
                apiMap[host] = api
            }
        }
    }
}

// MARK: - APIRepository (mirrors APIRepository)
struct APIRepository {
    let api: MainAPI

    func loadMainPage(page: Int, category: String?) async -> Resource<HomePageResponse> {
        do {
            let response = try await api.getMainPage(page: page, request: MainPageRequest(page: page, category: category))
            return .success(response)
        } catch {
            return CS3Error.from(error)
        }
    }

    func search(query: String) async -> Resource<SearchResponseList?> {
        do {
            let result = try await api.search(query: query)
            return .success(result)
        } catch {
            return CS3Error.from(error)
        }
    }

    func load(url: String) async -> Resource<LoadResponse?> {
        do {
            let result = try await api.load(url: url)
            return .success(result)
        } catch {
            return CS3Error.from(error)
        }
    }

    func loadLinks(episode: Episode) async -> Resource<LinkResult> {
        do {
            let result = try await api.loadLinks(episode: episode)
            return .success(result)
        } catch {
            return CS3Error.from(error)
        }
    }
}

// MARK: - PluginRegistry
/// Mirrors BasePlugin registration. Bundled providers (no APK loading on iOS).
enum PluginRegistry {
    static let bundledProviders: [MainAPI] = [
        IPTVProvider(),          // Live TV home/search/result
        SampleProvider()         // built-in movie/series provider skeleton
    ]

    @MainActor
    static func loadAllPlugins() {
        let holder = APIHolder.shared
        holder.reset()
        for extractor in bundledExtractors {
            holder.registerExtractor(extractor)
        }
        for subtitle in bundledSubtitleAPIs {
            holder.registerSubtitle(subtitle)
        }
    }

    static let bundledExtractors: [ExtractorAPI] = [
        GenericM3U8Extractor(),
        GenericVidPlayExtractor(),
        HlsManifestExtractor()
    ]

    static let bundledSubtitleAPIs: [SubtitleAPI] = [
        OpenSubtitlesProvider(),
        SubdlProvider(),
        SubSourceProvider()
    ]
}