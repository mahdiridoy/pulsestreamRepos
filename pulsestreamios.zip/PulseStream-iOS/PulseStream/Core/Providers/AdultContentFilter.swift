import Foundation
import UIKit
import CoreImage

// MARK: - AdultContentFilter (mirrors app utils/AdultContentFilter.kt)
/// Best-effort title-based + skin-tone image adult content filter.
///
/// The Adult Content Filter setting drives hiding of explicit content from Home,
/// Search, and results. Applied as a second layer on top of the `TvType.nsfw` flag.
enum AdultContentFilter {
    /// Filter is enabled when adult content should be HIDDEN (setting default ON).
    static var isEnabled: Bool {
        CSDataStore.getKeyBool(AppSettings.Keys.adultContentFilter) ?? true
    }

    private static let keywordPattern =
        #"(?i)\b(porn(o|hub|star)?|xxx|hentai|nsfw|erotic(a)?|sex(y|ual)?|nud(e|es|ity)|naked|topless|18\+|adult\s?(film|movie|video|xxx)|camgirl|escort|fetish|onlyfans|javhd?|brazzers|hardcore|softcore|milf|swinger|strip(per|tease)|orgy|gangbang|bdsm|kinky|lickerish|playboy|bareback|cuckold|creampie|boobs|tits|big\s?ass|anal|blowjob|shemale|transsexual|voyeur|gonewild|threesome|dildo|bondage|dominatrix|deepthroat|squirting|chaturbate|sexcam|nude\s?(beach|girl|women|woman)|lingerie\s?xxx|xxx\s?18)\b"#

    private static let keywordRegex = try! NSRegularExpression(pattern: keywordPattern)

    static func isLikelyAdult(title: String?) -> Bool {
        guard let title, !title.isEmpty else { return false }
        let range = NSRange(title.startIndex..., in: title)
        return keywordRegex.firstMatch(in: title, options: [], range: range) != nil
    }

    static func isLikelyAdult(_ response: SearchResponse) -> Bool {
        if response.type == .nsfw { return true }
        return isLikelyAdult(title: response.name)
    }

    static func filterList<T: SearchResponse>(_ items: [T]) -> [T] {
        guard isEnabled else { return items }
        return items.filter { !isLikelyAdult($0) }
    }

    // MARK: Skin-tone image detection

    private static let skinRatioThreshold: Float = 0.32

    private static var imageCache: [String: Bool] = [:]

    /// RGB-based skin pixel heuristic (mirrors the Kotlin thresholds).
    private static func isSkinPixel(r: Int, g: Int, b: Int) -> Bool {
        if r <= 95 || g <= 40 || b <= 20 { return false }
        if max(r, max(g, b)) - min(r, min(g, b)) <= 15 { return false }
        if abs(r - g) <= 15 { return false }
        if r <= g || r <= b { return false }
        let cb = 128 - 0.168736 * Double(r) - 0.331264 * Double(g) + 0.5 * Double(b)
        let cr = 128 + 0.5 * Double(r) - 0.418688 * Double(g) - 0.081312 * Double(b)
        if cb >= 85 && cb <= 135 && cr >= 135 && cr <= 180 { return true }
        // Hue check fallback.
        let rf = Float(r) / 255, gf = Float(g) / 255, bf = Float(b) / 255
        let cmax = max(rf, max(gf, bf)), cmin = min(rf, min(gf, bf))
        let delta = cmax - cmin
        guard delta > 0 else { return false }
        var hue: Float
        if cmax == rf { hue = 60 * (((gf - bf) / delta).truncatingRemainder(dividingBy: 6)) }
        else if cmax == gf { hue = 60 * (((bf - rf) / delta) + 2) }
        else { hue = 60 * (((rf - gf) / delta) + 4) }
        if hue < 0 { hue += 360 }
        return hue <= 25 || hue >= 335
    }

    private static func skinRatio(of image: UIImage) -> Float {
        guard let cgImage = image.cgImage else { return 0 }
        let width = 32, height = 32
        guard let cropped = downsample(cgImage, to: CGSize(width: width, height: height)) else { return 0 }
        guard let data = cropped.dataProvider?.data,
              let ptr = CFDataGetBytePtr(data) else { return 0 }
        let bytesPerRow = cropped.bytesPerRow
        let bpp = cropped.bitsPerPixel / 8
        var skin: Int = 0
        var total: Int = 0
        for y in 0..<height {
            for x in 0..<width {
                let offset = y * bytesPerRow + x * bpp
                guard offset + 3 < CFDataGetLength(data) else { continue }
                // ARGB or RGBA ordering handled via bitmapInfo; assume RGBA.
                let r = Int(ptr[offset]), g = Int(ptr[offset + 1]), b = Int(ptr[offset + 2])
                total += 1
                if isSkinPixel(r: r, g: g, b: b) { skin += 1 }
            }
        }
        guard total > 0 else { return 0 }
        return Float(skin) / Float(total)
    }

    private static func downsample(_ image: CGImage, to size: CGSize) -> CGImage? {
        let width = Int(size.width), height = Int(size.height)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: nil, width: width, height: height,
                                bitsPerComponent: 8, bytesPerRow: width * 4,
                                space: colorSpace,
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
        context?.interpolationQuality = .medium
        context?.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        return context?.makeImage()
    }

    private static func fetchImage(urlString: String?) async -> Bool {
        guard let urlString, let url = URL(string: urlString) else { return false }
        if let cached = imageCache[urlString] { return cached }
        var request = URLRequest(url: url)
        request.timeoutInterval = 15
        guard let (data, _) = try? await URLSession.shared.data(for: request),
              let image = UIImage(data: data) else { return false }
        let ratio = skinRatio(of: image)
        let result = ratio >= skinRatioThreshold
        imageCache[urlString] = result
        return result
    }

    /// Second layer: drop items whose poster is mostly skin-toned. Mirrors filterByImage.
    static func filterByImage<T: SearchResponse>(_ items: [T]) async -> [T] {
        guard isEnabled, !items.isEmpty else { return items }
        // Limit concurrent downloads (mirrors the 8-permit semaphore).
        let semaphore = AsyncSemaphore(permits: 8)
        var keep: [Bool] = Array(repeating: true, count: items.count)
        await withTaskGroup(of: (Int, Bool).self) { group in
            for (index, item) in items.enumerated() {
                group.addTask {
                    await semaphore.withPermit {
                        let adult = await fetchImage(urlString: item.posterUrl)
                        return (index, !adult)
                    }
                }
            }
            for await (index, result) in group {
                keep[index] = result
            }
        }
        return items.enumerated().compactMap { keep[$0.offset] ? $0.element : nil }
    }
}

/// Tiny async semaphore (mirrors kotlinx Semaphore(8).withPermit).
private final class AsyncSemaphore: @unchecked Sendable {
    private let limit: Int
    private var active = 0
    private var waiters: [CheckedContinuation<Void, Never>] = []
    private let lock = NSLock()

    init(permits: Int) { self.limit = permits }

    func withPermit<T>(_ body: () async -> T) async -> T {
        await waitIfNeeded()
        defer { release() }
        return await body()
    }

    private func waitIfNeeded() async {
        lock.lock()
        if active < limit {
            active += 1
            lock.unlock()
            return
        }
        await withCheckedContinuation { continuation in
            waiters.append(continuation)
            lock.unlock()
        }
    }

    private func release() {
        lock.lock()
        if let next = waiters.first {
            waiters.removeFirst()
            lock.unlock()
            next.resume()
        } else {
            active -= 1
            lock.unlock()
        }
    }
}