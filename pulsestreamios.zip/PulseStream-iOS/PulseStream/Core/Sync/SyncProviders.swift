import Foundation

// MARK: - Auth & Sync API contracts (mirrors AuthAPI / SyncAPI / AuthRepo)
enum AuthLoginRequirement {
    case username
    case password
    case pin
}

struct AuthToken: Codable, Equatable, Sendable {
    var accessToken: String?
    var refreshToken: String?
    var accessTokenLifetime: Int64?

    func isExpired() -> Bool {
        guard let accessTokenLifetime else { return false }
        // 10s margin mirrors the Android implementation.
        return accessTokenLifetime <= Int64(Date().timeIntervalSince1970) + 10
    }
}

struct AuthUser: Codable, Equatable, Sendable {
    var name: String?
    var id: String?
    var profilePicture: String?
    var profilePictureHeaders: [String: String]?
}

protocol AuthAPI: AnyObject, Sendable {
    var name: String { get }
    var idPrefix: String { get }
    var mainUrl: String { get }
    var requiresLogin: Bool { get }
    var hasOAuth2: Bool { get }
    var hasPin: Bool { get }
    var hasInApp: Bool { get }
    var inAppLoginRequirement: AuthLoginRequirement { get }

    func getOauthUrl() async throws -> URL?
    func refreshToken(token: AuthToken) async throws -> AuthToken
    func login(form: [String: String]) async throws -> AuthToken
    func login(pin: String) async throws -> AuthToken
    func user(token: AuthToken) async throws -> AuthUser?
    func logout()
}

protocol SyncAPI: AuthAPI {
    var requireLibraryRefresh: Bool { get }
    var supportedWatchTypes: [TvType] { get }
    var syncIdName: SyncIdName { get }

    func updateStatus(auth: AuthToken?, id: String, newStatus: SyncStatusData) async throws -> Bool
    func status(auth: AuthToken?, id: String) async throws -> SyncStatusData?
    func load(auth: AuthToken?, id: String) async throws -> SyncResult?
    func library(auth: AuthToken?) async throws -> [LibraryMetadata]?
}

// MARK: - AuthRepo
/// Mirrors AuthRepo token storage.
@MainActor
final class AuthRepo {
    let api: any AuthAPI
    private let tokenKey: String

    init(api: any AuthAPI) {
        self.api = api
        self.tokenKey = "auth_tokens/\(api.idPrefix)"
    }

    func getAuth() -> AuthToken? {
        CSDataStore.getKey(tokenKey, type: AuthToken.self)
    }

    func saveAuth(_ token: AuthToken) {
        CSDataStore.setKey(tokenKey, token)
    }

    func logout() {
        CSDataStore.removeKey(tokenKey)
        api.logout()
    }

    /// Returns a fresh (possibly refreshed) token.
    func freshAuth() async throws -> AuthToken? {
        guard var token = getAuth() else { return nil }
        if token.isExpired(), let refresh = token.refreshToken {
            token = try await api.refreshToken(token: token)
            saveAuth(token)
        }
        return token
    }
}

// MARK: - AccountManager (mirrors syncproviders/AccountManager.kt)
@MainActor
final class AccountManager {
    static let shared = AccountManager()
    static let accountToken = "auth_tokens"
    static let accountIds = "auth_ids"
    static let noneId = -1

    private(set) var syncAPIs: [SyncAPI] = []
    private(set) var subtitleAPIs: [any SubtitleAPI] = []

    init() {
        syncAPIs = [
            AniListAPI(),
            MALAPI(),
            KitsuAPI(),
            SimklAPI(),
            LocalListAPI()
        ]
    }

    /// Mirrors initMainAPI.
    func initMainAPI() {
        syncAPIs = [
            AniListAPI(),
            MALAPI(),
            KitsuAPI(),
            SimklAPI(),
            LocalListAPI()
        ]
    }

    func api(for idName: SyncIdName) -> (any SyncAPI)? {
        syncAPIs.first { $0.syncIdName == idName }
    }

    func currentAccountName() -> String {
        "Main"
    }
}

// MARK: - Concrete providers

/// AniList GraphQL provider.
final class AniListAPI: SyncAPI, @unchecked Sendable {
    var name: String { "AniList" }
    var idPrefix: String { "anilist" }
    var mainUrl: String { "https://anilist.co" }
    var requiresLogin: Bool { true }
    var hasOAuth2: Bool { true }
    var hasPin: Bool { false }
    var hasInApp: Bool { false }
    var inAppLoginRequirement: AuthLoginRequirement { .username }
    var requireLibraryRefresh: Bool { false }
    var supportedWatchTypes: [TvType] { [.anime, .animeMovie, .cartoon, .ova, .tvSeries] }
    var syncIdName: SyncIdName { .anilist }

    private let base = "https://anilist.co/api/v2/oauth"

    func getOauthUrl() async throws -> URL? {
        var components = URLComponents(string: "\(base)/authorize")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: AppConfig.anilistKey),
            URLQueryItem(name: "response_type", value: "token")
        ]
        return components.url
    }

    func refreshToken(token: AuthToken) async throws -> AuthToken {
        guard let refresh = token.refreshToken else { return token }
        let body: [String: Any] = [
            "grant_type": "refresh_token",
            "refresh_token": refresh,
            "client_id": AppConfig.anilistKey
        ]
        let response = try await Requests.app.post("\(base)/token", json: body)
        let json = try response.jsonObject()
        return try CSJSON.decode(AuthToken.self, from: json)
    }

    func login(form: [String: String]) async throws -> AuthToken {
        throw CS3Error.invalidResponse
    }

    func login(pin: String) async throws -> AuthToken {
        let body: [String: Any] = [
            "grant_type": "authorization_code",
            "code": pin,
            "client_id": AppConfig.anilistKey
        ]
        let response = try await Requests.app.post("\(base)/token", json: body)
        let json = try response.jsonObject()
        return try CSJSON.decode(AuthToken.self, from: json)
    }

    func user(token: AuthToken) async throws -> AuthUser? {
        guard let access = token.accessToken else { return nil }
        let query = "query { Viewer { name id avatar { large } } }"
        let response = try await Requests.app.post("https://graphql.anilist.co",
                                                   headers: ["Authorization": "Bearer \(access)"],
                                                   json: ["query": query])
        let json = try response.jsonObject()
        let data = json["data"] as? [String: Any]
        let viewer = data?["Viewer"] as? [String: Any]
        let avatar = viewer?["avatar"] as? [String: Any]
        return AuthUser(name: viewer?["name"] as? String,
                        id: "\(viewer?["id"] ?? "")",
                        profilePicture: avatar?["large"] as? String)
    }

    func logout() {}

    func updateStatus(auth: AuthToken?, id: String, newStatus: SyncStatusData) async throws -> Bool {
        guard let access = auth?.accessToken else { return false }
        var variables: [String: Any] = ["mediaId": Int(id) ?? 0]
        if let status = newStatus.status { variables["status"] = status.rawValue.lowercased() }
        if newStatus.score > 0 { variables["scoreRaw"] = newStatus.score }
        if let episode = newStatus.episodeNumber { variables["progress"] = episode }
        let mutation = """
        mutation($mediaId: Int, $status: MediaListStatus, $scoreRaw: Int, $progress: Int) {
          SaveMediaListEntry(mediaId: $mediaId, status: $status, scoreRaw: $scoreRaw, progress: $progress) {
            id
          }
        }
        """
        let response = try await Requests.app.post("https://graphql.anilist.co",
                                                   headers: ["Authorization": "Bearer \(access)"],
                                                   json: ["query": mutation, "variables": variables])
        return response.isSuccessful
    }

    func status(auth: AuthToken?, id: String) async throws -> SyncStatusData? {
        guard let access = auth?.accessToken, let mediaId = Int(id) else { return nil }
        let query = """
        query($mediaId: Int) { MediaList(mediaId: $mediaId) { status score progress } }
        """
        let response = try await Requests.app.post("https://graphql.anilist.co",
                                                   headers: ["Authorization": "Bearer \(access)"],
                                                   json: ["query": query, "variables": ["mediaId": mediaId]])
        let json = try response.jsonObject()
        let data = json["data"] as? [String: Any]
        let list = data?["MediaList"] as? [String: Any]
        guard let list else { return nil }
        return SyncStatusData(synced: true,
                              status: SyncStatus(rawValue: (list["status"] as? String)?.capitalized ?? ""),
                              score: (list["score"] as? Int) ?? 0,
                              episodeNumber: list["progress"] as? Int,
                              isRewatched: false)
    }

    func load(auth: AuthToken?, id: String) async throws -> SyncResult? { nil }

    func library(auth: AuthToken?) async throws -> [LibraryMetadata]? { nil }
}

/// MyAnimeList OAuth2 provider.
final class MALAPI: SyncAPI, @unchecked Sendable {
    var name: String { "MyAnimeList" }
    var idPrefix: String { "mal" }
    var mainUrl: String { "https://myanimelist.net" }
    var requiresLogin: Bool { true }
    var hasOAuth2: Bool { true }
    var hasPin: Bool { false }
    var hasInApp: Bool { false }
    var inAppLoginRequirement: AuthLoginRequirement { .username }
    var requireLibraryRefresh: Bool { false }
    var supportedWatchTypes: [TvType] { [.anime, .animeMovie, .cartoon, .ova] }
    var syncIdName: SyncIdName { .myAnimeList }

    private let base = "https://myanimelist.net/v1/oauth2"

    func getOauthUrl() async throws -> URL? {
        var components = URLComponents(string: "\(base)/authorize")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: AppConfig.malKey),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "code_challenge", value: "challenge"),
            URLQueryItem(name: "state", value: AppPackage.app)
        ]
        return components.url
    }

    func refreshToken(token: AuthToken) async throws -> AuthToken {
        guard let refresh = token.refreshToken else { return token }
        let body: [String: Any] = [
            "grant_type": "refresh_token",
            "refresh_token": refresh,
            "client_id": AppConfig.malKey,
            "code_verifier": "challenge"
        ]
        let response = try await Requests.app.post("\(base)/token", json: body)
        let json = try response.jsonObject()
        return try CSJSON.decode(AuthToken.self, from: json)
    }

    func login(form: [String: String]) async throws -> AuthToken {
        throw CS3Error.invalidResponse
    }

    func login(pin: String) async throws -> AuthToken {
        let body: [String: Any] = [
            "grant_type": "authorization_code",
            "code": pin,
            "client_id": AppConfig.malKey,
            "code_verifier": "challenge"
        ]
        let response = try await Requests.app.post("\(base)/token", json: body)
        let json = try response.jsonObject()
        return try CSJSON.decode(AuthToken.self, from: json)
    }

    func user(token: AuthToken) async throws -> AuthUser? {
        guard let access = token.accessToken else { return nil }
        let response = try await Requests.app.get("https://api.myanimelist.net/v2/users/@me",
                                                  headers: ["Authorization": "Bearer \(access)"])
        let json = try response.jsonObject()
        return AuthUser(name: json["name"] as? String,
                        id: "\(json["id"] ?? "")",
                        profilePicture: json["picture"] as? String)
    }

    func logout() {}

    func updateStatus(auth: AuthToken?, id: String, newStatus: SyncStatusData) async throws -> Bool {
        guard let access = auth?.accessToken else { return false }
        var body: [String: Any] = ["status": (newStatus.status ?? .currently).rawValue.lowercased()]
        if newStatus.score > 0 { body["score"] = newStatus.score }
        if let episode = newStatus.episodeNumber { body["num_watched_episodes"] = episode }
        let response = try await Requests.app.put("https://api.myanimelist.net/v2/anime/\(id)/my_list_status",
                                                  headers: ["Authorization": "Bearer \(access)"], json: body)
        return response.isSuccessful
    }

    func status(auth: AuthToken?, id: String) async throws -> SyncStatusData? {
        guard let access = auth?.accessToken else { return nil }
        let response = try await Requests.app.get("https://api.myanimelist.net/v2/anime/\(id)?fields=my_list_status",
                                                  headers: ["Authorization": "Bearer \(access)"])
        let json = try response.jsonObject()
        guard let status = json["my_list_status"] as? [String: Any] else { return nil }
        return SyncStatusData(synced: true,
                              status: SyncStatus(rawValue: (status["status"] as? String)?.capitalized ?? ""),
                              score: (status["score"] as? Int) ?? 0,
                              episodeNumber: status["num_watched_episodes"] as? Int,
                              isRewatched: false)
    }

    func load(auth: AuthToken?, id: String) async throws -> SyncResult? { nil }
    func library(auth: AuthToken?) async throws -> [LibraryMetadata]? { nil }
}

/// Kitsu provider.
final class KitsuAPI: SyncAPI, @unchecked Sendable {
    var name: String { "Kitsu" }
    var idPrefix: String { "kitsu" }
    var mainUrl: String { "https://kitsu.io" }
    var requiresLogin: Bool { true }
    var hasOAuth2: Bool { true }
    var hasPin: Bool { false }
    var hasInApp: Bool { false }
    var inAppLoginRequirement: AuthLoginRequirement { .username }
    var requireLibraryRefresh: Bool { false }
    var supportedWatchTypes: [TvType] { [.anime, .animeMovie, .cartoon, .ova] }
    var syncIdName: SyncIdName { .kitsu }

    func getOauthUrl() async throws -> URL? { nil }
    func refreshToken(token: AuthToken) async throws -> AuthToken { token }
    func login(form: [String: String]) async throws -> AuthToken { throw CS3Error.invalidResponse }
    func login(pin: String) async throws -> AuthToken { throw CS3Error.invalidResponse }
    func user(token: AuthToken) async throws -> AuthUser? { nil }
    func logout() {}
    func updateStatus(auth: AuthToken?, id: String, newStatus: SyncStatusData) async throws -> Bool { false }
    func status(auth: AuthToken?, id: String) async throws -> SyncStatusData? { nil }
    func load(auth: AuthToken?, id: String) async throws -> SyncResult? { nil }
    func library(auth: AuthToken?) async throws -> [LibraryMetadata]? { nil }
}

/// Simkl provider.
final class SimklAPI: SyncAPI, @unchecked Sendable {
    var name: String { "Simkl" }
    var idPrefix: String { "simkl" }
    var mainUrl: String { "https://simkl.com" }
    var requiresLogin: Bool { true }
    var hasOAuth2: Bool { true }
    var hasPin: Bool { false }
    var hasInApp: Bool { false }
    var inAppLoginRequirement: AuthLoginRequirement { .username }
    var requireLibraryRefresh: Bool { false }
    var supportedWatchTypes: [TvType] { [.movie, .tvSeries, .anime, .cartoon] }
    var syncIdName: SyncIdName { .simkl }

    func getOauthUrl() async throws -> URL? { nil }
    func refreshToken(token: AuthToken) async throws -> AuthToken { token }
    func login(form: [String: String]) async throws -> AuthToken { throw CS3Error.invalidResponse }
    func login(pin: String) async throws -> AuthToken { throw CS3Error.invalidResponse }
    func user(token: AuthToken) async throws -> AuthUser? { nil }
    func logout() {}
    func updateStatus(auth: AuthToken?, id: String, newStatus: SyncStatusData) async throws -> Bool { false }
    func status(auth: AuthToken?, id: String) async throws -> SyncStatusData? { nil }
    func load(auth: AuthToken?, id: String) async throws -> SyncResult? { nil }
    func library(auth: AuthToken?) async throws -> [LibraryMetadata]? { nil }
}

/// Local list provider — persists sync status on-device (mirrors LocalList).
final class LocalListAPI: SyncAPI, @unchecked Sendable {
    var name: String { "Local List" }
    var idPrefix: String { "local" }
    var mainUrl: String { "NONE" }
    var requiresLogin: Bool { false }
    var hasOAuth2: Bool { false }
    var hasPin: Bool { false }
    var hasInApp: Bool { false }
    var inAppLoginRequirement: AuthLoginRequirement { .username }
    var requireLibraryRefresh: Bool { true }
    var supportedWatchTypes: [TvType] { [.movie, .tvSeries, .anime, .cartoon, .ova] }
    var syncIdName: SyncIdName { .localList }

    func getOauthUrl() async throws -> URL? { nil }
    func refreshToken(token: AuthToken) async throws -> AuthToken { token }
    func login(form: [String: String]) async throws -> AuthToken { AuthToken() }
    func login(pin: String) async throws -> AuthToken { AuthToken() }
    func user(token: AuthToken) async throws -> AuthUser? { AuthUser(name: "Local List") }
    func logout() {}

    func updateStatus(auth: AuthToken?, id: String, newStatus: SyncStatusData) async throws -> Bool {
        CSDataStore.setKey("local_list/\(id)", newStatus)
        return true
    }

    func status(auth: AuthToken?, id: String) async throws -> SyncStatusData? {
        CSDataStore.getKey("local_list/\(id)", type: SyncStatusData.self)
    }

    func load(auth: AuthToken?, id: String) async throws -> SyncResult? { nil }
    func library(auth: AuthToken?) async throws -> [LibraryMetadata]? {
        let keys = CSDataStore.getKeys().filter { $0.hasPrefix("local_list/") }
        return keys.compactMap { key in
            let id = String(key.dropFirst("local_list/".count))
            let data: SyncStatusData? = CSDataStore.getKey(key, type: SyncStatusData.self)
            return data.map { LibraryMetadata(id: id, name: id, score: $0.score, status: $0.status) }
        }
    }
}