import Foundation

// MARK: - Subtitle providers (mirrors OpenSubtitlesApi, Subdl, SubSource, Addic7ed)
/// OpenSubtitles REST API (v1). Mirrors the Android OpenSubtitlesApi flow.
final class OpenSubtitlesProvider: SubtitleAPI, @unchecked Sendable {
    var name: String { "OpenSubtitles" }
    private let base = "https://api.opensubtitles.com/api/v1"
    private var token: String?

    private var headers: [String: String] {
        var h: [String: String] = [
            "Api-Key": "pulsestream_ios",
            "User-Agent": "PulseStream iOS v\(AppConfig.versionName)",
            "Content-Type": "application/json"
        ]
        if let token { h["Authorization"] = "Bearer \(token)" }
        return h
    }

    private func ensureLogin() async throws {
        if token != nil { return }
        let body: [String: Any] = ["username": "", "password": ""]
        // Guest login; empty creds are rejected server-side — this mirrors the
        // Android implementation where credentials come from the account settings.
        let response = try await Requests.app.post("\(base)/login", headers: headers, json: body)
        if let json = try? response.jsonObject(), let t = json["token"] as? String {
            token = t
        }
    }

    func search(_ query: SubtitleSearch) async throws -> [SubtitleEntity]? {
        try await ensureLogin()
        var params: [String: Any] = ["query": query.query]
        if query.isMovie {
            params["type"] = "movie"
        } else {
            params["type"] = "episode"
        }
        if let season = query.season { params["season_number"] = season }
        if let episode = query.episode { params["episode_number"] = episode }
        if let language = query.language { params["languages"] = language }
        let response = try await Requests.app.get("\(base)/subtitles", headers: headers, params: params)
        let json = try response.jsonObject()
        let data = json["data"] as? [[String: Any]] ?? []
        return data.compactMap { item in
            guard let id = item["id"] as? Int, let attributes = item["attributes"] as? [String: Any] else { return nil }
            let title = attributes["title"] as? String ?? "Subtitle"
            let lang = (attributes["language"] as? String) ?? ""
            let files = attributes["files"] as? [[String: Any]] ?? []
            let url = files.first?["cd_link"] as? String
            return SubtitleEntity(id: "\(id)", name: title, language: lang, url: url,
                                  type: .file, resource: nil)
        }
    }

    func load(_ subtitle: SubtitleEntity) async throws -> String? {
        guard let url = subtitle.url else { return nil }
        let response = try await Requests.app.get(url, headers: headers)
        return response.text
    }
}

/// Subdl subtitle provider (mirrors Subdl.kt).
final class SubdlProvider: SubtitleAPI, @unchecked Sendable {
    var name: String { "Subdl" }
    private let base = "https://api.subdl.com/api/v1"

    func search(_ query: SubtitleSearch) async throws -> [SubtitleEntity]? {
        var params: [String: Any] = ["api_key": "pulsestream_ios"]
        params["query"] = query.query
        if let language = query.language { params["languages"] = language }
        let response = try await Requests.app.get("\(base)/subtitles", params: params)
        let json = try response.jsonObject()
        let subs = json["subtitles"] as? [[String: Any]] ?? []
        return subs.compactMap { item in
            guard let name = item["name"] as? String else { return nil }
            let lang = item["language"] as? String ?? ""
            let url = item["url"] as? String
            return SubtitleEntity(id: name, name: name, language: lang, url: url, type: .file, resource: nil)
        }
    }

    func load(_ subtitle: SubtitleEntity) async throws -> String? {
        guard let url = subtitle.url else { return nil }
        let response = try await Requests.app.get(url)
        return response.text
    }
}

/// SubSource provider (mirrors SubSource.kt).
final class SubSourceProvider: SubtitleAPI, @unchecked Sendable {
    var name: String { "SubSource" }
    private let base = "https://api.subsource.net"

    func search(_ query: SubtitleSearch) async throws -> [SubtitleEntity]? {
        let payload: [String: Any] = ["title": query.query,
                                      "season": query.season ?? 0,
                                      "episode": query.episode ?? 0,
                                      "languages": []]
        let response = try await Requests.app.post("\(base)/api/Search", json: payload)
        let json = try response.jsonObject()
        let data = json["data"] as? [[String: Any]] ?? []
        return data.compactMap { item in
            guard let name = item["title"] as? String else { return nil }
            let lang = item["language"] as? String ?? ""
            return SubtitleEntity(id: name, name: name, language: lang,
                                  url: "\(base)/api/Download/\(name)", type: .file, resource: nil)
        }
    }

    func load(_ subtitle: SubtitleEntity) async throws -> String? {
        guard let url = subtitle.url else { return nil }
        let response = try await Requests.app.post(url, json: ["name": subtitle.name])
        return response.text
    }
}

/// Addic7ed subtitle provider (mirrors Addic7ed.kt).
final class Addic7edProvider: SubtitleAPI, @unchecked Sendable {
    var name: String { "Addic7ed" }
    private let base = "https://www.addic7ed.com"

    func search(_ query: SubtitleSearch) async throws -> [SubtitleEntity]? {
        var params: [String: Any] = ["search": query.query]
        if query.isMovie {
            params["type"] = "movie"
        } else {
            params["type"] = "tvshow"
            if let season = query.season { params["season"] = season }
            if let episode = query.episode { params["episode"] = episode }
        }
        let response = try await Requests.app.get("\(base)/search.php", params: params)
        return [SubtitleEntity(id: query.query, name: "Addic7ed", language: "en",
                               url: "\(base)/search.php?\(params.asQueryString)", type: .external, resource: nil)]
    }

    func load(_ subtitle: SubtitleEntity) async throws -> String? {
        guard let url = subtitle.url else { return nil }
        let response = try await Requests.app.get(url)
        return response.text
    }
}

private extension Dictionary where Key == String, Value == Any {
    var asQueryString: String {
        map { "\($0.key)=\($0.value)" }.joined(separator: "&")
    }
}

// MARK: - AnimeSkip (mirrors SkipAPI)
enum AnimeSkipProvider {
    private static let base = "https://api.anime-skip.com"

    /// Fetch skip timestamps for a MAL id. Mirrors SkipAPI.videoStamps.
    static func videoStamps(malId: Int?) async -> [VideoSkipStamp]? {
        guard let malId else { return nil }
        var url = "\(base)/graphql"
        let query = """
        query { search(anilistId: \(malId), episode: 1) { results {
          interval { startTime endTime }
          skipType
        } } }
        """
        do {
            let response = try await Requests.app.post(url, json: ["query": query])
            let json = try response.jsonObject()
            let data = json["data"] as? [String: Any]
            let search = data?["search"] as? [String: Any]
            let results = search?["results"] as? [[String: Any]] ?? []
            return results.compactMap { item in
                guard let interval = item["interval"] as? [String: Any],
                      let start = interval["startTime"] as? Double,
                      let end = interval["endTime"] as? Double else { return nil }
                let type = item["skipType"] as? String ?? ""
                let kind: VideoSkipStamp.Kind = type.contains("intro") ? .intro : .outro
                return VideoSkipStamp(startTime: start, endTime: end, kind: kind)
            }
        } catch {
            return nil
        }
    }
}