import Foundation

// MARK: - SearchSuggestionApi (mirrors app ui/search/SearchSuggestionApi.kt)
/// TMDB multi-search suggestions for the search bar.
enum SearchSuggestionApi {
    private static let tmdbURL = "https://api.themoviedb.org/3/search/multi"
    private static let tmdbAPIKey = "e6333b32409e02a4a6eba6fb7ff866bb"

    struct TmdbSearchResult: Codable {
        let results: [TmdbSearchItem]?
    }

    struct TmdbSearchItem: Codable {
        let mediaType: String?
        let title: String?
        let name: String?
    }

    static func getSuggestions(query: String) async -> [String] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2 else { return [] }
        do {
            let response = try await Requests.app.get(
                tmdbURL,
                params: ["api_key": tmdbAPIKey, "query": trimmed, "language": "en-US"]
            )
            guard response.isSuccessful else { return [] }
            let parsed = try response.parsed(TmdbSearchResult.self)
            var seen = Set<String>()
            var suggestions: [String] = []
            for item in parsed.results ?? [] {
                guard item.mediaType == "movie" || item.mediaType == "tv" else { continue }
                let name = item.title ?? item.name ?? ""
                guard !name.isEmpty, seen.insert(name).inserted else { continue }
                suggestions.append(name)
                if suggestions.count >= 10 { break }
            }
            return suggestions
        } catch {
            return []
        }
    }
}