import Foundation
import SwiftUI
import UIKit

// MARK: - ImageLoader
/// Mirrors Coil's image loading with in-memory + disk caching.
@MainActor
final class ImageLoader {
    static let shared = ImageLoader()

    private let memoryCache = NSCache<NSString, UIImage>()
    private let diskCacheURL: URL
    private let session: URLSession

    init() {
        let urls = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
        diskCacheURL = urls[0].appendingPathComponent("pulsestream_images", isDirectory: true)
        try? FileManager.default.createDirectory(at: diskCacheURL, withIntermediateDirectories: true)
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 30
        session = URLSession(configuration: config)
        memoryCache.totalCostLimit = 64 * 1024 * 1024
    }

    func load(urlString: String?, headers: [String: String]? = nil) async -> UIImage? {
        guard let urlString else { return nil }
        let key = urlString as NSString
        if let cached = memoryCache.object(forKey: key) { return cached }

        // Disk cache
        let cacheFile = diskCacheURL.appendingPathComponent(String(urlString.hash).replacingOccurrences(of: "-", with: "m"))
        if let data = try? Data(contentsOf: cacheFile), let image = UIImage(data: data) {
            memoryCache.setObject(image, forKey: key, cost: data.count)
            return image
        }

        guard let url = URL(string: urlString) else { return nil }
        var request = URLRequest(url: url)
        request.timeoutInterval = 30
        if let headers {
            for (k, v) in headers { request.setValue(v, forHTTPHeaderField: k) }
        }
        guard let (data, _) = try? await session.data(for: request),
              let image = UIImage(data: data) else { return nil }

        memoryCache.setObject(image, forKey: key, cost: data.count)
        try? data.write(to: cacheFile)
        return image
    }

    func clearCache() {
        memoryCache.removeAllObjects()
        try? FileManager.default.removeItem(at: diskCacheURL)
        try? FileManager.default.createDirectory(at: diskCacheURL, withIntermediateDirectories: true)
    }
}

// MARK: - Async image view
struct RemoteImage: View {
    let url: String?
    let headers: [String: String]?
    let placeholder: Image?
    @State private var image: UIImage?
    @State private var failed = false

    init(url: String?, headers: [String: String]? = nil, placeholder: Image? = nil) {
        self.url = url
        self.headers = headers
        self.placeholder = placeholder
    }

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable()
            } else if failed {
                (placeholder ?? Image(systemName: "film")).resizable()
                    .foregroundColor(.gray)
            } else {
                ZStack {
                    Color.gray.opacity(0.2)
                    if let placeholder {
                        placeholder.resizable().foregroundColor(.gray)
                    } else {
                        ProgressView()
                    }
                }
            }
        }
        .task(id: url) {
            image = nil
            failed = false
            guard let url, !url.isEmpty else { return }
            let result = await ImageLoader.shared.load(urlString: url, headers: headers)
            if result == nil { failed = true }
            image = result
        }
    }
}