import Foundation

// MARK: - Library & resume watching (mirrors DataStoreHelper.kt)
@MainActor
final class CSDataStoreHelper {
    static let shared = CSDataStoreHelper()

    // MARK: Favorites / library

    struct FavoritesData: Codable, Equatable {
        var bookmarks: [String] = []
        var favorites: [String] = []
        var history: [String] = []
        var subscriptions: [String] = []

        static let empty = FavoritesData()
    }

    /// Mirrors the per-account favorites storage under `favorites/`.
    private func favoritesKey(for apiName: String?) -> String {
        let account = apiName ?? "none"
        return "favorites/\(account)"
    }

    func getFavorites(for apiName: String?) -> FavoritesData {
        let key = favoritesKey(for: apiName)
        return CSDataStore.getKey(key, type: FavoritesData.self) ?? .empty
    }

    func setFavorites(_ data: FavoritesData, for apiName: String?) {
        let key = favoritesKey(for: apiName)
        CSDataStore.setKey(key, data)
    }

    /// Mirror of `isFavorite` / `isBookmarked` / `isInHistory`.
    func isFavorite(url: String, apiName: String?) -> Bool {
        getFavorites(for: apiName).favorites.contains(url)
    }

    func isBookmarked(url: String, apiName: String?) -> Bool {
        getFavorites(for: apiName).bookmarks.contains(url)
    }

    func isInHistory(url: String, apiName: String?) -> Bool {
        getFavorites(for: apiName).history.contains(url)
    }

    func toggleFavorite(url: String, apiName: String?) -> Bool {
        var data = getFavorites(for: apiName)
        if let idx = data.favorites.firstIndex(of: url) {
            data.favorites.remove(at: idx)
            data.subscriptions.removeAll { $0 == url }
        } else {
            data.favorites.insert(url, at: 0)
            if !data.subscriptions.contains(url) { data.subscriptions.append(url) }
        }
        setFavorites(data, for: apiName)
        return data.favorites.contains(url)
    }

    func toggleBookmark(url: String, apiName: String?) -> Bool {
        var data = getFavorites(for: apiName)
        if let idx = data.bookmarks.firstIndex(of: url) {
            data.bookmarks.remove(at: idx)
        } else {
            data.bookmarks.insert(url, at: 0)
        }
        setFavorites(data, for: apiName)
        return data.bookmarks.contains(url)
    }

    func addToHistory(url: String, apiName: String?) {
        var data = getFavorites(for: apiName)
        data.history.removeAll { $0 == url }
        data.history.insert(url, at: 0)
        if data.history.count > 500 { data.history = Array(data.history.prefix(500)) }
        setFavorites(data, for: apiName)
    }

    func removeFromLibrary(url: String, apiName: String?) {
        var data = getFavorites(for: apiName)
        data.favorites.removeAll { $0 == url }
        data.bookmarks.removeAll { $0 == url }
        data.history.removeAll { $0 == url }
        data.subscriptions.removeAll { $0 == url }
        setFavorites(data, for: apiName)
    }

    // MARK: Continue watching

    struct VideoWatchState: Codable, Equatable {
        var positionMs: Int64 = 0
        var durationMs: Int64 = 0
    }

    func getVideoWatchState(url: String, apiName: String?) -> VideoWatchState {
        let key = "resume/\(apiName ?? "none")/\(url)"
        return CSDataStore.getKey(key, type: VideoWatchState.self) ?? VideoWatchState()
    }

    func setVideoWatchState(_ state: VideoWatchState, url: String, apiName: String?) {
        let key = "resume/\(apiName ?? "none")/\(url)"
        if state.positionMs <= 0 {
            CSDataStore.removeKey(key)
        } else {
            CSDataStore.setKey(key, state)
        }
    }

    /// Mirrors getViewPos with the >=95% reset behavior.
    func getViewPos(url: String, apiName: String?) -> Int64 {
        let state = getVideoWatchState(url: url, apiName: apiName)
        guard state.durationMs > 0 else { return state.positionMs }
        let progress = Double(state.positionMs) / Double(state.durationMs)
        if progress >= 0.95 { return 0 }
        return state.positionMs
    }

    func setViewPos(url: String, apiName: String?, positionMs: Int64, durationMs: Int64) {
        let progress = durationMs > 0 ? Double(positionMs) / Double(durationMs) : 0
        if progress >= 0.95 {
            setVideoWatchState(VideoWatchState(), url: url, apiName: apiName)
        } else {
            setVideoWatchState(VideoWatchState(positionMs: positionMs, durationMs: durationMs), url: url, apiName: apiName)
        }
    }

    /// Last watched episode (season/episode) used to restore the initial episode index.
    private func lastWatchedEpisodeKey(url: String, apiName: String?) -> String {
        "resume/episode/\(apiName ?? "none")/\(url)"
    }

    func getLastWatchedEpisode(url: String, apiName: String?) -> (episode: Int?, season: Int?) {
        guard let raw = CSDataStore.getKeyString(lastWatchedEpisodeKey(url: url, apiName: apiName)) else {
            return (nil, nil)
        }
        let parts = raw.split(separator: ":").compactMap { Int($0) }
        guard parts.count == 2 else { return (nil, nil) }
        return (parts[1], parts[0])
    }

    func setLastWatchedEpisode(url: String, apiName: String?, episode: Int?, season: Int?) {
        guard let episode, let season else { return }
        CSDataStore.setKey(lastWatchedEpisodeKey(url: url, apiName: apiName), "\(season):\(episode)")
    }

    // MARK: Playback speed

    func getPlaybackSpeed() -> Double {
        CSDataStore.getKeyDouble("playback_speed_key") ?? 1.0
    }
    func setPlaybackSpeed(_ speed: Double) {
        CSDataStore.setKey("playback_speed_key", speed)
    }

    // MARK: Download metadata caches

    struct DownloadHeaderCached: Codable, Equatable, Identifiable {
        var name: String
        var url: String
        var apiName: String
        var id: String { url }
    }

    struct DownloadEpisodeCached: Codable, Equatable, Identifiable {
        var id: Int
        var season: Int
        var episode: Int
        var name: String?
        var posterUrl: String?
        var url: String
    }

    func getDownloadHeaders() -> [DownloadHeaderCached] {
        CSDataStore.getKey("\(CSDataStore.downloadHeaderCache)/entries", type: [DownloadHeaderCached].self) ?? []
    }
    func setDownloadHeaders(_ headers: [DownloadHeaderCached]) {
        CSDataStore.setKey("\(CSDataStore.downloadHeaderCache)/entries", headers)
    }

    // MARK: Search history

    func getSearchHistory() -> [String] {
        CSDataStore.getKey("search_history", type: [String].self) ?? []
    }
    func addSearchHistory(_ query: String) {
        var history = getSearchHistory()
        history.removeAll { $0.lowercased() == query.lowercased() }
        history.insert(query, at: 0)
        if history.count > 30 { history = Array(history.prefix(30)) }
        CSDataStore.setKey("search_history", history)
    }
    func clearSearchHistory() {
        CSDataStore.removeKey("search_history")
    }
}