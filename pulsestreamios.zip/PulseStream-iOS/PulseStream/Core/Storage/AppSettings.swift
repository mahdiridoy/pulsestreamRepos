import Foundation
import Combine

// MARK: - AppSettings
/// Central settings registry mirroring the Android preference keys and defaults.
@MainActor
final class AppSettings: ObservableObject {
    static let shared = AppSettings()

    // Theme values from array.xml
    static let themeNames = ["Dark", "Gray", "Amoled", "Flashbang", "System", "Material You", "Dracula", "Lavender Dreams", "Silent Blue"]
    static let themeValues = ["AmoledLight", "Black", "Amoled", "Light", "System", "Monet", "Dracula", "Lavender", "SilentBlue"]
    static let overlayNames = ["Normal", "Dandelion Yellow", "Carnation Pink", "Orange", "Dark Green", "Maroon",
                               "Navy Blue", "Grey", "White", "Cool Blue", "Brown", "Cool", "Fire", "Burple",
                               "Green", "Apple", "Banana", "Party", "Pink Pain", "Lavender", "Material You", "Material You (Secondary)"]
    static let overlayValues = ["Normal", "DandelionYellow", "CarnationPink", "Orange", "DarkGreen", "Maroon",
                                "NavyBlue", "Grey", "White", "CoolBlue", "Brown", "Blue", "Red", "Purple",
                                "Green", "GreenApple", "Banana", "Party", "Pink", "Lavender", "Monet", "Monet2"]

    @Published var appTheme: String { didSet { CSDataStore.setKey("app_theme_key", appTheme) } }
    @Published var primaryColor: String { didSet { CSDataStore.setKey("primary_color_key", primaryColor) } }

    private init() {
        self.appTheme = CSDataStore.getKeyString("app_theme_key") ?? "System"
        self.primaryColor = CSDataStore.getKeyString("primary_color_key") ?? "Normal"
    }

    // MARK: Generic typed accessors
    func string(_ key: String, default def: String) -> String {
        CSDataStore.getKeyString(key) ?? def
    }
    func set(_ key: String, _ value: String) { CSDataStore.setKey(key, value) }

    func int(_ key: String, default def: Int) -> Int {
        CSDataStore.getKeyInt(key) ?? def
    }
    func set(_ key: String, _ value: Int) { CSDataStore.setKey(key, value) }

    func bool(_ key: String, default def: Bool) -> Bool {
        CSDataStore.getKeyBool(key) ?? def
    }
    func set(_ key: String, _ value: Bool) { CSDataStore.setKey(key, value) }

    func double(_ key: String, default def: Double) -> Double {
        CSDataStore.getKeyDouble(key) ?? def
    }
    func set(_ key: String, _ value: Double) { CSDataStore.setKey(key, value) }

    func object<T: Codable>(_ key: String, type: T.Type, default def: T? = nil) -> T? {
        CSDataStore.getKey(key, type: T.self) ?? def
    }
    func setObject<T: Encodable>(_ key: String, _ value: T) { CSDataStore.setKey(key, value) }

    // MARK: Layout / device
    static let phone = 0b001
    static let tv = 0b010
    static let emulator = 0b100

    var appLayout: Int { int("app_layout_key", default: -1) }
    var isPhone: Bool { appLayout == 0 }

    // MARK: Keys (from donottranslate-strings.xml)
    struct Keys {
        static let locale = "locale_key"
        static let adultContentFilter = "adult_content_filter_key"
        static let downloadPath = "download_path_key"
        static let downloadParallel = "download_parallel_key"
        static let downloadConcurrent = "download_concurrent_key"
        static let episodeSyncEnabled = "episode_sync_enabled_key"
        static let playerDefault = "player_default_key"
        static let preferLimitTitle = "prefer_limit_title_key"
        static let preferLimitShowPlayerInfo = "prefer_limit_show_player_info_key"
        static let hidePlayerControlNames = "hide_player_control_names_key"
        static let subtitleSettings = "subtitle_settings_key"
        static let playerSourcePriority = "player_source_priority_key"
        static let pipEnabled = "pip_enabled_key"
        static let playerResizeEnabled = "player_resize_enabled_key"
        static let playbackSpeedEnabled = "playback_speed_enabled_key"
        static let speedup = "speedup_key"
        static let autoplayNext = "autoplay_next_key"
        static let enableSkipOpFromDatabase = "enable_skip_op_from_database_key"
        static let rotateVideo = "rotate_video_key"
        static let autoRotateVideo = "auto_rotate_video_key"
        static let previewSeekbar = "preview_seekbar_key"
        static let softwareDecoding = "software_decoding_key2"
        static let extraBrightness = "extra_brightness_key"
        static let swipeToSeek = "swipe_to_seek_key"
        static let swipeToChange = "swipe_to_change_key"
        static let doubleTapEnabled = "double_tap_enabled_key"
        static let doubleTapPauseEnabled = "double_tap_pause_enabled_key"
        static let doubleTapSeekTime = "double_tap_seek_time_key"
        static let qualityPref = "quality_pref_key"
        static let qualityPrefMobileData = "quality_pref_mobile_data_key"
        static let videoBufferSize = "video_buffer_size_key"
        static let videoBufferLength = "video_buffer_length_key"
        static let videoBufferDisk = "video_buffer_disk_key"
        static let videoBufferClear = "video_buffer_clear_key"
        static let bottomTitle = "bottom_title_key"
        static let overscan = "overscan_key"
        static let posterSize = "poster_size_key"
        static let posterUi = "poster_ui_key"
        static let searchSuggestions = "search_suggestions_enabled_key"
        static let showTrailers = "show_trailers_key"
        static let showCastInDetails = "show_cast_in_details_key"
        static let showFillers = "show_fillers_key"
        static let showPlayerMetadataOverlay = "show_player_metadata_overlay_key"
        static let tvLayoutClock = "tv_layout_clock_key"
        static let randomButton = "random_button_key"
        static let confirmExit = "confirm_exit_key"
        static let filterSearchQuality = "pref_filter_search_quality_key"
        static let providerLang = "provider_lang_key"
        static let preferMediaType = "prefer_media_type_key"
        static let displaySub = "display_sub_key"
        static let testProviders = "test_providers_key"
        static let skipStartupAccountSelect = "skip_startup_account_select_key"
        static let biometric = "biometric_key"
        static let backup = "backup_key"
        static let automaticBackup = "automatic_backup_key"
        static let restore = "restore_key"
        static let backupPath = "backup_path_key"
        static let autoUpdatePlugins = "auto_update_plugins_key"
        static let autoDownloadPlugins = "auto_download_plugins_key2"
        static let manualUpdatePlugins = "manual_update_plugins_key"
        static let showLogcat = "show_logcat_key"
        static let redoSetup = "redo_setup_key"
        static let hasDoneSetup = "HAS_DONE_SETUP"
        static let homeApiUsed = "home_api_used"
        static let userCustomSites = "user_custom_sites"
        static let subtitleAutoSelect = "subs_auto_select"
        static let filterSubLang = "filter_sub_lang_key"
        static let showName = "show_name_key"
        static let showResolution = "show_resolution_key"
        static let showMediaInfo = "show_media_info_key"
        static let subtitlesEncoding = "subtitles_encoding_key"
        static let autoUpdate = "manual_check_update_key"
    }
}