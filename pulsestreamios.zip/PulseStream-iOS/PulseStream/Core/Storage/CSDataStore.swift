import Foundation

// MARK: - CSDataStore
/// Mirrors `utils/DataStore.kt` — a JSON-string backed key/value store.
/// On iOS this maps to UserDefaults; values are stored as JSON strings just like Android.
enum CSDataStore {
    static let preferencesKey = "rebuild_preference"

    // Constants from DataStore.kt
    static let downloadHeaderCache = "download_header_cache"
    static let downloadHeaderCacheBackup = "download_header_cache_backup"
    static let downloadEpisodeCache = "download_episode_cache"
    static let downloadEpisodeCacheBackup = "download_episode_cache_backup"
    static let videoPlayerBrightness = "video_player_alpha_key"
    static let userSelectedHomepageApi = "home_api_used"
    static let userProviderApi = "user_custom_sites"

    static var defaults: UserDefaults { UserDefaults.standard }

    static func getKeys() -> [String] {
        Array(defaults.dictionaryRepresentation().keys)
    }

    static func containsKey(_ key: String) -> Bool {
        defaults.object(forKey: key) != nil
    }

    static func removeKey(_ key: String) {
        defaults.removeObject(forKey: key)
    }

    static func removeKeys(_ keys: [String]) {
        for key in keys { defaults.removeObject(forKey: key) }
    }

    static func getRaw(_ key: String) -> String? {
        defaults.string(forKey: key)
    }

    static func setRaw(_ key: String, _ value: String) {
        defaults.set(value, forKey: key)
    }

    // MARK: JSON-based get/set (mirrors toJsonLiteral/parseJson)

    static func getKey<T: Decodable>(_ key: String, type: T.Type) -> T? {
        guard let raw = getRaw(key) else { return nil }
        return try? CSJSON.decoder.decode(T.self, from: Data(raw.utf8))
    }

    static func getKey<T: Decodable>(_ key: String, type: T.Type, default defaultValue: T) -> T {
        guard let raw = getRaw(key), let value = try? CSJSON.decoder.decode(T.self, from: Data(raw.utf8)) else {
            return defaultValue
        }
        return value
    }

    static func getKey<T: Decodable>(_ key: String) -> T? {
        guard let raw = getRaw(key) else { return nil }
        return try? CSJSON.decoder.decode(T.self, from: Data(raw.utf8))
    }

    static func getKeyString(_ key: String) -> String? {
        guard let raw = getRaw(key) else { return nil }
        // Values stored as JSON strings are wrapped in quotes.
        if raw.hasPrefix("\""), raw.hasSuffix("\""), raw.count >= 2 {
            return String(raw.dropFirst().dropLast())
        }
        return raw
    }

    static func getKeyInt(_ key: String) -> Int? {
        guard let raw = getRaw(key) else { return nil }
        return Int(raw)
    }

    static func getKeyBool(_ key: String) -> Bool? {
        guard let raw = getRaw(key) else { return nil }
        if let b = Bool(raw) { return b }
        return (raw as NSString).boolValue
    }

    static func getKeyDouble(_ key: String) -> Double? {
        guard let raw = getRaw(key) else { return nil }
        return Double(raw)
    }

    static func setKey(_ key: String, _ value: Any?) {
        guard let value else {
            removeKey(key)
            return
        }
        switch value {
        case let string as String:
            setRaw(key, string)
        case let int as Int:
            setRaw(key, "\(int)")
        case let double as Double:
            setRaw(key, "\(double)")
        case let float as Float:
            setRaw(key, "\(float)")
        case let bool as Bool:
            setRaw(key, "\(bool)")
        default:
            if let encodable = value as? Encodable,
               let data = try? CSJSON.encoder.encode(encodable) {
                setRaw(key, String(data: data, encoding: .utf8) ?? "")
            } else {
                setRaw(key, "\(value)")
            }
        }
    }

    /// Batch edit (mirrors DataStore.Editor).
    struct Editor {
        private var pending: [String: String] = [:]
        private var removed: [String] = []

        mutating func put(_ key: String, _ value: Any?) -> Editor {
            guard let value else {
                removed.append(key)
                return self
            }
            switch value {
            case let string as String: pending[key] = string
            case let int as Int: pending[key] = "\(int)"
            case let double as Double: pending[key] = "\(double)"
            case let float as Float: pending[key] = "\(float)"
            case let bool as Bool: pending[key] = "\(bool)"
            default:
                if let encodable = value as? Encodable,
                   let data = try? CSJSON.encoder.encode(encodable) {
                    pending[key] = String(data: data, encoding: .utf8)
                } else {
                    pending[key] = "\(value)"
                }
            }
            return self
        }

        func apply() {
            for (k, v) in pending { CSDataStore.setRaw(k, v) }
            for k in removed { CSDataStore.removeKey(k) }
        }
    }
}

// MARK: - PreferenceDelegate helper (mirrors PreferenceDelegate<T>)
@propertyWrapper
struct CSPreference<T: Codable & Equatable> {
    private let key: String
    private let defaultValue: T

    init(_ key: String, default: T) {
        self.key = key
        self.defaultValue = `default`
    }

    var wrappedValue: T {
        get { CSDataStore.getKey(key, type: T.self, default: defaultValue) }
        set {
            if newValue == defaultValue {
                CSDataStore.removeKey(key)
            } else {
                CSDataStore.setKey(key, newValue)
            }
        }
    }
}