import Foundation
import Combine

// MARK: - WatchTogetherManager
/// Mirrors ui/watchtogether/WatchTogetherManager.kt exactly.
@MainActor
final class WatchTogetherManager: ObservableObject {
    static let shared = WatchTogetherManager()

    static let server = "https://watch-together-server.mdmahdiouzzamanridoy.workers.dev"
    static let wsServer = "wss://watch-together-server.mdmahdiouzzamanridoy.workers.dev/ws"

    // Persistence (SharedPreferences file "watch_together")
    private static let prefsFile = "watch_together"
    private static let roomCodeKey = "room_code"
    private static let hostTokenKey = "host_token"
    private static let roleKey = "role"

    @Published private(set) var role: WatchTogetherRole = .none
    @Published private(set) var roomCode: String = ""
    @Published private(set) var connected = false
    @Published private(set) var users: [RoomUser] = []
    @Published var lastRoomName: String = ""

    private var socket: URLSessionWebSocketTask?
    private var session: URLSession?
    private var displayName: String = "Guest"
    private var hostToken: String = ""

    private(set) var lastPositionMs: Int64 = 0
    private(set) var lastPlaying = false
    private(set) var lastContent: ContentInfo?
    private var lastFiredContent: ContentInfo?
    private var lastFiredNavigate: NavigateInfo?
    private var pendingContent: (url: String, apiName: String?, name: String, episodeId: Int?, episode: Int?, season: Int?, positionMs: Int64, playing: Bool)?

    // Listeners (mirror the Android interfaces)
    var contentListener: ((ContentInfo, Int64, Bool) -> Void)?
    var usersListener: (([RoomUser]) -> Void)?
    var navigateListener: ((NavigateInfo) -> Void)?
    var connectionListener: ((Bool) -> Void)?
    var roomClosedListener: (() -> Void)?
    var onDisconnected: (() -> Void)?
    var onError: ((String) -> Void)?
    var onPlay: ((Int64) -> Void)?
    var onPause: ((Int64) -> Void)?
    var onSeek: ((Int64) -> Void)?

    private var pingTask: Task<Void, Never>?
    private var receiveTask: Task<Void, Never>?

    private init() {
        loadSavedConnection()
    }

    // MARK: Persistence

    private func loadSavedConnection() {
        roomCode = CSDataStore.getKeyString(Self.roomCodeKey) ?? ""
        hostToken = CSDataStore.getKeyString(Self.hostTokenKey) ?? ""
        let roleRaw = CSDataStore.getKeyString(Self.roleKey) ?? ""
        role = WatchTogetherRole(rawValue: roleRaw) ?? .none
        cleanupStaleSessionIfNeeded()
    }

    /// Wipes persisted connection if a previous process died while connected.
    private func cleanupStaleSessionIfNeeded() {
        if role != .none && !connected {
            clearSavedConnection()
        }
    }

    func cleanupStaleSession() {
        cleanupStaleSessionIfNeeded()
    }

    private func saveConnection() {
        CSDataStore.setKey(Self.roomCodeKey, roomCode)
        CSDataStore.setKey(Self.hostTokenKey, hostToken)
        CSDataStore.setKey(Self.roleKey, role.rawValue)
    }

    private func clearSavedConnection() {
        CSDataStore.removeKey(Self.roomCodeKey)
        CSDataStore.removeKey(Self.hostTokenKey)
        CSDataStore.removeKey(Self.roleKey)
    }

    // MARK: Room creation & connection

    func createRoom(name: String) async throws -> RoomInfo {
        let body: [String: Any] = ["roomName": name]
        let response = try await Requests.app.post("\(Self.server)/room/create", json: body)
        guard response.isSuccessful else {
            let json = try? response.jsonObject()
            let message = (json?["error"] as? String) ?? "Failed to create room"
            throw CS3Error.server(message)
        }
        return try response.parsed(RoomInfo.self)
    }

    func connectAsHost(roomCode: String, hostToken: String, name: String) {
        displayName = name.isEmpty ? "Host" : name
        self.hostToken = hostToken
        connect(roomCode: roomCode, role: .host, token: hostToken)
    }

    func connectAsViewer(code: String, name: String) {
        displayName = name.isEmpty ? "Guest" : name
        hostToken = ""
        connect(roomCode: code, role: .viewer, token: "")
    }

    private func connect(roomCode: String, role: WatchTogetherRole, token: String) {
        disconnect(clearSavedConnection: false)
        let trimmed = roomCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        self.roomCode = trimmed
        self.role = role
        saveConnection()

        var components = URLComponents(string: Self.wsServer)!
        var query: [URLQueryItem] = [
            URLQueryItem(name: "room", value: trimmed),
            URLQueryItem(name: "role", value: role.wireValue ?? "viewer")
        ]
        if !token.isEmpty {
            query.append(URLQueryItem(name: "token", value: token))
        }
        query.append(URLQueryItem(name: "name", value: displayName))
        components.queryItems = query
        guard let url = components.url else { return }

        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        self.session = session
        let socket = session.webSocketTask(with: url)
        self.socket = socket
        socket.resume()
        startReceiving()
        startPing()

        // Flush any pending content a host loaded before the socket opened.
        if role == .host, let pending = pendingContent {
            sendRaw(WatchTogetherOutbound.openContent(url: pending.url, apiName: pending.apiName,
                                                      name: pending.name, position: pending.positionMs,
                                                      playing: pending.playing, episodeId: pending.episodeId,
                                                      episode: pending.episode, season: pending.season))
            self.pendingContent = nil
        }
    }

    private func startReceiving() {
        receiveTask?.cancel()
        receiveTask = Task { [weak self] in
            guard let self, let socket else { return }
            while !Task.isCancelled {
                do {
                    let message = try await socket.receive()
                    switch message {
                    case .string(let text):
                        await self.handleMessage(text)
                    case .data(let data):
                        if let text = String(data: data, encoding: .utf8) {
                            await self.handleMessage(text)
                        }
                    @unknown default:
                        break
                    }
                } catch {
                    if !Task.isCancelled {
                        self.markDisconnected()
                    }
                    break
                }
            }
        }
    }

    private func startPing() {
        pingTask?.cancel()
        pingTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 20_000_000_000)
                guard let self, let socket else { return }
                if socket.state == .running {
                    socket.sendPing(pongReceiveHandler: { _ in })
                }
            }
        }
    }

    // MARK: Sending

    private func sendRaw(_ json: [String: Any]) {
        guard let socket, socket.state == .running else { return }
        guard let data = try? JSONSerialization.data(withJSONObject: json),
              let text = String(data: data, encoding: .utf8) else { return }
        socket.send(.string(text)) { _ in }
    }

    private func send(_ json: [String: Any]) {
        sendRaw(json)
    }

    func sendPlay(positionMs: Int64) {
        lastPositionMs = positionMs
        lastPlaying = true
        send(WatchTogetherOutbound.play(position: positionMs))
    }

    func sendPause(positionMs: Int64) {
        lastPositionMs = positionMs
        lastPlaying = false
        send(WatchTogetherOutbound.pause(position: positionMs))
    }

    func sendSeek(positionMs: Int64) {
        lastPositionMs = positionMs
        send(WatchTogetherOutbound.seek(position: positionMs))
    }

    func sendContent(url: String, apiName: String?, name: String, episodeId: Int?, episode: Int?,
                     season: Int?, positionMs: Int64, playing: Bool) {
        let content = ContentInfo(url: url, apiName: apiName ?? "", name: name,
                                  episodeId: episodeId, episode: episode, season: season)
        lastContent = content
        lastPositionMs = positionMs
        lastPlaying = playing
        if socket == nil || socket?.state != .running {
            // Buffer until the socket opens.
            pendingContent = (url, apiName, name, episodeId, episode, season, positionMs, playing)
            return
        }
        send(WatchTogetherOutbound.openContent(url: url, apiName: apiName, name: name,
                                               position: positionMs, playing: playing,
                                               episodeId: episodeId, episode: episode, season: season))
    }

    func sendNavigate(destination: String, url: String?, apiName: String?, name: String?) {
        send(WatchTogetherOutbound.navigate(destination: destination, url: url, apiName: apiName, name: name))
    }

    // MARK: Message handling (mirrors handleMessage)

    private func handleMessage(_ text: String) async {
        guard let data = text.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        let message = WatchTogetherMessage.parse(json)

        switch message {
        case .connected:
            // Android ignores CONNECTED.
            break

        case .roomState(let state):
            lastPositionMs = state.position
            lastPlaying = state.playing
            let content = ContentInfo(url: state.contentUrl ?? "",
                                      apiName: state.apiName ?? "",
                                      name: state.name ?? "",
                                      episodeId: Int(state.episodeId ?? ""),
                                      episode: state.episode,
                                      season: state.season)
            guard !content.url.isEmpty else { break }
            if !content.sameContent(as: lastFiredContent) {
                lastFiredContent = content
                lastContent = content
                contentListener?(content, state.position, state.playing)
            }

        case .openContent(let url, let apiName, let name, let position, let playing,
                          let episodeId, let episode, let season):
            let content = ContentInfo(url: url, apiName: apiName ?? "", name: name,
                                      episodeId: episodeId as? Int,
                                      episode: episode as? Int,
                                      season: season as? Int)
            lastContent = content
            lastFiredContent = content
            lastPositionMs = position
            lastPlaying = playing
            contentListener?(content, position, playing)

        case .play(let position):
            lastPositionMs = position
            lastPlaying = true
            onPlay?(position)

        case .pause(let position):
            lastPositionMs = position
            lastPlaying = false
            onPause?(position)

        case .seek(let position):
            lastPositionMs = position
            onSeek?(position)

        case .roomUsers(let users):
            self.users = users
            usersListener?(users)

        case .userJoined(let role, let name):
            let user = RoomUser(role: role == "host" ? .host : .viewer, name: name)
            if !users.contains(where: { $0.role == user.role && $0.name == user.name }) {
                users.append(user)
                usersListener?(users)
            }

        case .userDisconnected(let role, let name):
            users.removeAll { $0.role.rawValue == role && $0.name == name }
            usersListener?(users)

        case .navigate(let destination, let url, let apiName, let name):
            let info = NavigateInfo(destination: destination, url: url, apiName: apiName, name: name)
            if !info.sameAs(lastFiredNavigate) {
                lastFiredNavigate = info
                navigateListener?(info)
            }

        case .roomClosed:
            disconnect(clearSavedConnection: false)
            usersListener?(users)
            roomClosedListener?()

        case .error(let message):
            onError?(message)

        case .unknown:
            break
        }
    }

    // MARK: Lifecycle

    func disconnect(clearSavedConnection: Bool) {
        receiveTask?.cancel()
        receiveTask = nil
        pingTask?.cancel()
        pingTask = nil
        socket?.cancel(with: .goingAway, reason: nil)
        socket = nil
        session?.invalidateAndCancel()
        session = nil
        connected = false
        users = []
        lastContent = nil
        lastFiredContent = nil
        lastFiredNavigate = nil
        pendingContent = nil
        lastPositionMs = 0
        lastPlaying = false
        if clearSavedConnection {
            clearSavedConnection()
        }
        onDisconnected?()
        connectionListener?(false)
    }

    private func markDisconnected() {
        connected = false
        socket = nil
        onDisconnected?()
        connectionListener?(false)
    }

    /// Host leave: disconnect and clear saved state (mirrors MainActivity behavior).
    func leaveRoom() {
        disconnect(clearSavedConnection: true)
        role = .none
        roomCode = ""
    }
}