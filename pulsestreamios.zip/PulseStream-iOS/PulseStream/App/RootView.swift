import SwiftUI
import AVFoundation
import BackgroundTasks

// MARK: - BackgroundTaskRegistrar
/// Mirrors WorkManager background jobs (download queue, periodic backup).
enum BackgroundTaskRegistrar {
    static let downloadIdentifier = "com.pulsestream.ios.downloads"
    static let backupIdentifier = "com.pulsestream.ios.backup"

    static func register() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: downloadIdentifier, using: nil) { task in
            handleDownloadProcessing(task: task as! BGProcessingTask)
        }
        BGTaskScheduler.shared.register(forTaskWithIdentifier: backupIdentifier, using: nil) { task in
            handleBackup(task: task as! BGProcessingTask)
        }
    }

    static func scheduleDownloadProcessing() {
        let request = BGProcessingTaskRequest(identifier: downloadIdentifier)
        request.requiresNetworkConnectivity = true
        request.requiresExternalPower = false
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60)
        try? BGTaskScheduler.shared.submit(request)
    }

    private static func handleDownloadProcessing(task: BGProcessingTask) {
        task.expirationHandler = {
            task.setTaskCompleted(success: false)
        }
        // Downloads continue through the background URLSession; mark done.
        task.setTaskCompleted(success: true)
        scheduleDownloadProcessing()
    }

    private static func handleBackup(task: BGProcessingTask) {
        Task { @MainActor in
            BackupManager.shared.performBackup()
        }
        task.setTaskCompleted(success: true)
    }
}

// MARK: - BackupManager (mirrors BackupUtils)
@MainActor
final class BackupManager {
    static let shared = BackupManager()
    private let backupDir: URL

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        backupDir = docs.appendingPathComponent("backups", isDirectory: true)
        try? FileManager.default.createDirectory(at: backupDir, withIntermediateDirectories: true)
    }

    func performBackup() {
        let allKeys = CSDataStore.getKeys()
        var dict: [String: String] = [:]
        for key in allKeys {
            if let value = CSDataStore.getRaw(key) {
                dict[key] = value
            }
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let filename = "backup_\(formatter.string(from: Date())).json"
        let url = backupDir.appendingPathComponent(filename)
        if let data = try? JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted) {
            try? data.write(to: url)
        }
    }

    func getBackupFiles() -> [URL] {
        (try? FileManager.default.contentsOfDirectory(at: backupDir, includingPropertiesForKeys: [.creationDateKey])) ?? []
    }

    func restore(from url: URL) throws {
        guard let data = try? Data(contentsOf: url),
              let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String] else {
            throw CS3Error.decode("Invalid backup file")
        }
        for (key, value) in dict {
            CSDataStore.setRaw(key, value)
        }
    }
}

// MARK: - RootView
struct RootView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        Group {
            if appState.isSplashVisible {
                SplashView()
                    .transition(.opacity)
            } else if !appState.hasDoneSetup {
                SetupWizardView()
            } else {
                MainTabView()
            }
        }
        .task {
            // Mirrors the splash duration then proceeds.
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            withAnimation(.easeInOut(duration: 0.4)) {
                appState.isSplashVisible = false
            }
        }
    }
}

// MARK: - SplashView
struct SplashView: View {
    @Environment(\.appTheme) var theme

    var body: some View {
        ZStack {
            Color(theme.background).ignoresSafeArea()
            VStack(spacing: 16) {
                Image(systemName: "play.rectangle.fill")
                    .font(.system(size: 72))
                    .foregroundColor(Color(theme.accent))
                Text("PulseStream")
                    .font(.title.bold())
                    .foregroundColor(Color(theme.text))
                Text("Streaming made free")
                    .font(.subheadline)
                    .foregroundColor(Color(theme.textSecondary))
            }
        }
    }
}