import SwiftUI
import UIKit
import AVFoundation

@main
struct PulseStreamApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environment(\.appTheme, AppTheme(theme: appState.theme, primary: appState.primaryColor))
                .preferredColorScheme(appState.theme == .system ? nil : (appState.theme.isDark ? .dark : .light))
                .onOpenURL { url in
                    appState.handleDeepLink(url)
                }
        }
    }
}

// MARK: - AppDelegate
final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // Configure audio session for playback.
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)

        // Load bundled providers/extractors.
        Task { @MainActor in
            PluginRegistry.loadAllPlugins()
            // Clean stale watch-together session.
            WatchTogetherManager.shared.cleanupStaleSession()
        }

        // Register background tasks.
        BackgroundTaskRegistrar.register()

        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        BackgroundTaskRegistrar.scheduleDownloadProcessing()
    }
}

// MARK: - AppState (mirrors MainActivity-level app state)
@MainActor
final class AppState: ObservableObject {
    @Published var theme: CSTheme
    @Published var primaryColor: CSPrimaryColor
    @Published var hasDoneSetup: Bool
    @Published var selectedTab: AppTab = .liveTv
    @Published var navigationPath: [NavigationTarget] = []
    @Published var isSplashVisible = true
    @Published var nextSearchQuery: String?

    var didSelectSetup: Bool { hasDoneSetup }

    init() {
        let themeValue = CSDataStore.getKeyString("app_theme_key") ?? "System"
        theme = CSTheme(rawValue: themeValue) ?? .system
        let colorValue = CSDataStore.getKeyString("primary_color_key") ?? "Normal"
        primaryColor = CSPrimaryColor(rawValue: colorValue) ?? .normal
        hasDoneSetup = CSDataStore.getKeyBool("HAS_DONE_SETUP") ?? false
    }

    func setTheme(_ theme: CSTheme) {
        self.theme = theme
        CSDataStore.setKey("app_theme_key", theme.rawValue)
    }

    func setPrimaryColor(_ color: CSPrimaryColor) {
        self.primaryColor = color
        CSDataStore.setKey("primary_color_key", color.rawValue)
    }

    func completeSetup() {
        hasDoneSetup = true
        CSDataStore.setKey("HAS_DONE_SETUP", true)
    }

    func handleDeepLink(_ url: URL) {
        let scheme = url.scheme?.lowercased()
        let authority = url.host ?? ""
        guard scheme == "pulsestream" || scheme == "pulse" else { return }

        switch authority {
        case "player":
            // Direct playback: pulsestream://player/<encoded url>?name=...
            let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
            let path = String(url.path.dropFirst())
            let decoded = path.removingPercentEncoding ?? path
            let name = components?.queryItems?.first(where: { $0.name == "name" })?.value ?? "Stream"
            navigationPath.append(.player(url: decoded, name: name, episodeId: nil))
        case "search":
            nextSearchQuery = String(url.path.dropFirst()).removingPercentEncoding
            selectedTab = .search
        case "resume":
            navigationPath.append(.resumeWatching)
        default:
            // Try as a result URL
            let decoded = String(url.path.dropFirst()).removingPercentEncoding
            if let decoded, !decoded.isEmpty {
                navigationPath.append(.result(url: decoded, apiName: nil, name: nil))
            }
        }
    }
}

enum AppTab: Int, CaseIterable, Identifiable {
    case liveTv = 0
    case home = 1
    case search = 2
    case library = 3
    case downloads = 4
    case settings = 5

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .liveTv: return "Live TV"
        case .home: return "Movies & Series"
        case .search: return "Search"
        case .library: return "Library"
        case .downloads: return "Downloads"
        case .settings: return "Settings"
        }
    }

    var icon: String {
        switch self {
        case .liveTv: return "tv"
        case .home: return "film"
        case .search: return "magnifyingglass"
        case .library: return "bookmark"
        case .downloads: return "arrow.down.circle"
        case .settings: return "gearshape"
        }
    }
}

enum NavigationTarget: Hashable {
    case result(url: String, apiName: String?, name: String?)
    case player(url: String, name: String, episodeId: Int?)
    case watchTogether
    case extensions
    case subtitleSettings
    case qualityProfiles
    case downloadsQueue
    case livePlayer(channelId: String)
    case resumeWatching
}