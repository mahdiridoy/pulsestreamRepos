import SwiftUI

// MARK: - DownloadsView
struct DownloadsView: View {
    @StateObject private var queueManager = DownloadQueueManager.shared
    @StateObject private var downloadManager = DownloadManager.shared
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme

    var body: some View {
        NavigationStack(path: $appState.navigationPath) {
            ZStack {
                Color(theme.background).ignoresSafeArea()

                if queueManager.queue.isEmpty {
                    EmptyStateView(message: "No downloads yet", icon: "arrow.down.circle")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(queueManager.queue) { wrapper in
                            DownloadRow(item: wrapper.item,
                                        status: downloadManager.status(of: wrapper.item.id),
                                        progress: downloadManager.progress[wrapper.item.id] ?? 0,
                                        isPending: wrapper.isPending)
                                .swipeActions {
                                    Button(role: .destructive) {
                                        downloadManager.remove(id: wrapper.item.id)
                                        queueManager.remove(id: wrapper.item.id)
                                    } label: {
                                        Label("Delete", systemImage: "trash")
                                    }
                                }
                        }
                        .onMove { source, dest in
                            queueManager.reorder(fromOffsets: source, toOffset: dest)
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(.plain)
                }
            }
            .navigationDestination(for: NavigationTarget.self) { target in
                if case .player(let url, let name, let episodeId) = target {
                    PlayerContainerView(url: url, name: name, episodeId: episodeId)
                } else {
                    EmptyView()
                }
            }
            .navigationTitle("Downloads")
            .toolbar {
                if !queueManager.queue.isEmpty {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Clear All") {
                            queueManager.removeAll()
                        }
                        .foregroundColor(.red)
                    }
                    ToolbarItem(placement: .navigationBarLeading) {
                        EditButton()
                    }
                }
            }
        }
    }
}

struct DownloadRow: View {
    let item: DownloadQueueItem
    let status: DownloadType
    let progress: Double
    let isPending: Bool
    @Environment(\.appTheme) var theme

    private var statusText: String {
        switch status {
        case .isDownloading: return "Downloading"
        case .isDone: return "Downloaded"
        case .isPaused: return "Paused"
        case .isFailed: return "Failed"
        case .isStopped: return "Stopped"
        case .isPending: return "Queued"
        }
    }

    private var statusColor: Color {
        switch status {
        case .isDone: return .green
        case .isDownloading, .isPending: return Color(theme.accent)
        case .isPaused, .isStopped: return .orange
        case .isFailed: return .red
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            RemoteImage(url: item.posterUrl, placeholder: Image(systemName: "film"))
                .frame(width: 46, height: 64)
                .background(Color(theme.surfaceVariant))
                .clipShape(RoundedRectangle(cornerRadius: 6))

            VStack(alignment: .leading, spacing: 6) {
                Text(item.title)
                    .font(.subheadline.bold())
                    .foregroundColor(Color(theme.text))
                    .lineLimit(2)

                HStack(spacing: 6) {
                    Circle()
                        .fill(statusColor)
                        .frame(width: 8, height: 8)
                    Text(statusText)
                        .font(.caption)
                        .foregroundColor(statusColor)
                    if isPending {
                        Text("(waiting)")
                            .font(.caption)
                            .foregroundColor(Color(theme.textSecondary))
                    }
                }

                if status == .isDownloading || status == .isPending {
                    ProgressView(value: progress)
                        .tint(Color(theme.accent))
                }
            }
            Spacer()

            switch status {
            case .isDownloading:
                Button {
                    DownloadManager.shared.pause(id: item.id)
                } label: {
                    Image(systemName: "pause.circle")
                }
            case .isPaused:
                Button {
                    DownloadManager.shared.resume(id: item.id)
                } label: {
                    Image(systemName: "play.circle")
                }
            default:
                Button {
                    DownloadManager.shared.stop(id: item.id)
                } label: {
                    Image(systemName: "stop.circle")
                }
            }
        }
        .padding(.vertical, 4)
    }
}