import SwiftUI

// MARK: - ResultView
struct ResultView: View {
    @StateObject var viewModel: ResultViewModel
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme

    init(url: String, apiName: String?, name: String?) {
        _viewModel = StateObject(wrappedValue: ResultViewModel(url: url, apiName: apiName, name: name))
    }

    var body: some View {
        ZStack {
            AppBackground()
            content
        }
        .navigationTitle(viewModel.response?.name ?? viewModel.name ?? "Details")
        .fullScreenCover(item: $viewModel.playerConfig) { config in
            FullScreenPlayerView(config: config)
        }
        .task {
            viewModel.load()
        }
    }

    @ViewBuilder
    private var content: some View {
        switch viewModel.state {
        case .idle, .loading:
            LoadingGrid(count: 6)
        case .error(let message):
            ErrorStateView(message: message) {
                viewModel.load()
            }
        case .loaded:
            if let response = viewModel.response {
                loadedContent(response)
            }
        }
    }

    private func loadedContent(_ response: LoadResponse) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                header(response)

                if !response.tags.isEmpty {
                    tagRow(response.tags)
                }

                if let plot = response.plot, !plot.isEmpty {
                    Text(plot)
                        .font(.subheadline)
                        .foregroundColor(Color(theme.textSecondary))
                        .padding(.horizontal)
                }

                if !response.trailerUrls.isEmpty {
                    trailerRow(response.trailerUrls)
                }

                if !viewModel.episodes.isEmpty {
                    episodesSection
                }

                if !response.recommendations.isEmpty {
                    recommendationsSection(response.recommendations)
                }
            }
            .padding(.vertical)
        }
    }

    private func header(_ response: LoadResponse) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 14) {
                RemoteImage(url: response.posterUrl, headers: response.posterHeaders,
                            placeholder: Image(systemName: "film"))
                    .frame(width: 130, height: 190)
                    .background(Color(theme.surfaceVariant))
                    .clipShape(RoundedRectangle(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 8) {
                Text(response.name)
                    .font(.title3.bold())
                    .foregroundColor(Color(theme.text))
                    .lineLimit(3)

                if !response.score.isUnrated {
                    Label("\(response.score.toRating, specifier: "%.1f")/10", systemImage: "star.fill")
                        .font(.subheadline)
                        .foregroundColor(.yellow)
                }

                if let year = response.year {
                    Text("\(year)")
                        .font(.subheadline)
                        .foregroundColor(Color(theme.textSecondary))
                }

                if let status = response.showStatus.rawValue as String?, !status.isEmpty {
                    Text(status)
                        .font(.caption)
                        .foregroundColor(Color(theme.accent))
                }

                Spacer(minLength: 0)

                HStack(spacing: 12) {
                    actionButton(icon: viewModel.isFavorite ? "heart.fill" : "heart",
                                 tint: viewModel.isFavorite ? .red : Color(theme.textSecondary)) {
                        viewModel.toggleFavorite()
                    }
                    actionButton(icon: viewModel.isBookmarked ? "bookmark.fill" : "bookmark",
                                 tint: viewModel.isBookmarked ? .blue : Color(theme.textSecondary)) {
                        viewModel.toggleBookmark()
                    }
                    actionButton(icon: "play.tv", tint: Color(theme.accent)) {
                        viewModel.play()
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal)

        HStack(spacing: 12) {
            Button {
                viewModel.play()
            } label: {
                Label("Play", systemImage: "play.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(theme.accent))

            if viewModel.isLoadingLinks {
                ProgressView().padding(.horizontal)
            } else {
                Button {
                    Task { await viewModel.playMirror() }
                } label: {
                    Label("Play Mirror", systemImage: "arrow.triangle.2.circlepath")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .tint(Color(theme.accent))
            }

            Button {
                viewModel.downloadCurrentEpisode()
            } label: {
                Image(systemName: "arrow.down.circle")
            }
            .buttonStyle(.bordered)
            .tint(Color(theme.accent))
        }
        .padding(.horizontal)
        }
    }

    private func actionButton(icon: String, tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(tint)
                .frame(width: 40, height: 40)
                .background(Color(theme.surface))
                .clipShape(Circle())
        }
    }

    private func tagRow(_ tags: [String]) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(tags, id: \.self) { tag in
                    Text(tag)
                        .font(.caption)
                        .foregroundColor(Color(theme.accent))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color(theme.surface))
                        .clipShape(Capsule())
                }
            }
            .padding(.horizontal)
        }
    }

    private func trailerRow(_ trailers: [String]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionHeader(title: "Trailers")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(trailers, id: \.self) { trailer in
                        Button {
                            appState.navigationPath.append(.player(url: trailer, name: "Trailer", episodeId: nil))
                        } label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color(theme.surfaceVariant))
                                    .frame(width: 160, height: 90)
                                Image(systemName: "play.circle.fill")
                                    .font(.title)
                                    .foregroundColor(Color(theme.accent))
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
    }

    private var episodesSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionHeader(title: "Episodes")
            LazyVStack(spacing: 2) {
                ForEach(Array(viewModel.episodes.enumerated()), id: \.element.id) { index, episode in
                    EpisodeRow(episode: episode, isSelected: index == viewModel.currentEpisodeIndex)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            viewModel.selectEpisode(index: index)
                            viewModel.play()
                        }
                }
            }
        }
    }

    private func recommendationsSection(_ items: [SearchResponse]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionHeader(title: "More like this")
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 12) {
                    ForEach(items, id: \.id) { item in
                        PosterCard(item: item, width: 120, posterHeight: 170)
                            .onTapGesture {
                                appState.navigationPath.append(.result(url: item.url, apiName: item.apiName, name: item.name))
                            }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

struct EpisodeRow: View {
    let episode: ResultEpisode
    let isSelected: Bool
    @Environment(\.appTheme) var theme

    var body: some View {
        HStack(spacing: 12) {
            Text("E\(episode.episode)")
                .font(.caption.bold())
                .foregroundColor(isSelected ? Color(theme.accent) : Color(theme.textSecondary))
                .frame(width: 34, alignment: .leading)
            VStack(alignment: .leading, spacing: 2) {
                Text(episode.name ?? "Episode \(episode.episode)")
                    .font(.subheadline)
                    .foregroundColor(isSelected ? Color(theme.accent) : Color(theme.text))
                if let desc = episode.description, !desc.isEmpty {
                    Text(desc)
                        .font(.caption)
                        .foregroundColor(Color(theme.textSecondary))
                        .lineLimit(2)
                }
            }
            Spacer()
            Image(systemName: "play.circle")
                .foregroundColor(isSelected ? Color(theme.accent) : Color(theme.textSecondary))
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(isSelected ? Color(theme.accent).opacity(0.12) : Color.clear)
    }
}