import SwiftUI
import Combine

// MARK: - PlayerConfig (what the full-screen player needs to start)
struct PlayerConfig: Identifiable {
    var title: String
    var apiName: String?
    var generator: any VideoGenerator
    var startIndex: Int
    var episodeId: Int?

    var id: String { "\(apiName ?? "direct")|\(title)|\(startIndex)|\(episodeId ?? -1)" }
}

// MARK: - ResultViewModel (mirrors ui/result/ResultViewModel2.kt + PlayMirrorAction.kt)
@MainActor
final class ResultViewModel: ObservableObject {
    enum State {
        case idle
        case loading
        case loaded
        case error(String)
    }

    let url: String
    let apiName: String?
    let name: String?

    @Published private(set) var state: State = .idle
    @Published private(set) var response: LoadResponse?
    @Published private(set) var episodes: [ResultEpisode] = []
    @Published private(set) var currentEpisodeIndex = 0
    @Published private(set) var isFavorite = false
    @Published private(set) var isBookmarked = false
    @Published private(set) var isLoadingLinks = false
    @Published var playerConfig: PlayerConfig?

    private var loadTask: Task<Void, Never>?

    init(url: String, apiName: String?, name: String?) {
        self.url = url
        self.apiName = apiName
        self.name = name
        refreshLocalState()
    }

    func refreshLocalState() {
        let helper = CSDataStoreHelper.shared
        if let apiName {
            let data = helper.getFavorites(for: apiName)
            isFavorite = data.favorites.contains(url) || data.subscriptions.contains(url)
            isBookmarked = data.bookmarks.contains(url)
        }
    }

    var currentEpisode: ResultEpisode? {
        episodes.indices.contains(currentEpisodeIndex) ? episodes[currentEpisodeIndex] : nil
    }

    func load() {
        loadTask?.cancel()
        loadTask = Task { [weak self] in
            guard let self else { return }
            self.state = .loading
            let api = APIHolder.shared.getApiFromName(self.apiName ?? "") ?? APIHolder.shared.getApiFromUrl(self.url)
            guard let api else {
                self.state = .error("No provider found for this content")
                return
            }
            let repo = APIRepository(api: api)
            let result = await repo.load(url: self.url)
            switch result {
            case .loading:
                break
            case .success(let loadResponse):
                guard let loadResponse else {
                    self.state = .error("Content not found")
                    return
                }
                self.response = loadResponse
                self.episodes = self.buildEpisodes(from: loadResponse)
                self.currentEpisodeIndex = self.findInitialEpisode()
                self.state = .loaded
            case .failure(_, let message):
                self.state = .error(message.isEmpty ? "Load failed" : message)
            }
        }
    }

    private func buildEpisodes(from response: LoadResponse) -> [ResultEpisode] {
        if let tv = response as? TvSeriesLoadResponse {
            return tv.episodes.map { ep in
                ResultEpisode(id: ep.id, name: ep.name ?? "Episode \(ep.episode)",
                              season: ep.season, episode: ep.episode, posterUrl: ep.posterUrl,
                              data: ep, description: ep.description)
            }
        }
        if let anime = response as? AnimeLoadResponse {
            var list: [ResultEpisode] = []
            let seasons = anime.episodes.keys.sorted()
            for season in seasons {
                for ep in anime.episodes[season] ?? [] {
                    list.append(ResultEpisode(id: ep.id, name: ep.name ?? "Episode \(ep.episode)",
                                              season: ep.season, episode: ep.episode,
                                              posterUrl: ep.posterUrl, data: ep, description: ep.description))
                }
            }
            return list
        }
        // Movies / live streams: single implicit episode.
        let ep = Episode(id: url.hashValue & 0x7fffffff, name: name ?? response.name,
                         season: 1, episode: 1)
        ep.url = url
        return [ResultEpisode(id: ep.id, name: ep.name, season: 1, episode: 1,
                              posterUrl: response.posterUrl, data: ep, description: response.plot)]
    }

    private func findInitialEpisode() -> Int {
        guard !episodes.isEmpty else { return 0 }
        // Resume from last watched episode if any.
        let helper = CSDataStoreHelper.shared
        let last = helper.getLastWatchedEpisode(url: url, apiName: apiName)
        if let idx = episodes.firstIndex(where: { $0.episode == last.episode && $0.season == last.season }) {
            return idx
        }
        return 0
    }

    // MARK: Actions

    func selectEpisode(index: Int) {
        currentEpisodeIndex = index
    }

    func toggleFavorite() {
        guard let apiName else { return }
        let helper = CSDataStoreHelper.shared
        var data = helper.getFavorites(for: apiName)
        if data.favorites.contains(url) {
            data.favorites.removeAll { $0 == url }
            data.subscriptions.removeAll { $0 == url }
        } else {
            data.favorites.append(url)
        }
        helper.setFavorites(data, for: apiName)
        isFavorite.toggle()
    }

    func toggleBookmark() {
        guard let apiName else { return }
        let helper = CSDataStoreHelper.shared
        var data = helper.getFavorites(for: apiName)
        if data.bookmarks.contains(url) {
            data.bookmarks.removeAll { $0 == url }
        } else {
            data.bookmarks.append(url)
        }
        helper.setFavorites(data, for: apiName)
        isBookmarked.toggle()
    }

    /// Mirrors the normal "Play" flow: open the player with the repository generator
    /// (link cache + priority sorting happen inside the player).
    func play() {
        guard let api = APIHolder.shared.getApiFromName(apiName ?? "") ?? APIHolder.shared.getApiFromUrl(url) else { return }
        let generator = RepoLinkGenerator(episodes, page: response, apiName: api.name)
        playerConfig = PlayerConfig(title: response?.name ?? name ?? "",
                                    apiName: api.name, generator: generator,
                                    startIndex: currentEpisodeIndex,
                                    episodeId: currentEpisode?.id)
    }

    /// Mirrors PlayMirrorAction: pre-loads links for the current episode and opens the
    /// player with a single pre-selected mirror link (oneSource = true).
    func playMirror() async {
        guard let api = APIHolder.shared.getApiFromName(apiName ?? "") ?? APIHolder.shared.getApiFromUrl(url),
              let episode = currentEpisode else { return }
        isLoadingLinks = true
        defer { isLoadingLinks = false }

        let repo = APIRepository(api: api)
        let result = await repo.loadLinks(episode: episode.data)
        guard case .success(let linkResult) = result, let link = linkResult.links.first else { return }

        var subs: [SubtitleData] = []
        for sub in linkResult.subtitles {
            subs.append(SubtitleData(originalName: sub.name, url: sub.url ?? "", origin: .url,
                                     languageCode: sub.lang))
        }

        let generator = PlayMirrorGenerator(allEpisodes: episodes, startIndex: currentEpisodeIndex,
                                            link: link, subs: subs, page: response, apiName: api.name)
        playerConfig = PlayerConfig(title: response?.name ?? name ?? "",
                                    apiName: api.name, generator: generator,
                                    startIndex: currentEpisodeIndex,
                                    episodeId: episode.id)
    }

    func downloadCurrentEpisode() {
        guard let episode = currentEpisode else { return }
        let id = "\(url)|\(episode.id)".hashValue & 0x7fffffff
        let item = DownloadQueueItem(id: id, episode: episode.episode, season: episode.season,
                                     title: "\(response?.name ?? name ?? "") - E\(episode.episode)",
                                     url: url, apiName: apiName ?? "", posterUrl: response?.posterUrl,
                                     tvType: response?.type ?? .movie)
        DownloadQueueManager.shared.add(item)
    }
}