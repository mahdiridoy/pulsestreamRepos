import SwiftUI
import Combine

// MARK: - SearchViewModel (mirrors ui/search/SearchViewModel.kt)
@MainActor
final class SearchViewModel: ObservableObject {
    @Published var query: String = ""
    @Published var results: [SearchResponse] = []
    @Published private(set) var suggestions: [String] = []
    @Published private(set) var history: [String] = []
    @Published private(set) var isLoading = false
    @Published private(set) var error: String?
    @Published var hasMore = false
    private var searchTask: Task<Void, Never>?
    private var page = 0
    private var currentQuery = ""

    init() {
        history = CSDataStoreHelper.shared.getSearchHistory()
    }

    func clear() {
        query = ""
        results = []
        suggestions = []
    }

    func search() {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count > 1 else {
            results = []
            return
        }
        currentQuery = trimmed
        page = 0
        CSDataStoreHelper.shared.addSearchHistory(trimmed)
        searchTask?.cancel()
        searchTask = Task { [weak self] in
            guard let self else { return }
            self.isLoading = true
            self.error = nil
            var collected: [SearchResponse] = []
            let providers = APIHolder.shared.apis.filter { $0.enabled }
            for provider in providers {
                if Task.isCancelled { break }
                let repo = APIRepository(api: provider)
                let result = await repo.search(query: trimmed)
                if case .success(let list) = result, let items = list?.items {
                    collected.append(contentsOf: AdultContentFilter.filterList(items))
                    if let hasMore = list?.hasNext { self.hasMore = hasMore }
                }
            }
            if Task.isCancelled { return }
            let filtered = await AdultContentFilter.filterByImage(collected)
            self.results = filtered
            self.history = CSDataStoreHelper.shared.getSearchHistory()
            self.isLoading = false
        }
    }

    func loadMore() async {
        guard hasMore else { return }
        page += 1
        let providers = APIHolder.shared.apis.filter { $0.enabled }
        for provider in providers {
            if let result = try? await provider.search(query: currentQuery, page: page) {
                results.append(contentsOf: result.items)
                hasMore = result.hasNext
            }
        }
    }

    func loadSuggestions() async {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2 else {
            suggestions = []
            return
        }
        // 300ms debounce (mirrors SearchViewModel.fetchSuggestions).
        try? await Task.sleep(nanoseconds: 300_000_000)
        guard !Task.isCancelled else { return }
        suggestions = await SearchSuggestionApi.getSuggestions(query: trimmed)
    }

    func addToHistory() {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        CSDataStoreHelper.shared.addSearchHistory(trimmed)
        history = CSDataStoreHelper.shared.getSearchHistory()
    }

    func clearHistory() {
        CSDataStoreHelper.shared.clearSearchHistory()
        history = []
    }
}

// MARK: - SearchView
struct SearchView: View {
    @StateObject private var viewModel = SearchViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme

    var body: some View {
        NavigationStack(path: $appState.navigationPath) {
            ZStack {
                AppBackground()
                VStack(spacing: 0) {
                    searchBar
                    content
                }
                .task(id: viewModel.query) {
                    await viewModel.loadSuggestions()
                }
            }
            .navigationDestination(for: NavigationTarget.self) { target in
                destination(for: target)
            }
            .navigationTitle("Search")
            .toolbar(.hidden, for: .navigationBar)
        }
        .onAppear {
            if let query = appState.nextSearchQuery {
                viewModel.query = query
                appState.nextSearchQuery = nil
                viewModel.search()
            }
        }
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(Color(theme.textSecondary))
                TextField("Search", text: $viewModel.query)
                    .foregroundColor(Color(theme.text))
                    .autocorrectionDisabled()
                    .submitLabel(.search)
                    .onSubmit {
                        viewModel.addToHistory()
                        viewModel.search()
                    }
                if !viewModel.query.isEmpty {
                    Button {
                        viewModel.clear()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(Color(theme.textSecondary))
                    }
                }
            }
            .padding(10)
            .background(Color(theme.surface))
            .clipShape(RoundedRectangle(cornerRadius: 10))

            Button("Search") {
                viewModel.addToHistory()
                viewModel.search()
            }
            .foregroundColor(Color(theme.accent))
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
    }

    @ViewBuilder
    private var content: some View {
        if !viewModel.suggestions.isEmpty && viewModel.results.isEmpty {
            suggestionsList
        } else if viewModel.isLoading && viewModel.results.isEmpty {
            LoadingGrid(count: 10)
        } else if viewModel.results.isEmpty && !viewModel.history.isEmpty {
            historyList
        } else if viewModel.results.isEmpty {
            EmptyStateView(message: "Search for movies, series and more", icon: "magnifyingglass")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            resultsGrid
        }
    }

    private var resultsGrid: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 120), spacing: 12)], spacing: 16) {
                ForEach(viewModel.results, id: \.id) { item in
                    PosterCard(item: item, width: 120, posterHeight: 170)
                        .onTapGesture {
                            appState.navigationPath.append(.result(url: item.url, apiName: item.apiName, name: item.name))
                        }
                }
            }
            .padding()
        }
    }

    private var historyList: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 4) {
                HStack {
                    SectionHeader(title: "Search history")
                    Spacer()
                    Button("Clear") {
                        viewModel.clearHistory()
                    }
                    .font(.caption)
                    .foregroundColor(Color(theme.accent))
                    .padding(.trailing)
                }
                ForEach(viewModel.history, id: \.self) { item in
                    HStack {
                        Image(systemName: "clock")
                            .foregroundColor(Color(theme.textSecondary))
                        Text(item)
                            .foregroundColor(Color(theme.text))
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        viewModel.query = item
                        viewModel.addToHistory()
                        viewModel.search()
                    }
                }
            }
        }
    }

    private var suggestionsList: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                ForEach(viewModel.suggestions, id: \.self) { suggestion in
                    HStack {
                        Image(systemName: "arrow.up.right")
                            .font(.caption)
                            .foregroundColor(Color(theme.textSecondary))
                        Text(suggestion)
                            .foregroundColor(Color(theme.text))
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 10)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        viewModel.query = suggestion
                        viewModel.addToHistory()
                        viewModel.search()
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func destination(for target: NavigationTarget) -> some View {
        switch target {
        case .result(let url, let apiName, let name):
            ResultView(url: url, apiName: apiName, name: name)
        case .player(let url, let name, let episodeId):
            PlayerContainerView(url: url, name: name, episodeId: episodeId)
        default:
            EmptyView()
        }
    }
}