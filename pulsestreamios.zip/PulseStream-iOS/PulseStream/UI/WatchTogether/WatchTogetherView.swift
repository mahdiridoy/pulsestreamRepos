import SwiftUI
import UIKit

// MARK: - WatchTogetherPanel
/// Panel shown inside the player to create/join/leave a Watch Together room.
struct WatchTogetherPanel: View {
    @Binding var isPresented: Bool
    @ObservedObject var manager = WatchTogetherManager.shared
    @State private var mode: Mode = .menu
    @State private var roomName = "My Watch Party"
    @State private var joinCode = ""
    @State private var displayName = ""
    @State private var isWorking = false
    @State private var errorMessage: String?

    enum Mode {
        case menu
        case create
        case join
        case room
    }

    var body: some View {
        VStack(spacing: 16) {
            header

            if manager.connected {
                roomView
            } else {
                switch mode {
                case .menu: menuView
                case .create: createView
                case .join: joinView
                case .room: EmptyView()
                }
            }
        }
        .padding(20)
        .frame(maxWidth: 420)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .padding(20)
        .onAppear {
            displayName = CSDataStore.getKeyString("wt_display_name") ?? UIDevice.current.name
            if manager.connected {
                mode = .room
            }
        }
    }

    private var header: some View {
        HStack {
            Text("Watch Together")
                .font(.headline)
                .foregroundColor(.white)
            Spacer()
            Button {
                isPresented = false
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .foregroundColor(.white.opacity(0.7))
            }
        }
    }

    private var menuView: some View {
        VStack(spacing: 12) {
            Button {
                mode = .create
            } label: {
                Label("Create Room", systemImage: "plus.circle.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(.white)

            Button {
                mode = .join
            } label: {
                Label("Join Room", systemImage: "person.badge.plus")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .tint(.white)
        }
    }

    private var createView: some View {
        VStack(spacing: 12) {
            TextField("Room name", text: $roomName)
                .textFieldStyle(.roundedBorder)
            TextField("Your name", text: $displayName)
                .textFieldStyle(.roundedBorder)

            if let errorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundColor(.red)
            }

            if isWorking {
                ProgressView()
            } else {
                HStack {
                    Button("Cancel") { mode = .menu }
                        .buttonStyle(.bordered)
                    Button("Create") { createRoom() }
                        .buttonStyle(.borderedProminent)
                        .tint(.white)
                }
            }
        }
    }

    private var joinView: some View {
        VStack(spacing: 12) {
            TextField("Room code", text: $joinCode)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.characters)
            TextField("Your name", text: $displayName)
                .textFieldStyle(.roundedBorder)

            if let errorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundColor(.red)
            }

            if isWorking {
                ProgressView()
            } else {
                HStack {
                    Button("Cancel") { mode = .menu }
                        .buttonStyle(.bordered)
                    Button("Join") { joinRoom() }
                        .buttonStyle(.borderedProminent)
                        .tint(.white)
                }
            }
        }
    }

    private var roomView: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Room Code:")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
                Text(manager.roomCode)
                    .font(.title3.bold().monospaced())
                    .foregroundColor(.yellow)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("People in room")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
                ForEach(manager.users, id: \.name) { user in
                    HStack {
                        Image(systemName: user.role == .host ? "crown.fill" : "person.fill")
                            .foregroundColor(user.role == .host ? .yellow : .white)
                        Text(user.name)
                            .foregroundColor(.white)
                        Spacer()
                        Text(user.role == .host ? "Host" : "Viewer")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.6))
                    }
                }
            }

            Button(role: .destructive) {
                manager.leaveRoom()
                mode = .menu
                isPresented = false
            } label: {
                Label("Leave Room", systemImage: "door.left.hand.open")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
        }
    }

    private func createRoom() {
        isWorking = true
        errorMessage = nil
        let name = roomName.isEmpty ? "My Watch Party" : roomName
        let user = displayName.isEmpty ? UIDevice.current.name : displayName
        CSDataStore.setKey("wt_display_name", user)
        Task {
            do {
                let room = try await manager.createRoom(name: name)
                manager.connectAsHost(roomCode: room.roomCode, hostToken: room.hostToken, name: user)
                mode = .room
            } catch {
                errorMessage = "Failed to create room: \(error.localizedDescription)"
            }
            isWorking = false
        }
    }

    private func joinRoom() {
        let code = joinCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !code.isEmpty else {
            errorMessage = "Enter a room code"
            return
        }
        isWorking = true
        errorMessage = nil
        let user = displayName.isEmpty ? UIDevice.current.name : displayName
        CSDataStore.setKey("wt_display_name", user)
        manager.connectAsViewer(code: code, name: user)
        isWorking = false
        mode = .room
    }
}

// MARK: - WatchTogetherListView (standalone screen reachable from Settings)
struct WatchTogetherListView: View {
    @ObservedObject var manager = WatchTogetherManager.shared
    @Environment(\.appTheme) var theme
    @State private var showPanel = false

    var body: some View {
        ZStack {
            Color(theme.background).ignoresSafeArea()
            VStack(spacing: 16) {
                if manager.connected {
                    HStack {
                        Text("Room: \(manager.roomCode)")
                            .font(.headline)
                            .foregroundColor(Color(theme.text))
                        Spacer()
                        Button("Leave") { manager.leaveRoom() }
                            .foregroundColor(.red)
                    }
                    .padding()
                    .background(Color(theme.surface))
                    .clipShape(RoundedRectangle(cornerRadius: 12))

                    Text("\(manager.users.count) in room")
                        .foregroundColor(Color(theme.textSecondary))
                } else {
                    EmptyStateView(message: "Watch content together with friends in sync",
                                   icon: "person.2.fill")
                }

                Button {
                    showPanel = true
                } label: {
                    Label(manager.connected ? "Manage room" : "Start Watch Together",
                          systemImage: "person.2.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(Color(theme.accent))
            }
            .padding()
        }
        .navigationTitle("Watch Together")
        .overlay {
            if showPanel {
                ZStack {
                    Color.black.opacity(0.5).ignoresSafeArea()
                        .onTapGesture { showPanel = false }
                    WatchTogetherPanel(isPresented: $showPanel)
                }
                .transition(.opacity)
            }
        }
    }
}