import SwiftUI

// MARK: - MainTabView
/// Mirrors the Android bottom navigation with 6 destinations.
struct MainTabView: View {
    @EnvironmentObject var appState: AppState
    @State private var tab: AppTab = .liveTv

    var body: some View {
        TabView(selection: $tab) {
            LiveTVView()
                .tabItem { Label("Live TV", systemImage: "tv") }
                .tag(AppTab.liveTv)

            HomeView()
                .tabItem { Label("Movies & Series", systemImage: "film") }
                .tag(AppTab.home)

            SearchView()
                .tabItem { Label("Search", systemImage: "magnifyingglass") }
                .tag(AppTab.search)

            LibraryView()
                .tabItem { Label("Library", systemImage: "bookmark") }
                .tag(AppTab.library)

            DownloadsView()
                .tabItem { Label("Downloads", systemImage: "arrow.down.circle") }
                .tag(AppTab.downloads)

            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
                .tag(AppTab.settings)
        }
        .tint(Color(uiColor: .init(hex: 0x3D50FA)))
        .onChange(of: tab) { newValue in
            appState.selectedTab = newValue
        }
    }
}