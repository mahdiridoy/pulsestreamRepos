import SwiftUI
import AVKit
import AVFoundation
import UIKit

// MARK: - PlayerSurface
/// Wraps the AVPlayerLayer inside a SwiftUI view.
struct PlayerSurface: UIViewRepresentable {
    let player: AVPlayer

    func makeUIView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.playerLayer.player = player
        view.playerLayer.videoGravity = .resizeAspect
        view.backgroundColor = .black
        return view
    }

    func updateUIView(_ uiView: PlayerLayerView, context: Context) {}

    final class PlayerLayerView: UIView {
        override class var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }
}

// MARK: - FullScreenPlayerView
struct FullScreenPlayerView: View {
    @StateObject var viewModel: PlayerViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var showSubtitlePicker = false
    @State private var showSpeedMenu = false
    @State private var showWatchTogether = false

    init(config: PlayerConfig) {
        _viewModel = StateObject(wrappedValue: PlayerViewModel(config: config))
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                PlayerSurface(player: viewModel.player.player)
                    .ignoresSafeArea()

                if viewModel.isLoading {
                    loadingOverlay
                } else if let error = viewModel.loadError {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                        Text(error).foregroundColor(.white)
                        Button("Close") { dismiss() }
                            .buttonStyle(.borderedProminent)
                    }
                } else {
                    controlsOverlay
                }
            }
            .overlay(alignment: .bottom) {
                if showWatchTogether {
                    WatchTogetherPanel(isPresented: $showWatchTogether)
                }
            }
            .sheet(isPresented: $showSubtitlePicker) {
                SubtitlePickerView(viewModel: viewModel)
            }
            .confirmationDialog("Playback Speed", isPresented: $showSpeedMenu, titleVisibility: .visible) {
                ForEach([0.5, 0.75, 1.0, 1.25, 1.5, 2.0], id: \.self) { speed in
                    Button("\(speed, specifier: "%.2f")x") {
                        viewModel.changeSpeed(speed)
                    }
                }
            }
        }
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .task {
            await viewModel.start()
        }
        .onDisappear {
            viewModel.onDisappear()
        }
    }

    // MARK: Overlays

    private var loadingOverlay: some View {
        VStack(spacing: 12) {
            ProgressView()
                .scaleEffect(1.4)
                .tint(.white)
            Text("Loading sources…")
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.8))
        }
    }

    private var controlsOverlay: some View {
        ZStack {
            // Tap anywhere toggles controls.
            Color.black.opacity(viewModel.controlsVisible ? 0.35 : 0.001)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation { viewModel.controlsVisible.toggle() }
                }

            if viewModel.controlsVisible {
                VStack {
                    topBar
                    Spacer()
                    centerControls
                    Spacer()
                    bottomBar
                }
                .transition(.opacity)
            }

            if let stamp = viewModel.player.getCurrentTimestamp() {
                skipStampButton(stamp)
            }
        }
    }

    private var topBar: some View {
        HStack {
            Button {
                dismiss()
            } label: {
                Image(systemName: "chevron.down")
                    .font(.title3)
                    .foregroundColor(.white)
                    .frame(width: 40, height: 40)
                    .background(Color.black.opacity(0.5))
                    .clipShape(Circle())
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(viewModel.title)
                    .font(.headline)
                    .foregroundColor(.white)
                    .lineLimit(1)
                if viewModel.totalEpisodes > 1 {
                    Text("\(viewModel.currentVideoIndex + 1) / \(viewModel.totalEpisodes)")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.7))
                }
            }
            Spacer()

            Button {
                showWatchTogether.toggle()
            } label: {
                Image(systemName: "person.2.fill")
                    .font(.title3)
                    .foregroundColor(viewModel.wtManager.connected ? .yellow : .white)
                    .frame(width: 40, height: 40)
                    .background(Color.black.opacity(0.5))
                    .clipShape(Circle())
            }

            Button {
                showSpeedMenu = true
            } label: {
                Text("\(viewModel.player.playbackSpeed, specifier: "%.2f")x")
                    .font(.caption.bold())
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(Color.black.opacity(0.5))
                    .clipShape(Capsule())
            }

            Button {
                showSubtitlePicker = true
            } label: {
                Image(systemName: "captions.bubble")
                    .font(.title3)
                    .foregroundColor(viewModel.selectedSubtitle != nil ? .green : .white)
                    .frame(width: 40, height: 40)
                    .background(Color.black.opacity(0.5))
                    .clipShape(Circle())
            }
        }
        .padding(.horizontal)
        .padding(.top, 8)
    }

    private var centerControls: some View {
        HStack(spacing: 40) {
            controlButton(icon: "gobackward.30") { viewModel.seekBack() }
            if viewModel.hasPrevEpisode {
                controlButton(icon: "backward.end") { viewModel.prevEpisode() }
            }
            Button {
                viewModel.togglePlayPause()
            } label: {
                Image(systemName: viewModel.player.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 64))
                    .foregroundColor(.white)
                    .shadow(radius: 4)
            }
            if viewModel.hasNextEpisode {
                controlButton(icon: "forward.end") { viewModel.nextEpisode() }
            }
            controlButton(icon: "goforward.30") { viewModel.seekForward() }
        }
    }

    private func controlButton(icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 36))
                .foregroundColor(.white)
                .frame(width: 56, height: 56)
                .background(Color.black.opacity(0.4))
                .clipShape(Circle())
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 6) {
            Slider(
                value: Binding(
                    get: {
                        guard viewModel.player.durationMs > 0 else { return 0 }
                        return Double(viewModel.player.positionMs) / Double(viewModel.player.durationMs)
                    },
                    set: { viewModel.seek(to: $0) }
                ),
                in: 0...1
            )
            .tint(.white)
            .disabled(viewModel.player.isLive)

            HStack {
                Text(timeString(viewModel.player.positionMs))
                Spacer()
                if viewModel.player.isLive {
                    Text("LIVE")
                        .font(.caption.bold())
                        .foregroundColor(.red)
                } else {
                    Text(timeString(viewModel.player.durationMs))
                }
            }
            .font(.caption.monospacedDigit())
            .foregroundColor(.white.opacity(0.8))
        }
        .padding(.horizontal)
        .padding(.bottom, 8)
    }

    private func skipStampButton(_ stamp: VideoSkipStamp) -> some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Button {
                    viewModel.player.skipCurrentChapter()
                } label: {
                    Label(stamp.kind == .intro ? "Skip Intro" : "Skip Outro", systemImage: "forward.fill")
                        .font(.subheadline.bold())
                        .foregroundColor(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(Color.black.opacity(0.7))
                        .clipShape(Capsule())
                }
                .padding()
            }
        }
    }

    private func timeString(_ ms: Int64) -> String {
        let total = max(0, ms / 1000)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%02d:%02d", m, s)
    }
}

// MARK: - SubtitlePickerView
struct SubtitlePickerView: View {
    @ObservedObject var viewModel: PlayerViewModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appTheme) var theme

    var body: some View {
        NavigationStack {
            List {
                Section("Subtitles") {
                    Button {
                        viewModel.selectedSubtitle = nil
                        dismiss()
                    } label: {
                        Label("Off", systemImage: viewModel.selectedSubtitle == nil ? "checkmark" : "")
                    }
                    ForEach(viewModel.subtitles) { sub in
                        Button {
                            viewModel.selectedSubtitle = sub
                            CSDataStore.setKey("subtitle_language_key", sub.languageCode ?? "")
                            dismiss()
                        } label: {
                            HStack {
                                Text(sub.name)
                                    .foregroundColor(Color(theme.text))
                                Spacer()
                                if viewModel.selectedSubtitle?.id == sub.id {
                                    Image(systemName: "checkmark")
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Subtitles")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

// MARK: - PlayerContainerView
/// Player for direct URL navigation (deep links, trailers, downloads).
struct PlayerContainerView: View {
    let url: String
    let name: String
    let episodeId: Int?

    var body: some View {
        let config = PlayerConfig(
            title: name,
            apiName: nil,
            generator: LinkGenerator([LinkGenerator.BasicLinkItem(url: url, name: name)],
                                     extract: true, id: episodeId ?? url.hashValue & 0x7fffffff),
            startIndex: 0,
            episodeId: episodeId
        )
        FullScreenPlayerView(config: config)
            .navigationBarBackButtonHidden()
            .toolbar(.hidden, for: .navigationBar)
    }
}

// MARK: - LiveTVPlayerView
struct LiveTVPlayerView: View {
    let channelId: String
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    @State private var controlsVisible = true
    @Environment(\.appTheme) var theme

    private var channel: LiveTvChannel? { LiveTvRepository.shared.channel(id: channelId) }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                if let channel, let url = URL(string: channel.streamUrl) {
                    AVPlayerController(player: player)
                        .ignoresSafeArea()
                        .onAppear {
                            if player == nil {
                                let newPlayer = AVPlayer(url: url)
                                newPlayer.automaticallyWaitsToMinimizeStalling = true
                                newPlayer.play()
                                player = newPlayer
                            }
                        }
                } else {
                    VStack(spacing: 12) {
                        ProgressView().tint(.white)
                        Text("Loading channel…").foregroundColor(.white)
                    }
                }

                Color.black.opacity(controlsVisible ? 0.35 : 0.001)
                    .ignoresSafeArea()
                    .onTapGesture { withAnimation { controlsVisible.toggle() } }

                if controlsVisible {
                    VStack {
                        HStack {
                            Button { dismiss() } label: {
                                Image(systemName: "chevron.down")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                    .frame(width: 40, height: 40)
                                    .background(Color.black.opacity(0.5))
                                    .clipShape(Circle())
                            }
                            Text(channel?.name ?? "Live TV")
                                .font(.headline)
                                .foregroundColor(.white)
                                .lineLimit(1)
                            Spacer()
                            Button {
                                switchChannel(next: false)
                            } label: {
                                Image(systemName: "backward.end")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                    .frame(width: 40, height: 40)
                                    .background(Color.black.opacity(0.5))
                                    .clipShape(Circle())
                            }
                            Button {
                                switchChannel(next: true)
                            } label: {
                                Image(systemName: "forward.end")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                    .frame(width: 40, height: 40)
                                    .background(Color.black.opacity(0.5))
                                    .clipShape(Circle())
                            }
                        }
                        .padding(.horizontal)
                        .padding(.top, 8)
                        Spacer()
                    }
                }
            }
        }
        .statusBarHidden()
    }

    private func switchChannel(next: Bool) {
        guard let current = channel else { return }
        let target = next
            ? LiveTvRepository.shared.nextChannel(after: current.id)
            : LiveTvRepository.shared.previousChannel(before: current.id)
        guard let target, let url = URL(string: target.streamUrl) else { return }
        LiveTvRepository.shared.lastChannelId = target.id
        player?.replaceCurrentItem(with: AVPlayerItem(url: url))
        player?.play()
    }
}

// MARK: - AVPlayerController
struct AVPlayerController: UIViewControllerRepresentable {
    let player: AVPlayer?

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspect
        return controller
    }

    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        uiViewController.player = player
    }
}