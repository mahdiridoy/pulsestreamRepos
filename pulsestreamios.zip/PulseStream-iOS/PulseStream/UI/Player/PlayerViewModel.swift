import SwiftUI
import AVFoundation
import Combine

// MARK: - PlayerViewModel
/// Drives playback from a `VideoGenerator` (mirrors GeneratorPlayer + AbstractPlayerFragment behaviors:
/// auto-select, priority sorting, skip stamps, watch-together, resume position, next-episode autoplay).
@MainActor
final class PlayerViewModel: ObservableObject {
    let config: PlayerConfig

    @Published private(set) var currentVideoIndex: Int
    @Published private(set) var links: [ExtractorLink] = []
    @Published private(set) var subtitles: [SubtitleData] = []
    @Published private(set) var currentLinkIndex = 0
    @Published var selectedSubtitle: SubtitleData?
    @Published private(set) var isLoading = true
    @Published private(set) var loadError: String?
    @Published var controlsVisible = true

    let player = CSPlayer()
    let wtManager = WatchTogetherManager.shared

    private var generator: any VideoGenerator
    private var didSendContent = false
    private var isApplyingRemote = false

    init(config: PlayerConfig) {
        self.config = config
        self.generator = config.generator
        self.currentVideoIndex = config.startIndex
        setupPlayerCallbacks()
        setupWatchTogether()
    }

    var totalEpisodes: Int { generator.videos.count }
    var currentEpisode: ResultEpisode? {
        generator.videos.indices.contains(currentVideoIndex) ? generator.videos[currentVideoIndex] : nil
    }
    var hasNextEpisode: Bool { generator.hasNext(currentVideoIndex) }
    var hasPrevEpisode: Bool { generator.hasPrev(currentVideoIndex) }

    var title: String {
        currentEpisode?.name ?? config.title
    }

    // MARK: Setup

    private func setupPlayerCallbacks() {
        player.eventHandler = { [weak self] event in
            Task { @MainActor in
                self?.handlePlayerEvent(event)
            }
        }
        player.statusChanged = { [weak self] status, source in
            Task { @MainActor in
                self?.handleStatus(status, source: source)
            }
        }
        player.positionChanged = { [weak self] positionMs, durationMs in
            Task { @MainActor in
                self?.handlePosition(positionMs, durationMs: durationMs)
            }
        }
    }

    private func handlePlayerEvent(_ event: PlayerEvent) {
        switch event {
        case .videoEnded:
            playNextEpisode()
        case .position(let positionMs, _, _):
            // Sync playback position to the room while connected.
            if wtManager.connected && !isApplyingRemote {
                if player.isPlaying {
                    wtManager.sendPlay(positionMs: positionMs)
                } else {
                    wtManager.sendPause(positionMs: positionMs)
                }
            }
        case .timestampInvoked(let stamp):
            // Auto-skip intro/outro when a stamp is detected.
            player.skipCurrentChapter()
        default:
            break
        }
    }

    private func handleStatus(_ status: CSPlayerLoading, source: PlayerEventSource) {
        guard source != .sync else { return }
        switch status {
        case .isPlaying:
            if wtManager.connected {
                wtManager.sendPlay(positionMs: player.positionMs)
            }
        case .isPaused:
            if wtManager.connected {
                wtManager.sendPause(positionMs: player.positionMs)
            }
        default:
            break
        }
    }

    private func handlePosition(_ positionMs: Int64, durationMs: Int64) {
        guard durationMs > 0, !isLive, let episode = currentEpisode else { return }
        // Mirror updateSyncProgressPercentage (80%) and resume persistence.
        if Double(positionMs) / Double(durationMs) >= 0.8 {
            CSDataStoreHelper.shared.setLastWatchedEpisode(url: config.generator.videos[currentVideoIndex].data.url ?? "",
                                                           apiName: config.apiName,
                                                           episode: episode.episode, season: episode.season)
        }
        CSDataStoreHelper.shared.setViewPos(url: episode.data.url ?? "", apiName: config.apiName,
                                            positionMs: positionMs, durationMs: durationMs)
    }

    var isLive: Bool { false }

    // MARK: Watch Together

    private func setupWatchTogether() {
        wtManager.contentListener = { [weak self] content, position, playing in
            Task { @MainActor in
                self?.handleRemoteContent(content, position: position, playing: playing)
            }
        }
        wtManager.onPlay = { [weak self] position in
            Task { @MainActor in
                guard let self else { return }
                self.isApplyingRemote = true
                self.player.seekTo(positionMs: position, source: .sync)
                self.player.play()
                self.isApplyingRemote = false
            }
        }
        wtManager.onPause = { [weak self] position in
            Task { @MainActor in
                guard let self else { return }
                self.isApplyingRemote = true
                self.player.seekTo(positionMs: position, source: .sync)
                self.player.pause()
                self.isApplyingRemote = false
            }
        }
        wtManager.onSeek = { [weak self] position in
            Task { @MainActor in
                guard let self else { return }
                self.isApplyingRemote = true
                self.player.seekTo(positionMs: position, source: .sync)
                self.isApplyingRemote = false
            }
        }
    }

    private func handleRemoteContent(_ content: ContentInfo, position: Int64, playing: Bool) {
        // A host broadcast a different episode; jump the episode list if it matches.
        if let idx = generator.videos.firstIndex(where: { "\($0.id)" == content.episodeId.map(String.init) ?? "" }),
           idx != currentVideoIndex {
            switchEpisode(to: idx, resume: position, playing: playing)
        }
    }

    private func broadcastContent(positionMs: Int64, playing: Bool) {
        guard let episode = currentEpisode else { return }
        wtManager.sendContent(url: episode.data.url ?? "", apiName: config.apiName,
                              name: config.title, episodeId: episode.id,
                              episode: episode.episode, season: episode.season,
                              positionMs: positionMs, playing: playing)
        didSendContent = true
    }

    // MARK: Loading

    func start() async {
        isLoading = true
        loadError = nil
        await loadVideo(at: currentVideoIndex, resume: resumePosition())
    }

    private func resumePosition() -> Int64 {
        guard let episode = currentEpisode else { return 0 }
        return CSDataStoreHelper.shared.getViewPos(url: episode.data.url ?? "", apiName: config.apiName)
    }

    func loadVideo(at index: Int, resume: Int64 = 0) async {
        var collected: [ExtractorLink] = []
        var subs: [SubtitleData] = []
        let success = await generator.generateLinks(
            clearCache: false,
            sourceTypes: LoadType.inApp.sourceTypes,
            callback: { videoLink in
                if let resolved = videoLink.link { collected.append(resolved) }
            },
            subtitleCallback: { subs.append($0) },
            offset: index,
            isCasting: false
        )

        links = collected
        subtitles = subs

        if collected.isEmpty {
            loadError = "No playable sources found"
            isLoading = false
            return
        }

        // Mirror sortUrls priority ordering; choose the best match.
        let sorted = QualityDataHelper.sortUrls(collected, profile: 0)
        links = sorted
        currentLinkIndex = 0

        await loadSkipStamps()
        startPlayback(link: sorted[0], startPosition: resume)
        isLoading = false

        if wtManager.connected && !didSendContent {
            broadcastContent(positionMs: resume, playing: true)
        }
    }

    private func startPlayback(link: ExtractorLink, startPosition: Int64) {
        player.loadPlayer(link: link, startPositionMs: startPosition)
        player.setPlaybackSpeed(CSDataStoreHelper.shared.getPlaybackSpeed())
        if let subtitle = autoSelectSubtitle() {
            selectedSubtitle = subtitle
        }
    }

    private func autoSelectSubtitle() -> SubtitleData? {
        // Prefer a cached/previously selected language, else English.
        let cached = CSDataStore.getKeyString("subtitle_language_key")
        return subtitles.first { $0.languageCode == cached }
            ?? subtitles.first { $0.languageCode?.lowercased().hasPrefix("en") == true }
            ?? subtitles.first
    }

    private func loadSkipStamps() async {
        guard let episode = currentEpisode, episode.data.url?.isEmpty == false else { return }
        // Stamps keyed off MAL id via sync providers; best-effort.
        if let stamps = await AnimeSkipProvider.videoStamps(malId: nil) {
            player.addTimeStamps(stamps)
        }
    }

    // MARK: Controls

    func togglePlayPause() {
        if wtManager.connected {
            if player.isPlaying { wtManager.sendPause(positionMs: player.positionMs) }
            else { wtManager.sendPlay(positionMs: player.positionMs) }
        }
        player.playPauseToggle()
    }

    func seekForward() {
        let target = player.positionMs + CSPlayer.seekActionTime
        if wtManager.connected { wtManager.sendSeek(positionMs: target) }
        player.seekForward()
    }

    func seekBack() {
        let target = max(0, player.positionMs - CSPlayer.seekActionTime)
        if wtManager.connected { wtManager.sendSeek(positionMs: target) }
        player.seekBack()
    }

    func changeSpeed(_ speed: Double) {
        player.setPlaybackSpeed(speed)
        CSDataStoreHelper.shared.setPlaybackSpeed(speed)
    }

    func nextEpisode() {
        if hasNextEpisode {
            switchEpisode(to: currentVideoIndex + 1)
        }
    }

    func prevEpisode() {
        if hasPrevEpisode {
            switchEpisode(to: currentVideoIndex - 1)
        }
    }

    private func playNextEpisode() {
        if hasNextEpisode {
            switchEpisode(to: currentVideoIndex + 1, resume: 0)
        } else {
            player.onPause()
        }
    }

    private func switchEpisode(to index: Int, resume: Int64? = nil, playing: Bool = true) {
        currentVideoIndex = index
        didSendContent = false
        selectedSubtitle = nil
        let start = resume ?? CSDataStoreHelper.shared.getViewPos(
            url: generator.videos[index].data.url ?? "", apiName: config.apiName)
        Task {
            await loadVideo(at: index, resume: start)
        }
    }

    func seek(to ratio: Double) {
        let target = Int64(ratio * Double(player.durationMs))
        player.seekTo(positionMs: target, source: .ui)
        if wtManager.connected { wtManager.sendSeek(positionMs: target) }
    }

    // MARK: Teardown

    func onDisappear() {
        player.release()
        if wtManager.connected && !didSendContent, let episode = currentEpisode {
            wtManager.sendPause(positionMs: player.positionMs)
            _ = episode
        }
    }
}