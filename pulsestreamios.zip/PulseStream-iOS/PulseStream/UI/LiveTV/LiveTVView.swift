import SwiftUI
import Combine

// MARK: - LiveTVViewModel (mirrors ui/livetv/LiveTVViewModel.kt)
@MainActor
final class LiveTVViewModel: ObservableObject {
    @Published var searchQuery: String = ""
    @Published private(set) var channels: [LiveTvChannel] = []
    @Published private(set) var isLoading = false
    @Published private(set) var isRefreshing = false
    @Published private(set) var error: String?

    private var timer: Timer?

    init() {
        let repo = LiveTvRepository.shared
        channels = repo.channels
        if channels.isEmpty {
            Task { await load() }
        }
        startAutoRefresh()
    }

    var filteredChannels: [LiveTvChannel] {
        guard !searchQuery.isEmpty else { return channels }
        return channels.filter { $0.name.localizedCaseInsensitiveContains(searchQuery) }
    }

    func load() async {
        isLoading = true
        error = nil
        let repo = LiveTvRepository.shared
        await repo.load()
        channels = repo.channels
        error = repo.loadError
        isLoading = false
    }

    func refresh() async {
        isRefreshing = true
        let repo = LiveTvRepository.shared
        await repo.load(forceRefresh: true)
        channels = repo.channels
        error = repo.loadError
        isRefreshing = false
    }

    func select(_ channel: LiveTvChannel) {
        LiveTvRepository.shared.lastChannelId = channel.id
    }

    private func startAutoRefresh() {
        timer = Timer.scheduledTimer(withTimeInterval: 5 * 60, repeats: true) { [weak self] _ in
            Task { @MainActor in
                await self?.refresh()
            }
        }
    }

    deinit {
        timer?.invalidate()
    }
}

// MARK: - LiveTVView
struct LiveTVView: View {
    @StateObject private var viewModel = LiveTVViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme

    private let columns = [GridItem(.adaptive(minimum: 150), spacing: 12)]

    var body: some View {
        NavigationStack(path: $appState.navigationPath) {
            ZStack {
                AppBackground()
                VStack(spacing: 0) {
                    searchBar
                    if viewModel.isLoading && viewModel.channels.isEmpty {
                        LoadingGrid(count: 8)
                    } else if let error = viewModel.error, viewModel.channels.isEmpty {
                        ErrorStateView(message: error) {
                            Task { await viewModel.load() }
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else if viewModel.filteredChannels.isEmpty {
                        EmptyStateView(message: "No channels found", icon: "tv")
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        channelGrid
                    }
                }
            }
            .navigationDestination(for: NavigationTarget.self) { target in
                switch target {
                case .livePlayer(let channelId):
                    LiveTVPlayerView(channelId: channelId)
                case .player(let url, let name, let episodeId):
                    PlayerContainerView(url: url, name: name, episodeId: episodeId)
                default:
                    EmptyView()
                }
            }
            .navigationTitle("Live TV")
            .toolbar(.hidden, for: .navigationBar)
            .task {
                if viewModel.channels.isEmpty {
                    await viewModel.load()
                }
            }
        }
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(Color(theme.textSecondary))
                TextField("Search channels", text: $viewModel.searchQuery)
                    .foregroundColor(Color(theme.text))
                    .autocorrectionDisabled()
            }
            .padding(10)
            .background(Color(theme.surface))
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
    }

    private var channelGrid: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(viewModel.filteredChannels) { channel in
                    ChannelCard(channel: channel)
                        .onTapGesture {
                            viewModel.select(channel)
                            appState.navigationPath.append(.livePlayer(channelId: channel.id))
                        }
                }
            }
            .padding()
        }
        .refreshable {
            await viewModel.refresh()
        }
    }
}

struct ChannelCard: View {
    let channel: LiveTvChannel
    @Environment(\.appTheme) var theme

    var body: some View {
        VStack(spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(theme.surfaceVariant))
                RemoteImage(url: channel.logoUrl, placeholder: Image(systemName: "tv"))
                    .frame(width: 90, height: 90)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                Image(systemName: "play.circle.fill")
                    .font(.title2)
                    .foregroundColor(Color(theme.accent))
                    .shadow(radius: 4)
            }
            .frame(height: 110)

            Text(channel.name)
                .font(.caption.bold())
                .foregroundColor(Color(theme.text))
                .lineLimit(2)
                .multilineTextAlignment(.center)
        }
    }
}