import SwiftUI
import UniformTypeIdentifiers

// MARK: - SettingsView
struct SettingsView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme
    @State private var showBackupPicker = false

    var body: some View {
        NavigationStack(path: $appState.navigationPath) {
            ZStack {
                Color(theme.background).ignoresSafeArea()
                Form {
                    appearanceSection
                    playerSection
                    downloadSection
                    watchTogetherSection
                    extensionsSection
                    backupSection
                    aboutSection
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Settings")
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: NavigationTarget.self) { target in
                switch target {
                case .watchTogether: WatchTogetherListView()
                case .extensions: ExtensionsView()
                case .qualityProfiles: QualityProfilesView()
                default: EmptyView()
                }
            }
            .fileImporter(isPresented: $showBackupPicker, allowedContentTypes: [.json]) { result in
                if case .success(let url) = result {
                    try? BackupManager.shared.restore(from: url)
                }
            }
        }
    }

    // MARK: Sections

    private var appearanceSection: some View {
        Section("Appearance") {
            Picker("Theme", selection: $appState.theme) {
                ForEach(CSTheme.allCases) { t in
                    Text(t.displayName).tag(t)
                }
            }
            .onChange(of: appState.theme) { newValue in
                appState.setTheme(newValue)
            }

            Picker("Primary Color", selection: $appState.primaryColor) {
                ForEach(CSPrimaryColor.allCases) { c in
                    Text(c.displayName).tag(c)
                }
            }
            .onChange(of: appState.primaryColor) { newValue in
                appState.setPrimaryColor(newValue)
            }

            Toggle("Adult Content Filter", isOn: Binding(
                get: { CSDataStore.getKeyBool(AppSettings.Keys.adultContentFilter) ?? true },
                set: { CSDataStore.setKey(AppSettings.Keys.adultContentFilter, $0) }
            ))
            .tint(Color(theme.accent))
        }
    }

    private var playerSection: some View {
        Section("Player") {
            Toggle("Autoplay next episode", isOn: Binding(
                get: { CSDataStore.getKeyBool(AppSettings.Keys.autoplayNext) ?? true },
                set: { CSDataStore.setKey(AppSettings.Keys.autoplayNext, $0) }
            ))
            .tint(Color(theme.accent))

            Toggle("Skip intro/outro from database", isOn: Binding(
                get: { CSDataStore.getKeyBool(AppSettings.Keys.enableSkipOpFromDatabase) ?? true },
                set: { CSDataStore.setKey(AppSettings.Keys.enableSkipOpFromDatabase, $0) }
            ))
            .tint(Color(theme.accent))

            NavigationLink(value: NavigationTarget.qualityProfiles) {
                Label("Source & Quality Priority", systemImage: "slider.horizontal.3")
            }

            Toggle("Swipe to seek", isOn: Binding(
                get: { CSDataStore.getKeyBool(AppSettings.Keys.swipeToSeek) ?? true },
                set: { CSDataStore.setKey(AppSettings.Keys.swipeToSeek, $0) }
            ))
            .tint(Color(theme.accent))
        }
    }

    private var downloadSection: some View {
        Section("Downloads") {
            Toggle("Parallel downloads", isOn: Binding(
                get: { CSDataStore.getKeyBool(AppSettings.Keys.downloadParallel) ?? true },
                set: { CSDataStore.setKey(AppSettings.Keys.downloadParallel, $0) }
            ))
            .tint(Color(theme.accent))

            Stepper("Concurrent downloads: \(DownloadManager.maxConcurrentDownloads)", value: Binding(
                get: { CSDataStore.getKeyInt(AppSettings.Keys.downloadConcurrent) ?? DownloadManager.maxConcurrentDownloads },
                set: { CSDataStore.setKey(AppSettings.Keys.downloadConcurrent, $0) }
            ), in: 1...DownloadManager.maxConcurrentDownloads)
        }
    }

    private var watchTogetherSection: some View {
        Section("Social") {
            NavigationLink(value: NavigationTarget.watchTogether) {
                Label("Watch Together", systemImage: "person.2.fill")
            }
        }
    }

    private var extensionsSection: some View {
        Section("Extensions") {
            NavigationLink(value: NavigationTarget.extensions) {
                Label("Plugins & Providers", systemImage: "puzzlepiece.extension")
            }
        }
    }

    private var backupSection: some View {
        Section("Backup") {
            Button("Backup now") {
                BackupManager.shared.performBackup()
            }
            Button("Restore from backup") {
                showBackupPicker = true
            }
            Toggle("Automatic backup", isOn: Binding(
                get: { CSDataStore.getKeyBool(AppSettings.Keys.automaticBackup) ?? true },
                set: { CSDataStore.setKey(AppSettings.Keys.automaticBackup, $0) }
            ))
            .tint(Color(theme.accent))
        }
    }

    private var aboutSection: some View {
        Section("About") {
            LabeledContent("Version", value: AppConfig.versionName)
            LabeledContent("Build", value: "\(AppConfig.versionCode)")
        }
    }
}

// MARK: - QualityProfilesView
struct QualityProfilesView: View {
    @Environment(\.appTheme) var theme
    @State private var profiles: [QualityDataHelper.QualityProfile] = []

    var body: some View {
        List {
            ForEach(profiles) { profile in
                VStack(alignment: .leading, spacing: 4) {
                    Text(profile.name)
                        .font(.subheadline.bold())
                        .foregroundColor(Color(theme.text))
                    Text("ID \(profile.id)")
                        .font(.caption)
                        .foregroundColor(Color(theme.textSecondary))
                }
            }
        }
        .navigationTitle("Source & Quality Priority")
        .onAppear {
            profiles = (0..<QualityDataHelper.profileCount).map { index in
                QualityDataHelper.QualityProfile(name: QualityDataHelper.getProfileName(index),
                                                 type: QualityDataHelper.getProfileType(index),
                                                 id: index)
            }
        }
    }
}