import SwiftUI

// MARK: - PosterCard
/// Mirrors the poster grid items used across Home/Search/Library/Results.
struct PosterCard: View {
    let item: SearchResponse
    var width: CGFloat = 120
    var posterHeight: CGFloat = 170
    @Environment(\.appTheme) var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            ZStack(alignment: .bottomTrailing) {
                RemoteImage(url: item.posterUrl, headers: item.posterHeaders,
                            placeholder: Image(systemName: "film"))
                    .frame(width: width, height: posterHeight)
                    .background(Color(theme.surfaceVariant))
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.white.opacity(0.06), lineWidth: 1)
                    )

                if !item.score.isUnrated {
                    Text("\(item.score.toRating, specifier: "%.1f")")
                        .font(.caption2.bold())
                        .foregroundColor(.white)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.green.opacity(0.9))
                        .clipShape(RoundedRectangle(cornerRadius: 4))
                        .padding(6)
                }
            }
            .frame(height: posterHeight)

            Text(item.name)
                .font(.caption)
                .foregroundColor(Color(theme.text))
                .lineLimit(2)
                .frame(width: width, alignment: .leading)

            if let year = item.year {
                Text("\(year)")
                    .font(.caption2)
                    .foregroundColor(Color(theme.textSecondary))
            }
        }
    }
}

// MARK: - Loading, Empty & Error states
struct LoadingRow: View {
    @Environment(\.appTheme) var theme
    var body: some View {
        HStack(spacing: 10) {
            RoundedRectangle(cornerRadius: 6)
                .fill(Color(theme.surfaceVariant))
                .frame(width: 50, height: 70)
            VStack(alignment: .leading, spacing: 6) {
                RoundedRectangle(cornerRadius: 4).fill(Color(theme.surfaceVariant)).frame(height: 12)
                RoundedRectangle(cornerRadius: 4).fill(Color(theme.surfaceVariant)).frame(height: 10).frame(width: 140)
            }
        }
        .redacted(reason: .placeholder)
    }
}

struct LoadingGrid: View {
    var count = 8
    var body: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 120), spacing: 12)], spacing: 16) {
                ForEach(0..<count, id: \.self) { _ in
                    LoadingRow()
                }
            }
            .padding()
        }
    }
}

struct ErrorStateView: View {
    let message: String
    let retry: () -> Void
    @Environment(\.appTheme) var theme

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 40))
                .foregroundColor(Color(theme.textSecondary))
            Text(message)
                .font(.subheadline)
                .foregroundColor(Color(theme.textSecondary))
                .multilineTextAlignment(.center)
            Button("Retry", action: retry)
                .buttonStyle(.borderedProminent)
                .tint(Color(theme.accent))
        }
        .padding(32)
    }
}

struct EmptyStateView: View {
    let message: String
    let icon: String
    @Environment(\.appTheme) var theme

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 40))
                .foregroundColor(Color(theme.textSecondary))
            Text(message)
                .font(.subheadline)
                .foregroundColor(Color(theme.textSecondary))
                .multilineTextAlignment(.center)
        }
        .padding(32)
    }
}

// MARK: - Horizontal poster row (home page lists)
struct PosterRow: View {
    let list: HomePageList
    var onTap: (SearchResponse) -> Void
    @Environment(\.appTheme) var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(list.name)
                .font(.headline)
                .foregroundColor(Color(theme.text))
                .padding(.horizontal)

            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 12) {
                    ForEach(list.list) { item in
                        PosterCard(item: item, width: 120, posterHeight: 170)
                            .onTapGesture { onTap(item) }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

// MARK: - Background
struct AppBackground: View {
    @Environment(\.appTheme) var theme
    var body: some View {
        Color(theme.background).ignoresSafeArea()
    }
}

// MARK: - Section header
struct SectionHeader: View {
    let title: String
    @Environment(\.appTheme) var theme
    var body: some View {
        Text(title)
            .font(.headline)
            .foregroundColor(Color(theme.text))
            .padding(.horizontal)
    }
}

// MARK: - Watched progress bar
struct ProgressBar: View {
    let progress: Double
    @Environment(\.appTheme) var theme
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(Color(theme.surfaceVariant))
                Capsule().fill(Color(theme.accent))
                    .frame(width: geo.size.width * min(max(progress, 0), 1))
            }
        }
        .frame(height: 3)
    }
}