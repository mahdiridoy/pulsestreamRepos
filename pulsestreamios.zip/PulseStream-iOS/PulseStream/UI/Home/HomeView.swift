import SwiftUI
import Combine

// MARK: - HomeViewModel (mirrors ui/home/HomeViewModel.kt)
@MainActor
final class HomeViewModel: ObservableObject {
    @Published private(set) var homeLists: [HomePageList] = []
    @Published private(set) var isLoading = false
    @Published private(set) var error: String?
    @Published var hasMore = false
    private var currentPage = 0

    func loadInitial() async {
        isLoading = true
        error = nil
        currentPage = 0
        var collected: [HomePageList] = []
        let providers = APIHolder.shared.apis.filter { $0.hasMainPage }
        for provider in providers {
            let repo = APIRepository(api: provider)
            let result = await repo.loadMainPage(page: 0, category: nil)
            if case .success(let response) = result {
                let filtered = response.items.map { list in
                    var copy = list
                    copy.list = AdultContentFilter.filterList(list.list)
                    return copy
                }
                collected.append(contentsOf: filtered)
                if response.hasNext { hasMore = true }
            } else if case .failure(_, let msg) = result {
                error = msg
            }
        }
        homeLists = collected
        isLoading = false
    }

    func loadMore() async {
        guard hasMore else { return }
        currentPage += 1
        var collected: [HomePageList] = []
        let providers = APIHolder.shared.apis.filter { $0.hasMainPage }
        for provider in providers {
            let repo = APIRepository(api: provider)
            let result = await repo.loadMainPage(page: currentPage, category: nil)
            if case .success(let response) = result {
                let filtered = response.items.map { list in
                    var copy = list
                    copy.list = AdultContentFilter.filterList(list.list)
                    return copy
                }
                collected.append(contentsOf: filtered)
                hasMore = response.hasNext
            }
        }
        homeLists.append(contentsOf: collected)
    }

    func refresh() async {
        await loadInitial()
    }
}

// MARK: - HomeView
struct HomeView: View {
    @StateObject private var viewModel = HomeViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme

    var body: some View {
        NavigationStack(path: $appState.navigationPath) {
            ZStack {
                AppBackground()
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 24) {
                        if viewModel.isLoading && viewModel.homeLists.isEmpty {
                            ForEach(0..<4, id: \.self) { _ in LoadingRow().padding(.horizontal) }
                        } else if let error = viewModel.error, viewModel.homeLists.isEmpty {
                            ErrorStateView(message: error) {
                                Task { await viewModel.loadInitial() }
                            }
                            .frame(maxWidth: .infinity)
                        } else {
                            ForEach(viewModel.homeLists) { list in
                                PosterRow(list: list) { item in
                                    appState.navigationPath.append(.result(url: item.url, apiName: item.apiName, name: item.name))
                                }
                            }
                        }
                    }
                    .padding(.vertical)
                }
                .refreshable {
                    await viewModel.refresh()
                }
            }
            .navigationDestination(for: NavigationTarget.self) { target in
                destination(for: target)
            }
            .navigationTitle("Movies & Series")
            .toolbar(.hidden, for: .navigationBar)
            .task {
                if viewModel.homeLists.isEmpty && !viewModel.isLoading {
                    await viewModel.loadInitial()
                }
            }
        }
    }

    @ViewBuilder
    private func destination(for target: NavigationTarget) -> some View {
        switch target {
        case .result(let url, let apiName, let name):
            ResultView(url: url, apiName: apiName, name: name)
        case .player(let url, let name, let episodeId):
            PlayerContainerView(url: url, name: name, episodeId: episodeId)
        case .livePlayer(let channelId):
            LiveTVPlayerView(channelId: channelId)
        default:
            EmptyView()
        }
    }
}