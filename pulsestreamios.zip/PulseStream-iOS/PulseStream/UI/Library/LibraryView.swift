import SwiftUI
import Combine

// MARK: - LibraryViewModel (mirrors ui/library/LibraryViewModel.kt)
@MainActor
final class LibraryViewModel: ObservableObject {
    enum Category: String, CaseIterable, Identifiable {
        case favorites = "Favorites"
        case bookmarks = "Bookmarks"
        case continueWatching = "Continue Watching"
        case history = "History"

        var id: String { rawValue }
    }

    @Published var category: Category = .favorites
    @Published private(set) var favorites: [LibraryEntry] = []
    @Published private(set) var bookmarks: [LibraryEntry] = []
    @Published private(set) var continueWatching: [LibraryEntry] = []
    @Published private(set) var history: [LibraryEntry] = []

    struct LibraryEntry: Identifiable {
        var id: String { url }
        var url: String
        var apiName: String?
        var name: String
        var posterUrl: String?
        var type: TvType
        var progress: Double?
    }

    func refresh() {
        let helper = CSDataStoreHelper.shared
        var favs: [LibraryEntry] = []
        var bookmarksEntries: [LibraryEntry] = []
        var historyEntries: [LibraryEntry] = []

        for api in APIHolder.shared.apis {
            let data = helper.getFavorites(for: api.name)
            for url in data.favorites {
                favs.append(LibraryEntry(url: url, apiName: api.name, name: url,
                                         posterUrl: nil, type: .movie, progress: nil))
            }
            for url in data.bookmarks {
                bookmarksEntries.append(LibraryEntry(url: url, apiName: api.name, name: url,
                                                     posterUrl: nil, type: .movie, progress: nil))
            }
            for url in data.history {
                historyEntries.append(LibraryEntry(url: url, apiName: api.name, name: url,
                                                   posterUrl: nil, type: .movie, progress: nil))
            }
        }

        // Continue watching from resume states.
        let keys = CSDataStore.getKeys().filter { $0.hasPrefix("resume/") }
        var cw: [LibraryEntry] = []
        for key in keys {
            let parts = key.split(separator: "/")
            guard parts.count >= 3 else { continue }
            let apiName = String(parts[1])
            let url = parts.dropFirst(2).joined(separator: "/")
            let state = helper.getVideoWatchState(url: url, apiName: apiName)
            guard state.durationMs > 0 else { continue }
            let progress = Double(state.positionMs) / Double(state.durationMs)
            guard progress < 0.95 else { continue }
            cw.append(LibraryEntry(url: url, apiName: apiName, name: url,
                                   posterUrl: nil, type: .tvSeries, progress: progress))
        }

        favorites = favs
        bookmarks = bookmarksEntries
        history = historyEntries
        continueWatching = cw
    }

    var currentEntries: [LibraryEntry] {
        switch category {
        case .favorites: return favorites
        case .bookmarks: return bookmarks
        case .continueWatching: return continueWatching
        case .history: return history
        }
    }

    func remove(_ entry: LibraryEntry) {
        let helper = CSDataStoreHelper.shared
        switch category {
        case .favorites:
            let data = helper.getFavorites(for: entry.apiName)
            var copy = data
            copy.favorites.removeAll { $0 == entry.url }
            copy.subscriptions.removeAll { $0 == entry.url }
            helper.setFavorites(copy, for: entry.apiName)
        case .bookmarks:
            let data = helper.getFavorites(for: entry.apiName)
            var copy = data
            copy.bookmarks.removeAll { $0 == entry.url }
            helper.setFavorites(copy, for: entry.apiName)
        case .continueWatching:
            helper.setVideoWatchState(.init(), url: entry.url, apiName: entry.apiName)
        case .history:
            let data = helper.getFavorites(for: entry.apiName)
            var copy = data
            copy.history.removeAll { $0 == entry.url }
            helper.setFavorites(copy, for: entry.apiName)
        }
        refresh()
    }
}

// MARK: - LibraryView
struct LibraryView: View {
    @StateObject private var viewModel = LibraryViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme

    var body: some View {
        NavigationStack(path: $appState.navigationPath) {
            ZStack {
                AppBackground()
                VStack(spacing: 0) {
                    Picker("Category", selection: $viewModel.category) {
                        ForEach(LibraryViewModel.Category.allCases) { cat in
                            Text(cat.rawValue).tag(cat)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal)
                    .padding(.vertical, 8)

                    if viewModel.currentEntries.isEmpty {
                        EmptyStateView(message: "Nothing here yet", icon: "bookmark")
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        List {
                            ForEach(viewModel.currentEntries) { entry in
                                LibraryRow(entry: entry)
                                    .contentShape(Rectangle())
                                    .onTapGesture {
                                        appState.navigationPath.append(.result(url: entry.url, apiName: entry.apiName, name: entry.name))
                                    }
                                    .swipeActions {
                                        Button(role: .destructive) {
                                            viewModel.remove(entry)
                                        } label: {
                                            Label("Remove", systemImage: "trash")
                                        }
                                    }
                            }
                        }
                        .scrollContentBackground(.hidden)
                        .listStyle(.plain)
                    }
                }
            }
            .navigationDestination(for: NavigationTarget.self) { target in
                if case .result(let url, let apiName, let name) = target {
                    ResultView(url: url, apiName: apiName, name: name)
                } else {
                    EmptyView()
                }
            }
            .navigationTitle("Library")
            .toolbar(.hidden, for: .navigationBar)
            .task {
                viewModel.refresh()
            }
        }
    }
}

struct LibraryRow: View {
    let entry: LibraryViewModel.LibraryEntry
    @Environment(\.appTheme) var theme

    var body: some View {
        HStack(spacing: 12) {
            RemoteImage(url: entry.posterUrl, placeholder: Image(systemName: "film"))
                .frame(width: 56, height: 80)
                .background(Color(theme.surfaceVariant))
                .clipShape(RoundedRectangle(cornerRadius: 6))
            VStack(alignment: .leading, spacing: 6) {
                Text(entry.name)
                    .font(.subheadline.bold())
                    .foregroundColor(Color(theme.text))
                    .lineLimit(2)
                if let progress = entry.progress {
                    ProgressBar(progress: progress)
                }
            }
            Spacer()
        }
        .padding(.vertical, 4)
    }
}