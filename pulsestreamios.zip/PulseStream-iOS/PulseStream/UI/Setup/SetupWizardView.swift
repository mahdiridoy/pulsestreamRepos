import SwiftUI

// MARK: - SetupWizardView
/// Mirrors the Android SetupActivity flow (welcome → internet → sponsor → done).
struct SetupWizardView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.appTheme) var theme
    @State private var step: Step = .welcome
    @State private var isCheckingNetwork = false
    @State private var networkOK = false

    enum Step {
        case welcome
        case internet
        case sponsor
        case done
    }

    var body: some View {
        ZStack {
            Color(theme.background).ignoresSafeArea()
            VStack(spacing: 24) {
                Spacer()

                switch step {
                case .welcome:
                    welcomeView
                case .internet:
                    internetView
                case .sponsor:
                    sponsorView
                case .done:
                    doneView
                }

                Spacer()
                progressDots
            }
            .padding(24)
        }
    }

    private var welcomeView: some View {
        VStack(spacing: 16) {
            Image(systemName: "play.rectangle.fill")
                .font(.system(size: 80))
                .foregroundColor(Color(theme.accent))
            Text("Welcome to PulseStream")
                .font(.largeTitle.bold())
                .foregroundColor(Color(theme.text))
                .multilineTextAlignment(.center)
            Text("Stream movies, series, live TV and more — all free.")
                .font(.subheadline)
                .foregroundColor(Color(theme.textSecondary))
                .multilineTextAlignment(.center)
            Button("Get Started") {
                withAnimation { step = .internet }
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(theme.accent))
            .padding(.top, 8)
        }
    }

    private var internetView: some View {
        VStack(spacing: 16) {
            Image(systemName: networkOK ? "checkmark.seal.fill" : "wifi")
                .font(.system(size: 70))
                .foregroundColor(networkOK ? .green : Color(theme.accent))
            Text("Check your connection")
                .font(.title2.bold())
                .foregroundColor(Color(theme.text))
            Text("PulseStream needs internet access to stream content and sync with your account.")
                .font(.subheadline)
                .foregroundColor(Color(theme.textSecondary))
                .multilineTextAlignment(.center)

            if isCheckingNetwork {
                ProgressView()
            }

            Button(networkOK ? "Continue" : "Check Connection") {
                if networkOK {
                    withAnimation { step = .sponsor }
                } else {
                    Task { await checkNetwork() }
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(theme.accent))
        }
    }

    private var sponsorView: some View {
        VStack(spacing: 16) {
            Image(systemName: "megaphone.fill")
                .font(.system(size: 60))
                .foregroundColor(Color(theme.accent))
            Text("Support the project")
                .font(.title2.bold())
                .foregroundColor(Color(theme.text))
            Text("PulseStream is free and open source. Consider supporting development.")
                .font(.subheadline)
                .foregroundColor(Color(theme.textSecondary))
                .multilineTextAlignment(.center)
            Button("Continue") {
                withAnimation { step = .done }
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(theme.accent))
        }
    }

    private var doneView: some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 80))
                .foregroundColor(.green)
            Text("You're all set!")
                .font(.largeTitle.bold())
                .foregroundColor(Color(theme.text))
            Button("Start Streaming") {
                appState.completeSetup()
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(theme.accent))
            .padding(.top, 8)
        }
    }

    private var progressDots: some View {
        HStack(spacing: 8) {
            ForEach(0..<4, id: \.self) { index in
                Circle()
                    .fill(dotColor(for: index))
                    .frame(width: 8, height: 8)
            }
        }
    }

    private func dotColor(for index: Int) -> Color {
        let stepIndex: Int
        switch step {
        case .welcome: stepIndex = 0
        case .internet: stepIndex = 1
        case .sponsor: stepIndex = 2
        case .done: stepIndex = 3
        }
        return index <= stepIndex ? Color(theme.accent) : Color(theme.surfaceVariant)
    }

    private func checkNetwork() async {
        isCheckingNetwork = true
        defer { isCheckingNetwork = false }
        do {
            let response = try await Requests.app.get("https://example.com", timeout: 10)
            networkOK = response.isSuccessful
        } catch {
            networkOK = false
        }
    }
}