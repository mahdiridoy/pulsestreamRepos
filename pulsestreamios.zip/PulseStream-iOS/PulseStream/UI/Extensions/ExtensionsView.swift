import SwiftUI

// MARK: - ExtensionsView
/// Mirrors the Plugins screen. iOS bundles providers/extractors instead of loading APKs.
struct ExtensionsView: View {
    @Environment(\.appTheme) var theme
    @State private var providers: [MainAPI] = []
    @State private var extractors: [ExtractorAPI] = []
    @State private var subtitles: [SubtitleAPI] = []

    var body: some View {
        ZStack {
            Color(theme.background).ignoresSafeArea()
            List {
                Section("Providers") {
                    ForEach(providers, id: \.name) { provider in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(provider.name)
                                    .foregroundColor(Color(theme.text))
                                Text(provider.mainUrl)
                                    .font(.caption)
                                    .foregroundColor(Color(theme.textSecondary))
                            }
                            Spacer()
                            Text(provider.enabled ? "On" : "Off")
                                .font(.caption)
                                .foregroundColor(provider.enabled ? .green : .orange)
                        }
                    }
                }

                Section("Extractors") {
                    ForEach(extractors, id: \.name) { extractor in
                        HStack {
                            Text(extractor.name)
                                .foregroundColor(Color(theme.text))
                            Spacer()
                            Image(systemName: "checkmark.seal.fill")
                                .foregroundColor(.green)
                        }
                    }
                }

                Section("Subtitle Providers") {
                    ForEach(subtitles, id: \.name) { subtitle in
                        HStack {
                            Text(subtitle.name)
                                .foregroundColor(Color(theme.text))
                            Spacer()
                            Image(systemName: "captions.bubble")
                                .foregroundColor(Color(theme.textSecondary))
                        }
                    }
                }

                Section {
                    Text("On iOS, providers are bundled with the app (APK plugins aren't supported). Tap a provider to toggle.")
                        .font(.footnote)
                        .foregroundColor(Color(theme.textSecondary))
                }
            }
            .scrollContentBackground(.hidden)
        }
        .navigationTitle("Plugins & Providers")
        .onAppear {
            providers = APIHolder.shared.apis
            extractors = APIHolder.shared.extractorApis
            subtitles = APIHolder.shared.subtitleApis
        }
    }
}